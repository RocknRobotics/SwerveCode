package frc.robot.Swerve;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.VecBuilder;
import edu.wpi.first.math.controller.LinearQuadraticRegulator;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.estimator.KalmanFilter;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N2;
import edu.wpi.first.math.system.LinearSystem;
import edu.wpi.first.math.system.LinearSystemLoop;
import edu.wpi.first.math.system.plant.LinearSystemId;
import edu.wpi.first.math.util.Units;
import frc.robot.Robot;

public final class Constants {
    //Drive motor ids
    static final int[] driveIds = {1, 2, 3, 4};

    //Turn motor ids
    static final int[] turnIds = {11, 12, 13, 14};

    //Drive motor inversions
    static final boolean[] driveInversions = {false, false, false, false};

    //Turn motor inversions
    static final boolean[] turnInversions = {true, true, true, true};

    //Encoder offsets
    public static final float[] encoderOffsets = {
        Robot.isReal() ? 2.7180152f : 0f, 
        Robot.isReal() ? 2.957851f : 0f, 
        Robot.isReal() ? 4.079757f : 0f, 
        Robot.isReal() ? 0.021486964f : 0f
    };

    //Pigeon2 id
    static final int pigeonId = 61;

    //The factor to multiply the rotation by so it is slower
    static final float rotationFactor = 0.5f;

    //Robot width/height, with bumper
    public static final float robotWidth = (float) Units.inchesToMeters(28f);
    public static final float robotHeight = (float) Units.inchesToMeters(28f);

    //To the centre of the module wheel
    static final float moduleWidth = (float) Units.inchesToMeters(24f);
    static final float moduleHeight = (float) Units.inchesToMeters(24f);

    //Stores rotations about various parts of the robot, assumes rotation to the left is positive
    //Module order is TR, BR, BL, TL
    static final float[][] rotationAngles = new float[][]{
        new float[]{ //Centre of the robot
            frc.robot.Constants.atanLookup(-moduleHeight / 2f, moduleWidth / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(-moduleHeight / 2f, -moduleWidth / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(moduleHeight / 2f, -moduleWidth / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(moduleHeight / 2f, moduleWidth / 2f) + frc.robot.Constants.PIF / 2f
        },
        new float[]{ //TR corner of the robot
            frc.robot.Constants.atanLookup((robotHeight - moduleHeight) / 2f, -(robotWidth - moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup((robotHeight - moduleHeight) / 2f, -(robotWidth + moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(-(robotHeight + moduleHeight) / 2f, -(robotWidth + moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(-(robotHeight + moduleHeight) / 2f, -(robotWidth - moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f
        },
        new float[]{ //BR corner of the robot
            frc.robot.Constants.atanLookup((robotHeight - moduleHeight) / 2f, (robotWidth + moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup((robotHeight - moduleHeight) / 2f, (robotWidth - moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(-(robotHeight + moduleHeight) / 2f, (robotWidth - moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(-(robotHeight + moduleHeight) / 2f, (robotWidth + moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f
        },
        new float[]{ //BL corner of the robot
            frc.robot.Constants.atanLookup(-(robotHeight + moduleHeight) / 2f, (robotWidth + moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(-(robotHeight + moduleHeight) / 2f, (robotWidth - moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup((robotHeight - moduleHeight) / 2f, (robotWidth - moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup((robotHeight - moduleHeight) / 2f, (robotWidth + moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f
        },
        new float[]{ //TL corner of the robot
            frc.robot.Constants.atanLookup(-(robotHeight + moduleHeight) / 2f, -(robotWidth - moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup(-(robotHeight + moduleHeight) / 2f, -(robotWidth + moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup((robotHeight - moduleHeight) / 2f, -(robotWidth + moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f,
            frc.robot.Constants.atanLookup((robotHeight - moduleHeight) / 2f, -(robotWidth - moduleWidth) / 2f) + frc.robot.Constants.PIF / 2f
        }
    };

    //The factor to divide the turn angle change by to get the desired turn motor speed
    static final float turnAngleDivisionFactor = frc.robot.Constants.PIF / 2f;

    //The modulus to use for the turn encoders
    static final float encoderModulus = frc.robot.Constants.PIF;

    //The conversion factor to use for the turn encoders
    public static final float encoderConversionFactor = 150f / 7f / 5f;

    //The conversion factor used to get the position in metres of the drive motor
    static final float driveLinearConversionFactor = (float) Units.inchesToMeters(2f) / 6.12f;

    //TODO
    public static final float maxTranslationalSpeed = (float) Units.feetToMeters(48d) / 3.74f;

    //TODO
    //The distance from the centre of the robot to the centre of the wheel of a swerve module
    static final float moduleCentreDistance = (float) Units.inchesToMeters(12f) * frc.robot.Constants.sqrtLookup(2f);

    //The angles of each of the modules to the centre of the root
    public static final float[] moduleCentreAngle = {-frc.robot.Constants.PIF / 4f, -3 * frc.robot.Constants.PIF / 4f, 3 * frc.robot.Constants.PIF / 4f, frc.robot.Constants.PIF / 4f};

    //A linear system representing a neo vortex used as a turn motor in a swerve module
    static final LinearSystem<N2, N1, N2> turnMotorSystem = LinearSystemId.createDCMotorSystem(
        frc.robot.Constants.neoVortexMotor, //A DCMotor object representing a neo vortex
        5.56f * Math.pow(10, -5) + 6.5 * Math.pow(10, -7), //The inertia of the motor (calculated as rotor inertia + wheel inertia)
        150f / 7f); //Gearing of the motor
    //A linear system representing a neo vortex used as a drive motor in a swerve module
    static final LinearSystem<N2, N1, N2> driveMotorSystem = LinearSystemId.createDCMotorSystem(
        frc.robot.Constants.neoVortexMotor, //A DCMotor object representing a neo vortex
        5.56f * Math.pow(10, -5) + 7.96 * Math.pow(10, -6), //The inertia of the motor (calculated as rotor inertia + wheel inertia)
        6.12f); //Gearing of the motor

    @SuppressWarnings("unchecked")
    //A state-space plant (describes how the system evolves in the future), controller (the LQR, used for finding the optimal voltage inputs), and an observer (the filter, which corrects the plant's predictions)
    //As well as a clamp function and the dtSeconds
    static final LinearSystemLoop<N2, N1, N2>[] turnSystem = new LinearSystemLoop[]{
        new LinearSystemLoop<N2, N1, N2>(
            turnMotorSystem,
            new LinearQuadraticRegulator<N2, N1, N2>(turnMotorSystem.getA(), turnMotorSystem.getB(), MatBuilder.fill(Nat.N2(), Nat.N2(), 0.85f, 0f, 0f, 0.0675f), MatBuilder.fill(Nat.N1(), Nat.N1(), 12f), 0.02f),
            new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), turnMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f),
            frc.robot.Constants.systemClampFunction,
            0.02f),
        new LinearSystemLoop<N2, N1, N2>(
            turnMotorSystem,
            new LinearQuadraticRegulator<N2, N1, N2>(turnMotorSystem.getA(), turnMotorSystem.getB(), MatBuilder.fill(Nat.N2(), Nat.N2(), 0.85f, 0f, 0f, 0.0675f), MatBuilder.fill(Nat.N1(), Nat.N1(), 12f), 0.02f),
            new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), turnMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f),
            frc.robot.Constants.systemClampFunction,
            0.02f),
        new LinearSystemLoop<N2, N1, N2>(
            turnMotorSystem,
            new LinearQuadraticRegulator<N2, N1, N2>(turnMotorSystem.getA(), turnMotorSystem.getB(), MatBuilder.fill(Nat.N2(), Nat.N2(), 0.85f, 0f, 0f, 0.0675f), MatBuilder.fill(Nat.N1(), Nat.N1(), 12f), 0.02f),
            new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), turnMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f),
            frc.robot.Constants.systemClampFunction,
            0.02f),
        new LinearSystemLoop<N2, N1, N2>(
            turnMotorSystem,
            new LinearQuadraticRegulator<N2, N1, N2>(turnMotorSystem.getA(), turnMotorSystem.getB(), MatBuilder.fill(Nat.N2(), Nat.N2(), 0.85f, 0f, 0f, 0.0675f), MatBuilder.fill(Nat.N1(), Nat.N1(), 12f), 0.02f),
            new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), turnMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f),
            frc.robot.Constants.systemClampFunction,
            0.02f)};

    @SuppressWarnings("unchecked")
    //Above but for the drive motors
    static final LinearSystemLoop<N2, N1, N2>[] driveSystem = new LinearSystemLoop[]{
        new LinearSystemLoop<N2, N1, N2>(
            driveMotorSystem, 
            new LinearQuadraticRegulator<N2, N1, N2>(driveMotorSystem, VecBuilder.fill(0.1d, 0.1d), VecBuilder.fill(12f), 0.02f), 
            new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), driveMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f), 
            frc.robot.Constants.systemClampFunction, 
            0.02f),
        new LinearSystemLoop<N2, N1, N2>(
            driveMotorSystem, 
            new LinearQuadraticRegulator<N2, N1, N2>(driveMotorSystem, VecBuilder.fill(0.1d, 0.1d), VecBuilder.fill(12f), 0.02f), 
            new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), driveMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f), 
            frc.robot.Constants.systemClampFunction, 
            0.02f),
        new LinearSystemLoop<N2, N1, N2>(
            driveMotorSystem, 
            new LinearQuadraticRegulator<N2, N1, N2>(driveMotorSystem, VecBuilder.fill(0.1d, 0.1d), VecBuilder.fill(12f), 0.02f), 
            new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), driveMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f), 
            frc.robot.Constants.systemClampFunction, 
            0.02f),
        new LinearSystemLoop<N2, N1, N2>(
            driveMotorSystem, 
            new LinearQuadraticRegulator<N2, N1, N2>(driveMotorSystem, VecBuilder.fill(0.1d, 0.1d), VecBuilder.fill(12f), 0.02f), 
            new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), driveMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f), 
            frc.robot.Constants.systemClampFunction, 
            0.02f)
    };

    //PID controllers for translational movement (x, y) and rotational movement (theta)
    //These are used for automatically driving to a given position. Not used for joystick driving.
    static final PIDController translationalController = new PIDController(1f, 0f, 0.002f, 0.02f);
    static final PIDController angleController = new PIDController(1f, 0f, 0.001f, 0.02f);
    static final PIDController rotationalController = new PIDController(0.85f, 0f, 0.075f, 0.02f);

    static final PIDController[] driveMotorControllers = new PIDController[]{
        new PIDController(0.5f, 0f, 0.01f, 0.02f),
        new PIDController(0.5f, 0f, 0.01f, 0.02f),
        new PIDController(0.5f, 0f, 0.01f, 0.02f),
        new PIDController(0.5f, 0f, 0.01f, 0.02f)
    };
}

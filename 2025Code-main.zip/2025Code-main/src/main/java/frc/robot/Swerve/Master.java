package frc.robot.Swerve;

import com.ctre.phoenix6.hardware.Pigeon2;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.estimator.SwerveDrivePoseEstimator3d;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.math.kinematics.SwerveDriveKinematics;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.smartdashboard.Field2d;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;
import frc.robot.MotorController.ControllerGroup;
import frc.robot.Path.Coordinate;

public class Master {
    //The global x, y, and heading of the robot
    //TODO: remove
    private float[] XYH;
    //The modules, in the order RU, RD, LD, LU
    private Module[] modules;
    //The pigeon (used to get the heading)
    private Pigeon2 pigeon;
    //Estimates the robot's pose from the gyro, wheel odometry, and vision measurements
    private SwerveDrivePoseEstimator3d poseEstimator;

    private float[] TA;
    private float[] lastRPH;
    private float[] dRPH;

    public static Field2d field;

    private float poseEstimatorInitialRot;

    public static boolean useGlass = true;

    public float swerveFactor = 1f;

    private float lastUpdateTime = 0f;

    private boolean autoHappened = false;

    public Master(ControllerGroup fatControllerGroup) {
        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            float[] tempXYH = new float[]{
                (float) SmartDashboard.getNumber("Initial Position X: ", 0d),
                (float) SmartDashboard.getNumber("Initial Position Y: ", 0d)
            };

            XYH = new float[]{tempXYH[0], tempXYH[1], frc.robot.Constants.PIF / 2f};
            poseEstimatorInitialRot = frc.robot.Constants.PIF / 2f;
        } else {
            float[] tempXYH = new float[]{
                (float) SmartDashboard.getNumber("Initial Position X: ", 0d),
                (float) SmartDashboard.getNumber("Initial Position Y: ", 0d)
            };

            XYH = new float[]{tempXYH[0], tempXYH[1], 3f * frc.robot.Constants.PIF / 2f};
            poseEstimatorInitialRot = 3f * frc.robot.Constants.PIF / 2f;
        }

        modules = new Module[Constants.driveIds.length];
        modules[0] = new Module(fatControllerGroup, Constants.driveIds[0], Constants.driveInversions[0], Constants.turnIds[0], Constants.turnInversions[0], false, Constants.encoderOffsets[0], Constants.encoderConversionFactor, 5f, Constants.driveSystem[0], Constants.turnSystem[0], Constants.driveMotorControllers[0], true);
        //Reset positions since otherwise odometry will be wonky
        modules[0].resetPosition(XYH, XYH[2], Constants.moduleCentreAngle[0]);
        modules[1] = new Module(fatControllerGroup, Constants.driveIds[1], Constants.driveInversions[1], Constants.turnIds[1], Constants.turnInversions[1], false, Constants.encoderOffsets[1], Constants.encoderConversionFactor, 5f, Constants.driveSystem[1], Constants.turnSystem[1], Constants.driveMotorControllers[1], false);
        //Reset positions since otherwise odometry will be wonky
        modules[1].resetPosition(XYH, XYH[2], Constants.moduleCentreAngle[1]);
        modules[2] = new Module(fatControllerGroup, Constants.driveIds[2], Constants.driveInversions[2], Constants.turnIds[2], Constants.turnInversions[2], false, Constants.encoderOffsets[2], Constants.encoderConversionFactor, 5f, Constants.driveSystem[2], Constants.turnSystem[2], Constants.driveMotorControllers[2], true);
        //Reset positions since otherwise odometry will be wonky
        modules[2].resetPosition(XYH, XYH[2], Constants.moduleCentreAngle[2]);
        modules[3] = new Module(fatControllerGroup, Constants.driveIds[3], Constants.driveInversions[3], Constants.turnIds[3], Constants.turnInversions[3], false, Constants.encoderOffsets[3], Constants.encoderConversionFactor, 5f, Constants.driveSystem[3], Constants.turnSystem[3], Constants.driveMotorControllers[3], false);
        //Reset positions since otherwise odometry will be wonky
        modules[3].resetPosition(XYH, XYH[2], Constants.moduleCentreAngle[3]);

        //Creating the pigeon. Setting the update frequency is important to make sure it either actually updates or doesn't update too fast (I don't remember which)
        pigeon = new Pigeon2(Constants.pigeonId);
        pigeon.optimizeBusUtilization();
        pigeon.getRoll().setUpdateFrequency(50f);
        pigeon.getPitch().setUpdateFrequency(50f);
        pigeon.getYaw().setUpdateFrequency(50f);

        //Resets the pigeon so its current heading is zero
        pigeon.setYaw(Math.toDegrees(poseEstimatorInitialRot));

        Constants.rotationalController.enableContinuousInput(-frc.robot.Constants.PIF, frc.robot.Constants.PIF);
        Constants.angleController.enableContinuousInput(-frc.robot.Constants.PIF, frc.robot.Constants.PIF);

        poseEstimator = new SwerveDrivePoseEstimator3d(
            new SwerveDriveKinematics(new Translation2d[]{
                new Translation2d(Constants.moduleCentreDistance, new Rotation2d(Constants.moduleCentreAngle[0])),
                new Translation2d(Constants.moduleCentreDistance, new Rotation2d(Constants.moduleCentreAngle[1])),
                new Translation2d(Constants.moduleCentreDistance, new Rotation2d(Constants.moduleCentreAngle[2])),
                new Translation2d(Constants.moduleCentreDistance, new Rotation2d(Constants.moduleCentreAngle[3]))
            }), 
            new Rotation3d(Math.toRadians(pigeon.getRoll().getValueAsDouble()), Math.toRadians(pigeon.getPitch().getValueAsDouble()), Robot.isSimulation() ? XYH[2] : Math.toRadians(pigeon.getYaw().getValueAsDouble())), 
            new SwerveModulePosition[]{
                new SwerveModulePosition(modules[0].getTotalDistance(), new Rotation2d(modules[0].getPositionRadians())),
                new SwerveModulePosition(modules[1].getTotalDistance(), new Rotation2d(modules[1].getPositionRadians())),
                new SwerveModulePosition(modules[2].getTotalDistance(), new Rotation2d(modules[2].getPositionRadians())),
                new SwerveModulePosition(modules[3].getTotalDistance(), new Rotation2d(modules[3].getPositionRadians()))
            }, 
            new Pose3d(
                new Translation3d(XYH[0], XYH[1], 0f),
                new Rotation3d(0f, 0f, XYH[2])
            )
        );

        TA = new float[2];

        if(useGlass) {
            field = new Field2d();
            SmartDashboard.putData("Field", field);
        }

        lastRPH = new float[3];
        dRPH = new float[3];

        SmartDashboard.putNumber("Drive P: ", Constants.driveMotorControllers[0].getP());
        SmartDashboard.putNumber("Drive D: ", Constants.driveMotorControllers[0].getD());
    }

    public void setPosition() {
        float[] tempXYH = new float[]{
            (float) SmartDashboard.getNumber("Initial Position X: ", 0d),
            (float) SmartDashboard.getNumber("Initial Position Y: ", 0d)
        };

        Coordinate tempCoord = new Coordinate(tempXYH[0], tempXYH[1]);
        Coordinate currCoord = new Coordinate(XYH[0], XYH[1]);
        tempCoord.updateDistance(currCoord);

        if(tempCoord.getDistance() < 1f) {
            return;
        }

        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            XYH = new float[]{tempXYH[0], tempXYH[1], frc.robot.Constants.PIF / 2f};
            poseEstimatorInitialRot = frc.robot.Constants.PIF / 2f;
        } else {
            XYH = new float[]{tempXYH[0], tempXYH[1], 3f * frc.robot.Constants.PIF / 2f};
            poseEstimatorInitialRot = 3f * frc.robot.Constants.PIF / 2f;
        }

        poseEstimator.resetPosition(
            new Rotation3d(Math.toRadians(pigeon.getRoll().getValueAsDouble()), Math.toRadians(pigeon.getPitch().getValueAsDouble()), Robot.isSimulation() ? XYH[2] : Math.toRadians(pigeon.getYaw().getValueAsDouble())), 
            new SwerveModulePosition[]{
                new SwerveModulePosition(modules[0].getTotalDistance(), new Rotation2d(modules[0].getPositionRadians())),
                new SwerveModulePosition(modules[1].getTotalDistance(), new Rotation2d(modules[1].getPositionRadians())),
                new SwerveModulePosition(modules[2].getTotalDistance(), new Rotation2d(modules[2].getPositionRadians())),
                new SwerveModulePosition(modules[3].getTotalDistance(), new Rotation2d(modules[3].getPositionRadians()))
            }, 
            new Pose3d(
                new Translation3d(XYH[0], XYH[1], 0f),
                new Rotation3d(0f, 0f, XYH[2])
            )
        );
    }

    public void robotPeriodic(float[] apriltagPoseInfo) {
        SmartDashboard.putNumber("Swerve Factor: ", swerveFactor);
        SmartDashboard.putNumber("Pigeon Roll: ", pigeon.getRoll().getValueAsDouble());
        SmartDashboard.putNumber("Pigeon Pitch: ", pigeon.getPitch().getValueAsDouble());
        SmartDashboard.putNumber("Pigeon Yaw: ", pigeon.getYaw().getValueAsDouble());
        updateOdometry(apriltagPoseInfo);

        dRPH[0] = ((float) pigeon.getRoll().getValueAsDouble() - lastRPH[0]) / 0.02f;
        dRPH[1] = ((float) pigeon.getPitch().getValueAsDouble() - lastRPH[1]) / 0.02f;
        dRPH[2] = ((float) pigeon.getYaw().getValueAsDouble() - lastRPH[2]) / 0.02f;
        lastRPH[0] = (float) pigeon.getRoll().getValueAsDouble();
        lastRPH[1] = (float) pigeon.getPitch().getValueAsDouble();
        lastRPH[2] = (float) pigeon.getYaw().getValueAsDouble();

        for(int i = 0; i < modules.length; ++i) {
            modules[i].driveMotorController.setP(SmartDashboard.getNumber("Drive P: ", modules[i].driveMotorController.getP()));
            modules[i].driveMotorController.setD(SmartDashboard.getNumber("Drive D: ", modules[i].driveMotorController.getD()));
        }

        if(DriverStation.isAutonomous() && !DriverStation.isDisabled()) {
            autoHappened = true;
        }
    }

    //Updates wheel odometry
    private void updateOdometry(float[] apriltagPoseInfo) {
        for(int i = 0; i < modules.length; ++i) {
            modules[i].robotPeriodic("" + i);
            SmartDashboard.putNumber("Module " + i + " angle: ", modules[i].getPositionDegrees());
        }

        float previousX = XYH[0];
        float previousY = XYH[1];
        XYH[0] = 0f;
        XYH[1] = 0f;

        //XYH[2] calculations here and using XYH[2] in place of pigeon.getYaw().getValueAsfloat() in poseEstimator.updateWithTime() is for
        //SIMULATION PURPOSES ONLY!!!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        if(Robot.isSimulation() || 7 == 7) {
            for(int i = 0; i < modules.length; ++i) {
                //Need to store the previous frame's module positions for angle calculations
                float[] prevModulePosition = new float[modules[i].getModulePosition().length];
    
                //Storing prev modules positions for later. Need to do element by element copy since the modules[i].prevModulePosition array gets modified (like literally the next line below this loop)
                for(int j = 0; j < prevModulePosition.length; ++j) {
                    prevModulePosition[j] = modules[i].getModulePosition()[j];
                }
    
                //Updates module position to this frame
                float[] modulePosition = modules[i].calculatePosition(XYH[2]);
                XYH[0] += modulePosition[0] / 4f;
                XYH[1] += modulePosition[1] / 4f;

                //Angle calculation. Of the form (-module_x * delta_Py + module_y * delta_Px) / (numberModuls * moduleCentreDistance^2)
                XYH[2] += ((modulePosition[0] - previousX) * (modulePosition[1] - prevModulePosition[1]) - (modulePosition[1] - previousY) * (modulePosition[0] - prevModulePosition[0])) / (4d * Constants.moduleCentreDistance * Constants.moduleCentreDistance);
            }
        }

        poseEstimator.updateWithTime(
            Timer.getFPGATimestamp(), 
            new Rotation3d(Math.toRadians(pigeon.getRoll().getValueAsDouble()), Math.toRadians(pigeon.getPitch().getValueAsDouble()), Robot.isSimulation() ? XYH[2] : Math.toRadians(pigeon.getYaw().getValueAsDouble())), new SwerveModulePosition[]{
            new SwerveModulePosition(modules[0].getTotalDistance(), new Rotation2d(modules[0].getPositionRadians())),
            new SwerveModulePosition(modules[1].getTotalDistance(), new Rotation2d(modules[1].getPositionRadians())),
            new SwerveModulePosition(modules[2].getTotalDistance(), new Rotation2d(modules[2].getPositionRadians())),
            new SwerveModulePosition(modules[3].getTotalDistance(), new Rotation2d(modules[3].getPositionRadians()))
        });

        //Checks if we actually have a vision measurement
        if(apriltagPoseInfo[6] != 0) {
            apriltagPoseInfo[7] = (float) Math.sqrt(apriltagPoseInfo[7]);
            
            poseEstimator.addVisionMeasurement(
                new Pose3d(
                    new Translation3d(apriltagPoseInfo[0], apriltagPoseInfo[1], apriltagPoseInfo[2]), 
                    new Rotation3d(apriltagPoseInfo[3], apriltagPoseInfo[4], apriltagPoseInfo[5])
                ), 
                apriltagPoseInfo[6]
                //MatBuilder.fill(Nat.N4(), Nat.N1(), apriltagPoseInfo[7], apriltagPoseInfo[7], apriltagPoseInfo[7], 99d)
            );
        }

        TA[0] = (float) Math.sqrt((XYH[0] - (float) poseEstimator.getEstimatedPosition().getX()) * (XYH[0] - (float) poseEstimator.getEstimatedPosition().getX()) + (XYH[1] - (float) poseEstimator.getEstimatedPosition().getY()) * (XYH[1] - (float) poseEstimator.getEstimatedPosition().getY())) / 0.02f;
        TA[1] = frc.robot.Constants.atanLookup((float) poseEstimator.getEstimatedPosition().getY() - XYH[1], (float) poseEstimator.getEstimatedPosition().getX() - XYH[0]);

        XYH[0] = (float) poseEstimator.getEstimatedPosition().getX();
        XYH[1] = (float) poseEstimator.getEstimatedPosition().getY();

        if(Robot.isReal()) {
            XYH[2] = (float) Math.toRadians(pigeon.getYaw().getValueAsDouble());
        }

        //Resets the current module positions based on the new robot centre
        for(int i = 0; i < modules.length; ++i) {
            modules[i].resetPosition(XYH, XYH[2], Constants.moduleCentreAngle[i]);
        }

        SmartDashboard.putNumber("Robot X: ", XYH[0]);
        SmartDashboard.putNumber("Robot Y: ", XYH[1]);
        SmartDashboard.putNumber("Robot H: ", XYH[2]);

        SmartDashboard.putNumber("Robot T: ", TA[0]);
        SmartDashboard.putNumber("Robot A:", TA[1]);

        //System.out.println("(" + XYH[0] + ", " + XYH[1] + ")");

        if(useGlass) {
            field.setRobotPose(XYH[1], frc.robot.Path.Constants.fieldX - XYH[0], new Rotation2d(XYH[2] - Math.PI / 2d));
        }
    }

    public void teleopPeriodic(float[] swervePacket) {
        /*modules[0].driveMAXController.set(0.25f);

        if(7 == 7) {
            return;
        }*/

        //Checks if the button to reset the heading is being pressed
        if(swervePacket[4] == 1f) {
            pigeon.setYaw(Math.toDegrees(poseEstimatorInitialRot));
            this.reset();
        }

        if(swervePacket[5] != -1f) {
            if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
                swervePacket[5] += 180f;
            }

            swervePacket[5] += 90f;

            float dTheta = (float) Constants.rotationalController.calculate(XYH[2], Math.toRadians(swervePacket[5]));
            swervePacket[2] = Math.max(-1f, Math.min(1f, dTheta));
        }

        //Gets the pigeon angle, in degrees
        float pigeonAngle = (float) pigeon.getYaw().getValueAsDouble();
        //Converts this angle to radians, and puts in the range of -pi to pi
        pigeonAngle = (float) MathUtil.angleModulus(Math.toRadians(pigeonAngle));

        //SIMULATION PURPOSES ONLY!!!
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if(Robot.isSimulation()) {
            pigeonAngle = XYH[2];
        }

        //Since the supid drive joystick is rectangular instead of circular we have to limit the magnitude to (-1, 1)
        swervePacket[0] = Math.min(swerveFactor, Math.max(-swerveFactor, swervePacket[0]));
        //Adjust the magnitude rotation by a factor so the robot doesn't turn so fast
        swervePacket[2] *= Constants.rotationFactor;
        swervePacket[2] = Math.min(swerveFactor, Math.max(-swerveFactor, swervePacket[2]));

        //Need to multiply both the translation and rotation by the scaling factor
        swervePacket[0] *= swervePacket[3];

        if(swervePacket[5] == -1f) {
            swervePacket[2] *= swervePacket[3];
        }

        //Adjusts the translational and rotational magnitude so that the total magnitude will not exceed 1
        float adjustedTranslation = swervePacket[0] / (Math.abs(swervePacket[2]) + 1f);
        float adjustedRotation = swervePacket[2] / (Math.abs(swervePacket[0]) + 1f);

        SmartDashboard.putNumber("adjustedTranslation: ", adjustedTranslation);
        SmartDashboard.putNumber("ajustedRotation: ", adjustedRotation);

        //The angles the wheels want to be at if the bot was only rotating
        float[] rotationAngles = Constants.rotationAngles[0];

        //Adjust the translational angle by the pigeon's current angle
        swervePacket[1] -= pigeonAngle;

        //Storing the x and y components of the translation vector here since it is the same for all the wheels
        float translationX = frc.robot.Constants.cosLookup(swervePacket[1]) * adjustedTranslation;
        float translationY = frc.robot.Constants.sinLookup(swervePacket[1]) * adjustedTranslation;

        for(int i = 0; i < Constants.driveIds.length; ++i) {
            //Remember that cos(angle) * magnitude gets the x component of a vector, and sin(angle) * magnitude gets the y component of a vector
            float targetX = translationX + frc.robot.Constants.cosLookup(rotationAngles[i]) * adjustedRotation;
            float targetY = translationY + frc.robot.Constants.sinLookup(rotationAngles[i]) * adjustedRotation;
            //Use sqrt() instead of lookup here since when we are practicing driving in areas that aren't the field, we aren't guaranteed we'll be within the sqrt lookup's range
            float targetMagnitude = (float) Math.sqrt(targetX * targetX + targetY * targetY);
            float targetAngle = frc.robot.Constants.atanLookup(targetY, targetX);

            //Puts the target angle within the range -pi to pi, and creates an angle that is the opposite direction
            targetAngle = (float) MathUtil.angleModulus(targetAngle);
            float targetAngleOpposite = targetAngle + (targetAngle < 0 ? frc.robot.Constants.PIF : -frc.robot.Constants.PIF);

            SmartDashboard.putNumber("Target Angle " + i + ": ", Math.toDegrees(targetAngle));
            SmartDashboard.putNumber("Current Angle " + i + ": ", modules[i].getPositionDegrees());

            //The changes of the target angle from the current angle
            float targetChange = (float) MathUtil.angleModulus(targetAngle - modules[i].getPositionRadians());
            float targetOppositeChange = (float) MathUtil.angleModulus(targetAngleOpposite - modules[i].getPositionRadians());

            //If the wheel isn't going to move, don't waste time trying to turn to a certain angle
            if(targetMagnitude == 0f) {
                targetChange = 0f;
                targetOppositeChange = 0f;
            }

            //Checks if just going to the calculated target angle is easier
            if(Math.abs(targetChange) < Math.abs(targetOppositeChange)) {
                SmartDashboard.putNumber("Target Magnitude " + i + ": ", targetMagnitude);
                SmartDashboard.putNumber("Target Change " + i + ": ", Math.toDegrees(targetChange));
                SmartDashboard.putNumber("Target Turn Set " + i + ": ", targetChange / Constants.turnAngleDivisionFactor);
                //* cos() since cos() == 0 when angle == PI /2, and cos() == 1 when angle == 0, so essentially the farther the angleChange is from 0, the smaller the targetMagnitude set ends up being
                //This has the effect of making the wheel only move based on how "aligned" it is with it's target direction
                modules[i].set(targetMagnitude * frc.robot.Constants.cosLookup(targetChange), targetChange);
            } else {
                //If going to the angle opposite the target angle is easier, then we need to reverse the magnitude
                SmartDashboard.putNumber("Target Magnitude " + i + ": ", -targetMagnitude);
                SmartDashboard.putNumber("Target Change " + i + ": ", Math.toDegrees(targetOppositeChange));
                SmartDashboard.putNumber("Target Turn Set " + i + ": ", targetOppositeChange / Constants.turnAngleDivisionFactor);
                modules[i].set(-targetMagnitude * frc.robot.Constants.cosLookup(targetOppositeChange), targetOppositeChange);
            }
        }
    }

    //speedBoost should range from [0, 1]
    //TODO...? Maybe figure out how to have dTranslation and dTheta spread evenly over the entire "trip"? Not sure how necessary/useful doing that is though
    public void goTo(float desiredX, float desiredY, float desiredHeading, float speedBoost) {
        
        if(7 == 7) {
            desiredX = XYH[0];
            desiredHeading = poseEstimatorInitialRot;

            if(DriverStation.getAlliance().get().equals(Alliance.Blue)) {
                desiredY = XYH[1] - 0.25f;
            } else {
                desiredY = XYH[1] + 0.25f;
            }
        }

        //Calculates the translational change, and theta change using the PID controllers (which effectively prevent oscillation around the desired point)
        float dx = desiredX - XYH[0];
        float dy = desiredY - XYH[1];
        float dTheta = (float) Constants.rotationalController.calculate(XYH[2], desiredHeading) / Constants.rotationFactor;

        float desiredTranslation = (TA[0] + (float) Constants.translationalController.calculate(TA[0], Math.min(Constants.maxTranslationalSpeed * swerveFactor, frc.robot.Constants.sqrtLookup(dx * dx + dy * dy) / 0.02f))) / Constants.maxTranslationalSpeed;
        float desiredAngle = TA[1] + (float) Constants.angleController.calculate(TA[1], frc.robot.Constants.atanLookup(dy, dx));

        //System.out.println("DX: " + dx + ", DY: " + dy + ", dTheta: " + dTheta + ", dTran: " + desiredTranslation + ", dAngle: " + desiredAngle);

        teleopPeriodic(new float[]{desiredTranslation + speedBoost, desiredAngle, dTheta, 1f, 0f, -1f});
    }

    public float[] getXYH() {
        return XYH;
    }

    public float[] getTA() {
        return TA;
    }

    public void disabledPeriodic() {
        for(int i = 0; i < Constants.driveIds.length; ++i) {
            modules[i].disabledPeriodic();
        }
    }

    //TODO
    public boolean atPosition(float[] targetXYH) {
        return frc.robot.Constants.sqrtLookup((XYH[0] - targetXYH[0]) * (XYH[0] - targetXYH[0]) + (XYH[1] - targetXYH[1]) * (XYH[1] - targetXYH[1])) < 0.1f &&
        Math.abs((float) MathUtil.angleModulus(XYH[2] - targetXYH[2])) < 0.1f;
    }

    public float[] getPredictedXYH() {
        if(TA[0] <= 0.1f) {
            return XYH;
        } else {
            return new float[]{XYH[0] + 0.02f * Constants.maxTranslationalSpeed * frc.robot.Constants.cosLookup(TA[1]), XYH[1] + 0.02f * Constants.maxTranslationalSpeed * frc.robot.Constants.sinLookup(TA[1]), XYH[2]};
        }
    }

    public boolean tipping() {
        return Math.abs(pigeon.getPitch().getValueAsDouble()) > 15d || Math.abs(pigeon.getRoll().getValueAsDouble()) > 15d;
    }

    public void reset() {
        for(int i = 0; i < modules.length; ++i) {
            modules[i].reset();
        }
    }

    public boolean anyTilt() {
        return Math.abs(pigeon.getPitch().getValueAsDouble()) > 2.5d || Math.abs(pigeon.getRoll().getValueAsDouble()) > 2.5d
            || Math.abs(dRPH[0]) > 0.1f|| Math.abs(dRPH[1]) > 0.1f;
    }

    public double[] getRPH() {
        return new double[]{
            Math.toRadians(pigeon.getRoll().getValueAsDouble()),
            Math.toRadians(pigeon.getPitch().getValueAsDouble()),
            Math.toRadians(pigeon.getYaw().getValueAsDouble())
        };
    }

    public Pose3d getPose() {
        return poseEstimator.getEstimatedPosition();
    }
}

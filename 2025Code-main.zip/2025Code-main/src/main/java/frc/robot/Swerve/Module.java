package frc.robot.Swerve;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N2;
import edu.wpi.first.math.system.LinearSystemLoop;
import frc.robot.Robot;
import frc.robot.MotorController.FlexVortexController;
import frc.robot.MotorController.MAXVortexController;
import frc.robot.MotorController.ControllerGroup;

public class Module {
    private FlexVortexController driveController;
    public MAXVortexController driveMAXController;
    private boolean useMaxDrive;
    private FlexVortexController turnController;
    private ControllerGroup moduleControllerGroup;

    //The total position traveled by the wheel, in metres
    private float prevLinearPosition;
    //The global x,y position of the module
    private float[] prevModulePosition;
    public PIDController driveMotorController;

    public Module(ControllerGroup fatControllerGroup, int driveId, boolean driveInversion, int turnId, boolean turnInversion, boolean absoluteInverted, float absoluteOffset, float absoluteConversionFactor, float absoluteRange, LinearSystemLoop<N2, N1, N2> driveSystem, LinearSystemLoop<N2, N1, N2> turnSystem, PIDController driveMotorController, boolean useMaxDrive) {
        this.useMaxDrive = useMaxDrive;
        
        if(!useMaxDrive) {
            driveController = new FlexVortexController(driveId, driveInversion, driveSystem, Constants.driveMotorSystem);
        } else {
            driveMAXController = new MAXVortexController(driveId, driveInversion, driveSystem, Constants.driveMotorSystem);
        }

        turnController = new FlexVortexController(turnId, turnInversion, absoluteInverted, absoluteOffset, absoluteConversionFactor, absoluteRange, turnSystem, Constants.turnMotorSystem, true, 0);

        if(!useMaxDrive) {
            moduleControllerGroup = new ControllerGroup(new FlexVortexController[]{driveController, turnController});
    
            fatControllerGroup.add(new FlexVortexController[]{driveController, turnController});
        } else {
            fatControllerGroup.add(driveMAXController);
            fatControllerGroup.add(turnController);
        }

        prevLinearPosition = getTotalDistance();
        prevModulePosition = new float[]{0f, 0f};

        this.driveMotorController = driveMotorController;
    }

    public void robotPeriodic(String corner) {
        if(!useMaxDrive) {
            moduleControllerGroup.robotPeriodic(new String[]{"Drive " + corner, "Turn " + corner});
        } else {
            driveMAXController.robotPeriodic("Drive: " + corner);
            turnController.robotPeriodic("Turn: " + corner);
        }
    }

    //Returns the position, in degrees
    public float getPositionDegrees() {
        return turnController.getPositionModulus(frc.robot.Constants.PIF, 7f / 150f) * 180f / frc.robot.Constants.PIF;
    }

    //Gets the position, in radians
    public float getPositionRadians() {
        return turnController.getPositionUnwrapped() * 7f / 150f;
    }

    //Sets the module to a desired speed and angle change, in radians
    public void set(float targetPercentage, float targetAngleChange) {
        //TODO: Move gearing into Controller.java apparently? Ideally in the set() and loopPosition() methods, otherwise add member and then do the division (seen below) inside the methods instead
        if(!useMaxDrive) {
            if(Robot.isReal()) {
                targetPercentage = (float) driveController.getAppliedOutput() + (float) driveMotorController.calculate(driveController.getAppliedOutput(), targetPercentage);
            } else {
                targetPercentage = (float) driveController.sim.getAppliedOutput() + (float) driveMotorController.calculate(driveController.sim.getAppliedOutput(), targetPercentage);
            }

            driveController.set(targetPercentage);
        } else {
            if(Robot.isReal()) {
                targetPercentage = (float) driveMAXController.getAppliedOutput() + (float) driveMotorController.calculate(driveMAXController.getAppliedOutput(), targetPercentage);
            } else {
                targetPercentage = (float) driveMAXController.sim.getAppliedOutput() + (float) driveMotorController.calculate(driveMAXController.sim.getAppliedOutput(), targetPercentage);
            }

            driveMAXController.set(targetPercentage);
        }

        //driveController.desiredVoltageFromPercentage(targetPercentage / 6.12f);
        turnController.desiredVoltageFromPositionChange(targetAngleChange / (7f / 150f));
    }

    public void disabledPeriodic() {
        if(!useMaxDrive) {
            moduleControllerGroup.stopMotor();
        } else {
            driveMAXController.stopMotor();
            turnController.stopMotor();
        }
    }

    public float getTotalDistance() {
        if(!useMaxDrive) {
            return driveController.getPositionUnwrapped() * Constants.driveLinearConversionFactor * (Robot.isSimulation() ? Constants.maxTranslationalSpeed / 5f : 1f);
        } else {
            return driveMAXController.getPositionUnwrapped() * Constants.driveLinearConversionFactor * (Robot.isSimulation() ? Constants.maxTranslationalSpeed / 5f : 1f);
        }
    }

    public float[] getModulePosition() {
        return prevModulePosition;
    }

    //Where robotAngle is in radians
    public float[] calculatePosition(float robotAngle) {
        //Get the current drive wheel position, in metres
        float currLinearPosition = getTotalDistance();

        //Multiply the change in metres of the drive wheel by the x component of the wheel's angle
        prevModulePosition[0] += (currLinearPosition - prevLinearPosition) * frc.robot.Constants.cosLookup(getPositionRadians() + robotAngle);
        //Above but for the y component
        prevModulePosition[1] += (currLinearPosition - prevLinearPosition) * frc.robot.Constants.sinLookup(getPositionRadians() + robotAngle);

        prevLinearPosition = currLinearPosition;

        return prevModulePosition;
    }

    //Resets the wheel position about a new centre
    public void resetPosition(float[] centre, float robotAngle, float moduleCentreAngle) {
        prevModulePosition[0] = centre[0] + Constants.moduleCentreDistance * frc.robot.Constants.cosLookup(robotAngle + moduleCentreAngle);
        prevModulePosition[1] = centre[1] + Constants.moduleCentreDistance * frc.robot.Constants.sinLookup(robotAngle + moduleCentreAngle);
    }

    public void reset() {
        turnController.reset();
    }
}

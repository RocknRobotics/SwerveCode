package frc.robot.MotorController;

import com.revrobotics.sim.SparkMaxSim;
import com.revrobotics.spark.SparkMax;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N2;
import edu.wpi.first.math.system.LinearSystemLoop;
import edu.wpi.first.math.system.plant.DCMotor;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;

public class ElevatorController extends SparkMax {
    //The encoder object associated with this motor controller. May be relative if no external encoders are connected, or absolute if an absolute encoder is connected
    private Encoder encoder;
    //The voltage the motor wants to be set to
    public float desiredVoltage;
    //SIMULATION PURPOSES ONLY!!!
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public SparkMaxSim sim;

    private float thisAccel;

    //Creates a motor controller from its id, whether to invert it, and a passed motor type. No absolute encoder.
    public ElevatorController(int controllerId, boolean inverted) {
        super(controllerId, MotorType.kBrushless);
        desiredVoltage = 0f;

        this.setCANTimeout(50);
        this.setCANMaxRetries(5);
        this.setControlFramePeriodMs(10);
        this.setPeriodicFrameTimeout(50);
        this.configure(frc.robot.Constants.baseMaxConfig.inverted(inverted), ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);

        //SIMULATION PURPOSES ONLY!!!
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if(Robot.isSimulation()) {
            sim = new SparkMaxSim(this, DCMotor.getNEO(1));
        }

        encoder = new Encoder(this);
    }

    //Updates the position, velocity, and acceleration of the encoder
    public void robotPeriodic(String name) {
        float thisVel = encoder.getVelocity();
        encoder.robotPeriodic();

        SmartDashboard.putNumber(name + " position: ", getPosition());
        SmartDashboard.putNumber(name + " position unwrapped: ", getPositionUnwrapped());
        SmartDashboard.putNumber(name + " velocity: ", getVelocity());
        SmartDashboard.putNumber(name + " desiredVoltage: ", desiredVoltage);

        thisAccel = (encoder.getVelocity() - thisVel) / 0.02f;
    }

    //Does this really need a comment?
    public float getDesiredVoltage() {
        return desiredVoltage;
    }

    public void desiredVoltageFromBottom(ElevatorController other, LinearSystemLoop<N2, N1, N2> loop) {
        if(Math.abs(thisAccel) < 0.05f && Math.abs(other.thisAccel) < 0.05f 
        && Math.abs(this.getVelocity()) < 0.05f && Math.abs(other.getVelocity()) < 0.05f
        && this.getPositionUnwrapped() < 0.05f && other.getPositionUnwrapped() < 0.05f
        && this.getDesiredVoltage() < 0.35f && other.getDesiredVoltage() < 0.35f) {
            this.setPosition(0f);
            other.setPosition(0f);
        }

        if(Math.abs((this.getPositionUnwrapped() + other.getPositionUnwrapped()) / 4f) < 0.002f) {
            this.stopMotor();
            other.stopMotor();
        } else {
            desiredVoltageFromPositionChange(-(this.getPositionUnwrapped() + other.getPositionUnwrapped()) / 5f, other, loop);
        }
    }

    //Gets the desired voltage from a desired position change
    public void desiredVoltageFromPositionChange(float positionChange, ElevatorController other, LinearSystemLoop<N2, N1, N2> loop) {
        //See above method. Does the same but with the position. Since we (presumably) want to stay at the desired position, the desired velocity is 0.
        loop.setNextR(MatBuilder.fill(Nat.N2(), Nat.N1(), positionChange + (this.getPositionUnwrapped() + other.getPositionUnwrapped()) / 2f, (positionChange / 0.02d + 9.81f * 0.02f) * frc.robot.Elevator.Constants.magicJohnson));
        loop.predict(0.02f);
        desiredVoltage = ((float) loop.getU().get(0, 0) + desiredVoltage) / 2f;
        other.desiredVoltage = this.desiredVoltage;
    }

    //Gets the desired voltage from a desired position (position can be in any range)
    public void desiredVoltageFromPosition(float position, ElevatorController other, LinearSystemLoop<N2, N1, N2> loop) {
        desiredVoltageFromPositionChange((position - (this.getPositionUnwrapped() + other.getPositionUnwrapped()) / 2f) / 2f, other, loop);
    }

    public float getPositionUnwrapped() {
        if(Robot.isSimulation()) {
            return (float) sim.getPosition() * (2f * frc.robot.Constants.PIF) * (float) Units.inchesToMeters(0.75f) / 10.71f;
        }

        return encoder.getPositionUnwrapped() * (float) Units.inchesToMeters(0.75f) / 10.71f;
    }

    public float getPositionModulus(float modulus, float conversionFactor) {
        return encoder.getPositionModulus(modulus, conversionFactor);
    }

    //Gets the position of the motor's encoder
    public float getPosition() {
        if(Robot.isSimulation()) {
            return encoder.applyModulus((float) sim.getPosition()) * (2f * frc.robot.Constants.PIF) * (float) Units.inchesToMeters(0.75f) / 10.71f;
        }

        return encoder.getPosition() * (float) Units.inchesToMeters(0.75f) / 10.71f;
    }

    //Gets the velocity of the motor's encoder
    public float getVelocity() {
        if(Robot.isSimulation()) {
            return (float) sim.getVelocity() / 60f * (2f * frc.robot.Constants.PIF) * (float) Units.inchesToMeters(0.75f) / 10.71f;
        }

        return encoder.getVelocity() * (float) Units.inchesToMeters(0.75f) / 10.71f;
    }

    public void stopMotor() {
        desiredVoltage = 0f;
        super.set(0d);
    }

    public void setPosition(float position) {
        encoder.setPosition(position);
    }

    public void set(float f) {
        desiredVoltage = ControllerGroup.currentBatteryVoltage * f;
    }
}
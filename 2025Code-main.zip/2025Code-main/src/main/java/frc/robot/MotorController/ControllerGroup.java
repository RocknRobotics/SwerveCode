package frc.robot.MotorController;

import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.RobotController;
import edu.wpi.first.wpilibj.simulation.BatterySim;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Subsystem;
import frc.robot.Robot;

//Provides an easier interface for using many related motor controllers
public class ControllerGroup implements Subsystem {
    //The group of motor controllers
    private FlexVortexController[] group;
    //Group of any Elevator controllers
    private ElevatorController[] elevatorGroup;
    private MAXVortexController[] maxGroup;
    //The estimated actual current battery voltage of the robot (without voltage drops included)
    public static float currentBatteryVoltage = (float) RobotController.getBatteryVoltage();

    public ControllerGroup(FlexVortexController[] group) {
        this.group = group;
        elevatorGroup = new ElevatorController[0];
        maxGroup = new MAXVortexController[0];
    }

    public ControllerGroup(ElevatorController[] elevatorGroup) {
        group = new FlexVortexController[0];
        this.elevatorGroup = elevatorGroup;
        maxGroup = new MAXVortexController[0];
    }

    public void add(MAXVortexController controller) {
        add(new MAXVortexController[]{controller});
    }

    public void add(MAXVortexController[] controllers) {
        MAXVortexController[] newGroup = new MAXVortexController[maxGroup.length + controllers.length];

        for(int i = 0; i < maxGroup.length; ++i) {
            newGroup[i] = maxGroup[i];
        }

        for(int i = maxGroup.length; i < newGroup.length; ++i) {
            newGroup[i] = controllers[i - maxGroup.length];
        }

        maxGroup = newGroup;
    }

    //Adds a controller to this controller group
    public void add(FlexVortexController controller) {
        add(new FlexVortexController[]{controller});
    }

    //Adds a group of controllers to this controller group
    public void add(FlexVortexController[] controllers) {
        FlexVortexController[] newGroup = new FlexVortexController[group.length + controllers.length];

        for(int i = 0; i < group.length; ++i) {
            newGroup[i] = group[i];
        }

        for(int i = group.length; i < newGroup.length; ++i) {
            newGroup[i] = controllers[i - group.length];
        }

        group = newGroup;
    }

    public void add(ElevatorController maxController) {
        add(new ElevatorController[]{maxController});
    }

    public void add(ElevatorController[] maxControllers) {
        ElevatorController[] newGroup = new ElevatorController[elevatorGroup.length + maxControllers.length];

        for(int i = 0; i < elevatorGroup.length; ++i) {
            newGroup[i] = elevatorGroup[i];
        }

        for(int i = elevatorGroup.length; i < newGroup.length; ++i) {
            newGroup[i] = maxControllers[i - elevatorGroup.length];
        }

        elevatorGroup = newGroup;
    }

    //Runs the robotPeriodic() of all the Controllers
    public void robotPeriodic(String[] names) {
        for(int i = 0; i < group.length; ++i) {
            group[i].robotPeriodic(names[i]);
        }

        for(int i = 0; i < elevatorGroup.length; ++i) {
            elevatorGroup[i].robotPeriodic(names[i + group.length]);
        }
    }

    //Sets all motor controllers in the group to the same speed
    public void set(float targetSpeed) {
        float[] targetSpeeds = new float[group.length + elevatorGroup.length];

        for(int i = 0; i < targetSpeeds.length; ++i) {
            targetSpeeds[i] = targetSpeed;
        }

        set(targetSpeeds);
    }

    //Sets the motor controllers in the group to different speeds. The input float array length must match the motor controller group size
    public void set(float[] targetSpeeds) {
        for(int i = 0; i < group.length; ++i) {
            group[i].set(targetSpeeds[i]);
        }

        for(int i = 0; i < elevatorGroup.length; ++i) {
            elevatorGroup[i].set(targetSpeeds[i + group.length]);
        }
    }

    //Stops all the motor controllers in the group
    public void stopMotor() {
        for(int i = 0; i < group.length; ++i) {
            group[i].stopMotor();
        }

        for(int i = 0; i < elevatorGroup.length; ++i) {
            elevatorGroup[i].stopMotor();
        }

        for(int i = 0; i < maxGroup.length; ++i) {
            maxGroup[i].stopMotor();
        }
    }

    public void limitVoltage() {
        for(int i = 0; i < group.length; ++i) {
            group[i].setVoltage(group[i].desiredVoltage);
        }

        for(int i = 0; i < elevatorGroup.length; ++i) {
            elevatorGroup[i].setVoltage(elevatorGroup[i].desiredVoltage);
        }

        for(int i = 0; i < maxGroup.length; ++i) {
            if (maxGroup[i].controllerId == 1) {
                //System.out.println("hi from 1: " + maxGroup[i].desiredVoltage);
            }
            maxGroup[i].setVoltage(maxGroup[i].desiredVoltage);
        }

        if(7 == 7) {
            return;
        }

        //Updates the current battery voltage
        currentBatteryVoltage = (float) RobotController.getBatteryVoltage();

        if(Robot.isSimulation()) {
            currentBatteryVoltage = (float) BatterySim.calculateLoadedBatteryVoltage(12d, frc.robot.Constants.batteryResistance, getCurrent());
        }

        currentBatteryVoltage += frc.robot.Constants.batteryResistance * getCurrent();

        //Seems to work better than trying to calculate the current battery voltage :/
        currentBatteryVoltage = 12f;

        SmartDashboard.putNumber("Current Battery Voltage: ", currentBatteryVoltage);

        //What we are going to multiply every voltage by. Will be 0 < scaling < 1.
        float voltageScalingFactor = 0f;
        float motorVoltageSum = 0f;

        for(int i = 0; i < group.length; ++i) {
            //Need to abs() since voltages may be negative, when really all the negative is doing is signifying direction (sign does not affect power draw)
            //group[i].desiredVoltage = group[i].getDesiredVoltage()));
            motorVoltageSum += Math.abs(group[i].getDesiredVoltage());
        }

        for(int i = 0; i < elevatorGroup.length; ++i) {
            //Need to abs() since voltages may be negative, when really all the negative is doing is signifying direction (sign does not affect power draw)
            //elevatorGroup[i].desiredVoltage = group[i].getDesiredVoltage()));
            motorVoltageSum += Math.abs(elevatorGroup[i].getDesiredVoltage());
        }

        for(int i = 0; i < maxGroup.length; ++i) {
            //Need to abs() since voltages may be negative, when really all the negative is doing is signifying direction (sign does not affect power draw)
            //maxGroup[i].desiredVoltage = group[i].getDesiredVoltage()));
            motorVoltageSum += Math.abs(maxGroup[i].getDesiredVoltage());
        }

        //Prevents division by 0 shenanigans
        if(motorVoltageSum <= 0.1d) {
            //Just set everything to what it wants, since if your voltage sum is less than 0.1 AND you still need to scale down, then you are cooked beyond well done
            for(int i = 0; i < group.length; ++i) {
                group[i].setVoltage(group[i].getDesiredVoltage());
                //SIMULATION PURPOSES ONLY!!!
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                if(Robot.isSimulation()) {
                    group[i].sim.iterate(6784d / 12f * group[i].getDesiredVoltage(), currentBatteryVoltage, 0.02f);
                    group[i].DCsim.setInputVoltage(group[i].getDesiredVoltage());
                    group[i].DCsim.update(0.02d);
                }
            }

            for(int i = 0; i < elevatorGroup.length; ++i) {
                elevatorGroup[i].setVoltage(elevatorGroup[i].getDesiredVoltage());
                //SIMULATION PURPOSES ONLY!!!
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                if(Robot.isSimulation()) {
                    elevatorGroup[i].sim.iterate(5676d / 12d * elevatorGroup[i].getDesiredVoltage(), currentBatteryVoltage, 0.02d);
                }
            }

            for(int i = 0; i < maxGroup.length; ++i) {
                maxGroup[i].setVoltage(maxGroup[i].getDesiredVoltage());
                //SIMULATION PURPOSES ONLY!!!
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                if(Robot.isSimulation()) {
                    maxGroup[i].sim.iterate(6784d / 12f * maxGroup[i].getDesiredVoltage(), currentBatteryVoltage, 0.02f);
                    maxGroup[i].DCsim.setInputVoltage(maxGroup[i].getDesiredVoltage());
                    maxGroup[i].DCsim.update(0.02d);
                }
            }

            return;
        }

        for(int i = 0; i < group.length; ++i) {
            voltageScalingFactor += (((currentBatteryVoltage - frc.robot.Constants.batteryMinimumVoltage) //The maximum allowable voltage drop.
            * ((float) frc.robot.Constants.neoVortexMotor.rOhms) / frc.robot.Constants.batteryResistance) //The motor's internal resistance divided by the battery resistance. Lowkey just happened as a result of rearranging the equation
            + ((Math.signum(group[i].getVelocity()) == Math.signum(group[i].getDesiredVoltage()) ? Math.abs(group[i].getVelocity()) : 0f) / (float) frc.robot.Constants.neoVortexMotor.KvRadPerSecPerVolt)) //The sum of all the motor velocities, divided by K_v. Effectively, this converts all motor velocities to the corresponding voltage. 
            //Essentially, this (above) term means that as motor velocity increases, the less current needed to sustain that velocity, leading to less power drawn from the battery, so the more voltage we have available if we want to increase the speed more.
            / motorVoltageSum; //Divide everything by the sum of the voltages. As this increases (i.e. we try to run more things and/or faster), the more the scaling factor decreases.
        }

        for(int i = 0; i < elevatorGroup.length; ++i) {
            voltageScalingFactor += (((currentBatteryVoltage - frc.robot.Constants.batteryMinimumVoltage) //The maximum allowable voltage drop.
            * ((float) frc.robot.Constants.neoMotor.rOhms) / frc.robot.Constants.batteryResistance) //The motor's internal resistance divided by the battery resistance. Lowkey just happened as a result of rearranging the equation
            + ((Math.signum(elevatorGroup[i].getVelocity()) == Math.signum(elevatorGroup[i].getDesiredVoltage()) ? Math.abs(elevatorGroup[i].getVelocity() / ((float) Units.inchesToMeters(0.75d) / 10.71f)) : 0f) / (float) frc.robot.Constants.neoMotor.KvRadPerSecPerVolt)) //The sum of all the motor velocities, divided by K_v. Effectively, this converts all motor velocities to the corresponding voltage. 
            //Essentially, this (above) term means that as motor velocity increases, the less current needed to sustain that velocity, leading to less power drawn from the battery, so the more voltage we have available if we want to increase the speed more.
            / motorVoltageSum; //Divide everything by the sum of the voltages. As this increases (i.e. we try to run more things and/or faster), the more the scaling factor decreases.
        }

        for(int i = 0; i < maxGroup.length; ++i) {
            voltageScalingFactor += (((currentBatteryVoltage - frc.robot.Constants.batteryMinimumVoltage) //The maximum allowable voltage drop.
            * ((float) frc.robot.Constants.neoVortexMotor.rOhms) / frc.robot.Constants.batteryResistance) //The motor's internal resistance divided by the battery resistance. Lowkey just happened as a result of rearranging the equation
            + ((Math.signum(maxGroup[i].getVelocity()) == Math.signum(maxGroup[i].getDesiredVoltage()) ? Math.abs(maxGroup[i].getVelocity()) : 0f) / (float) frc.robot.Constants.neoVortexMotor.KvRadPerSecPerVolt)) //The sum of all the motor velocities, divided by K_v. Effectively, this converts all motor velocities to the corresponding voltage. 
            //Essentially, this (above) term means that as motor velocity increases, the less current needed to sustain that velocity, leading to less power drawn from the battery, so the more voltage we have available if we want to increase the speed more.
            / motorVoltageSum; //Divide everything by the sum of the voltages. As this increases (i.e. we try to run more things and/or faster), the more the scaling factor decreases.
        }
        
        SmartDashboard.putNumber("Voltage Scaling Factor: ", voltageScalingFactor);
        //Make sure it doesn't exceed 1 (since we can't magically increase voltage) or go below 0 (since that would just have plain wrong effects. Shouldn't ever go below 0 though).
        voltageScalingFactor = Math.max(0f, Math.min(1f, voltageScalingFactor));

        //Set everything to its desired voltage, scaled
        for(int i = 0; i < group.length; ++i) {
            group[i].setVoltage(voltageScalingFactor * group[i].getDesiredVoltage());
            //SIMULATION PURPOSES ONLY!!!
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            if(Robot.isSimulation()) {
                group[i].sim.iterate(6784d / 12f * voltageScalingFactor * group[i].getDesiredVoltage(), currentBatteryVoltage, 0.02f);
                group[i].DCsim.setInputVoltage(voltageScalingFactor * group[i].getDesiredVoltage());
                group[i].DCsim.update(0.02d);
            }
        }

        for(int i = 0; i < elevatorGroup.length; ++i) {
            elevatorGroup[i].setVoltage(voltageScalingFactor * elevatorGroup[i].getDesiredVoltage());
            //SIMULATION PURPOSES ONLY!!!
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            if(Robot.isSimulation()) {
                elevatorGroup[i].sim.iterate(5676d / 12f * voltageScalingFactor * elevatorGroup[i].getDesiredVoltage(), currentBatteryVoltage, 0.02f);
            }
        }

        for(int i = 0; i < maxGroup.length; ++i) {
            maxGroup[i].setVoltage(voltageScalingFactor * maxGroup[i].getDesiredVoltage());
            //SIMULATION PURPOSES ONLY!!!
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            if(Robot.isSimulation()) {
                maxGroup[i].sim.iterate(6784d / 12f * voltageScalingFactor * maxGroup[i].getDesiredVoltage(), currentBatteryVoltage, 0.02f);
                maxGroup[i].DCsim.setInputVoltage(voltageScalingFactor * maxGroup[i].getDesiredVoltage());
                maxGroup[i].DCsim.update(0.02d);
            }
        }
    }

    //Gets the total current of all the motors
    public float getCurrent() {
        float totalCurrent = 0f;

        for(int i = 0; i < group.length; ++i) {
            totalCurrent += Math.abs(group[i].getCurrent() * (group[i].getBusVoltage() / 12f));
        }

        if(Robot.isReal()) {
            for(int i = 0; i < elevatorGroup.length; ++i) {
                totalCurrent += Math.abs(elevatorGroup[i].getOutputCurrent() * (elevatorGroup[i].getBusVoltage() / 12f));
            }
        } else {
            totalCurrent += frc.robot.Elevator.Master.elevatorSim.getCurrentDrawAmps();
        }

        return totalCurrent;
    }
}

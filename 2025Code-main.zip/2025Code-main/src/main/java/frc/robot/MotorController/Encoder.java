package frc.robot.MotorController;

import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkAnalogSensor;
import com.revrobotics.spark.SparkBase;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.DutyCycleEncoder;
import frc.robot.Robot;

public class Encoder {
    //The relative encoder of the motor attached to the SparkFlex, in case the getPosition() and/or getVelocity() methods still need to be used
    private RelativeEncoder relativeEncoder;
    //adding variable to store -> getPositionUnwrapped() "relativeEncoder.get()*(2*frc.robot.Constants.PIF)"
    private float positionUnwrapped;
    //Stores the position and velocity of the encoder
    private float[] positions;
    private SparkAnalogSensor temp;
    private float offset;

    //Creates a relative Encoder for a motor controller. Uses the relative encoder since no absolute encoder arguements were passed
    public Encoder(SparkBase controller) {
        relativeEncoder = controller.getEncoder();
        
        positionUnwrapped = (float) relativeEncoder.getPosition() * (2f * frc.robot.Constants.PIF);
        positions = new float[]{applyModulus(positionUnwrapped), (float) relativeEncoder.getVelocity() * (2f * frc.robot.Constants.PIF) / 60f};
    }

    //Creates an absolute Encoder for a motor controller, using the connected encoder of the encoder type passed as an argument
    //Used for analog encoders connected via ten-pins
    public Encoder(SparkBase controller, boolean absoluteInverted, float absoluteOffset, float absoluteConversionFactor, float absoluteRange, boolean analog, int dutyId) {
        relativeEncoder = controller.getEncoder();

        //Sets the absoluteEncoder object according to the encoderType connected
        float absolutePosition = 0f;

        if(Robot.isReal()) {
            if(analog) {
                absolutePosition = (float) controller.getAnalog().getPosition();
                temp = controller.getAnalog();
                System.out.println(absolutePosition);
            } else {
                DutyCycleEncoder dutyEncoder = new DutyCycleEncoder(new DigitalInput(dutyId), 100d, 0d);
                absolutePosition = (float) dutyEncoder.get();
                absolutePosition = 0f;
                System.out.println("Duty: " + absolutePosition);
                System.out.println("Connected: " + dutyEncoder.isConnected());
            }

            offset = absoluteOffset;

            //System.out.println(absolutePosition);

            absolutePosition -= absoluteOffset;

            if(absoluteInverted) {
                absolutePosition = absoluteRange - absolutePosition;
            }
    
            relativeEncoder.setPosition(absolutePosition * absoluteConversionFactor);
    
            positionUnwrapped = (float) absolutePosition * (2f * frc.robot.Constants.PIF);
            positions = new float[]{applyModulus(positionUnwrapped), (float) relativeEncoder.getVelocity() * (2f * frc.robot.Constants.PIF) / 60f};
        } else {
            positionUnwrapped = 0f;
            positions = new float[]{applyModulus(positionUnwrapped), (float) relativeEncoder.getVelocity() * (2f * frc.robot.Constants.PIF) / 60f};
        }
    }

    //Updates the position and velocity of the encoder
    public void robotPeriodic() {
        positionUnwrapped = (float) relativeEncoder.getPosition() * (2f * frc.robot.Constants.PIF);
        positions = new float[]{applyModulus(positionUnwrapped), (float) relativeEncoder.getVelocity() * (2f * frc.robot.Constants.PIF) / 60f};
    }

    //Puts position in the range -pi, pi
    public float applyModulus(float position) {
        while(position <= frc.robot.Constants.PIF) {
            position += 2 * frc.robot.Constants.PIF;
        }

        while(position > frc.robot.Constants.PIF) {
            position -= 2 * frc.robot.Constants.PIF;
        }

        return position;
    }

    //In case we need a specific conversion and modulus?
    public float getPositionModulus(float modulus, float conversionFactor) {
        float positionModulus = positionUnwrapped * conversionFactor;

        while(positionModulus <= modulus) {
            positionModulus += 2 * modulus;
        }

        while(positionModulus > modulus) {
            positionModulus -= 2 * modulus;
        }

        return positionModulus;
    }

    //Might get a position... ngl I'm really not sure -\(-.-)/-
    //Gets position without any range (as opposed to getPosition(), which limits the position to -pi, pi)
    public float getPositionUnwrapped() {
        return positionUnwrapped;
    }

    //Gets the position of the encoder
    public float getPosition() {
        return positions[0];
    }

    //Gets the velocity of the encoder.
    public float getVelocity() {
        return positions[1];
    }

    public void setPosition(float position) {
        relativeEncoder.setPosition(0f);
    }

    public void reset() {
        if(Robot.isReal()) {
            relativeEncoder.setPosition((temp.getPosition() - offset) * frc.robot.Swerve.Constants.encoderConversionFactor);
            positionUnwrapped = (float) (temp.getPosition() - offset) * (2f * frc.robot.Constants.PIF);
            positions = new float[]{applyModulus(positionUnwrapped), (float) relativeEncoder.getVelocity() * (2f * frc.robot.Constants.PIF) / 60f};
        }
    }
}
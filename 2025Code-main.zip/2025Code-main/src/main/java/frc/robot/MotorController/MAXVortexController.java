package frc.robot.MotorController;

import com.revrobotics.sim.SparkMaxSim;
import com.revrobotics.spark.SparkMax;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N2;
import edu.wpi.first.math.system.LinearSystem;
import edu.wpi.first.math.system.LinearSystemLoop;
import edu.wpi.first.wpilibj.simulation.DCMotorSim;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;

public class MAXVortexController extends SparkMax {
    //The encoder object associated with this motor controller. May be relative if no external encoders are connected, or absolute if an absolute encoder is connected
    private Encoder encoder;
    //State-space woohoo
    //<States, Inputs, Outputs>
    //<[angular position, angular velocity] (rads, rads/s), [voltage] (volts), [angular position, angular velocity] (rads, rads/s)>
    private LinearSystemLoop<N2, N1, N2> loop;
    //The voltage the motor wants to be set to
    public float desiredVoltage;
    //SIMULATION PURPOSES ONLY!!!
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public SparkMaxSim sim;
    public DCMotorSim DCsim;
    public int controllerId;

    //Creates a motor controller from its id, whether to invert it, and a passed motor type. No absolute encoder.
    public MAXVortexController(int controllerId, boolean inverted, LinearSystemLoop<N2, N1, N2> loop, LinearSystem<N2, N1, N2> simPlant) {
        super(controllerId, MotorType.kBrushless);
        this.controllerId = controllerId;
        encoder = new Encoder(this);
        this.loop = loop;
        desiredVoltage = 0f;

        this.setCANTimeout(50);
        this.setCANMaxRetries(5);
        this.setControlFramePeriodMs(10);
        this.setPeriodicFrameTimeout(50);
        this.configure(frc.robot.Constants.baseMaxConfig.inverted(inverted), ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);

        //SIMULATION PURPOSES ONLY!!!
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if(Robot.isSimulation()) {
            sim = new SparkMaxSim(this, frc.robot.Constants.neoVortexMotor);
            DCsim = new DCMotorSim(simPlant, frc.robot.Constants.neoVortexMotor, 0.001d, 0.01d);
        }
    }

    //Creates a motor controller from its id, whether to invert it, and a passed motor type. Has an absolute encoder that requires a type and an offset.
    public MAXVortexController(int controllerId, boolean inverted, boolean absoluteInverted, float absoluteOffset, float absoluteConversionFactor, float absoluteRange, LinearSystemLoop<N2, N1, N2> loop, LinearSystem<N2, N1, N2> simPlant, boolean analog, int dutyId) {
        super(controllerId, MotorType.kBrushless);
        this.controllerId = controllerId;
        encoder = new Encoder(this, absoluteInverted, absoluteOffset, absoluteConversionFactor, absoluteRange, analog, dutyId);
        this.loop = loop;
        desiredVoltage = 0f;

        this.setCANTimeout(50);
        this.setCANMaxRetries(5);
        this.setControlFramePeriodMs(10);
        this.setPeriodicFrameTimeout(50);
        this.configure(frc.robot.Constants.baseMaxConfig.inverted(inverted), ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);

        //SIMULATION PURPOSES ONLY!!!
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if(Robot.isSimulation()) {
            sim = new SparkMaxSim(this, frc.robot.Constants.neoVortexMotor);
            DCsim = new DCMotorSim(simPlant, frc.robot.Constants.neoVortexMotor, 0.001d, 0.01d);
        }
    }

    public LinearSystemLoop<N2, N1, N2> getLinearSystemLoop() {
        return loop;
    }

    //Updates the position, velocity, and acceleration of the encoder
    public void robotPeriodic(String name) {
        encoder.robotPeriodic();

        SmartDashboard.putNumber(name + " position: ", encoder.getPosition());
        SmartDashboard.putNumber(name + " position unwrapped: ", encoder.getPositionUnwrapped());
        SmartDashboard.putNumber(name + " velocity: ", encoder.getVelocity());
        SmartDashboard.putNumber(name + " desiredVoltage: ", desiredVoltage);

        //Moving LSL.correct and setClampFunction() to ropotPeirodic()
        //clamp got moved to constructor since I realised that was a better place for it to live
        loop.correct(MatBuilder.fill(Nat.N2(), Nat.N1(), getPositionUnwrapped(), getVelocity()));
    }

    //Does this really need a comment?
    public float getDesiredVoltage() {
        return desiredVoltage;
    }

    public void set(float speed) {
        //set((double) speed);
        desiredVoltage = ControllerGroup.currentBatteryVoltage * speed;
    }

    //Gets the desired voltage from a desired percentage (-1, 1) of total speed
    public void desiredVoltageFromPercentage(float targetPercentage) {
        targetPercentage = Math.max(-1f, Math.min(1f, targetPercentage));
        //ADDED setVoltage() TO SET... KILL ME KILL ME KILL ME KILL ME KILL ME
        //Holly ballognsse
        //Sets the next desired position and velocity of the motor
        loop.setNextR(MatBuilder.fill(Nat.N2(), Nat.N1(), getPositionUnwrapped() + frc.robot.Constants.neoVortexMotor.KvRadPerSecPerVolt * ControllerGroup.currentBatteryVoltage * targetPercentage * 0.02f, frc.robot.Constants.neoVortexMotor.KvRadPerSecPerVolt * ControllerGroup.currentBatteryVoltage * targetPercentage));
        //predict how the system will evolve and determine what the optimal voltage input is to reach the desired reference (what we put in above)
        loop.predict(0.02f);
        //Store the desired voltage so it can be limited later
        desiredVoltage = (float) loop.getU().get(0, 0);
    }

    //Gets the desired voltage from a desired position change
    public void desiredVoltageFromPositionChange(float positionChange) {
        //See above method. Does the same but with the position. Since we (presumably) want to stay at the desired position, the desired velocity is 0.
        loop.setNextR(MatBuilder.fill(Nat.N2(), Nat.N1(), positionChange + getPositionUnwrapped(), 0f));
        loop.predict(0.02f);
        desiredVoltage = (float) loop.getU().get(0, 0);
    }

    //Gets the desired voltage from a desired position (position can be in any range)
    public void desiredVoltageFromPosition(float position) {
        desiredVoltageFromPositionChange(encoder.applyModulus(position - getPositionUnwrapped()));
    }

    public float getPositionUnwrapped() {
        return encoder.getPositionUnwrapped();
    }

    public float getPositionModulus(float modulus, float conversionFactor) {
        return encoder.getPositionModulus(modulus, conversionFactor);
    }

    //Gets the position of the motor's encoder
    public float getPosition() {
        return encoder.getPosition();
    }

    //Gets the velocity of the motor's encoder
    public float getVelocity() {
        return encoder.getVelocity();
    }

    public void stopMotor() {
        desiredVoltage = 0f;
        super.set(0d);
    }

    public float getCurrent() {
        if(Robot.isSimulation()) {
            return (float) DCsim.getCurrentDrawAmps();
        }

        return (float) getOutputCurrent();
    }

    public void reset() {
        super.clearFaults();
        encoder.reset();
    }
}
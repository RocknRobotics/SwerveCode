package frc.robot.Camera;

import edu.wpi.first.math.geometry.CoordinateSystem;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Quaternion;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Timer;

public class Master {
    private NetworkTableInstance rioNetworkClient;
    private NetworkTableEntry[] cameraApriltagEntries;
    private float[] timeOffsets;

    int print = 0;

    public Master(NetworkTableInstance inst) {
        rioNetworkClient = inst;
        cameraApriltagEntries = new NetworkTableEntry[Constants.cameraNames.length];
        timeOffsets = new float[Constants.cameraNames.length];

        for(int i = 0; i < cameraApriltagEntries.length; ++i) {
            cameraApriltagEntries[i] = rioNetworkClient.getEntry("/Jetson/Camera/" + Constants.cameraNames[i] + "/Apriltag");
            cameraApriltagEntries[i].setDoubleArray(new double[]{});
            timeOffsets[i] = (float) (Timer.getFPGATimestamp() - (cameraApriltagEntries[i].getValue().getServerTime() / 1_000_000d));
        }

        for(int i = 0; i < 22; ++i) {
            System.out.println("(" + Constants.apriltagPoses[i].getX() + ", " + Constants.apriltagPoses[i].getY() + ")");
        }
    }

    //Reports the possible x, y, and h as calculated from the apriltag detections
    //TODO: Switch to median instead of mean
    public float[] robotPeriodic(float[] XYH, double[] RPH) {
        float x = 0f, y = 0f, z = 0f, roll = 0f, pitch = 0f, yaw = 0f, time = 0f;
        float totalDetections = 0;
        float minDistance = Float.MAX_VALUE;

        //For each camera
        for(int c = 0; c < cameraApriltagEntries.length; ++c) {
            double[] information = cameraApriltagEntries[c].getDoubleArray(new double[]{});

            //If no detections, skip this entry
            if(information.length == 0) {
                continue;
            }

            //While there are still more tag detections to parse
            for(int i = 0; i < information.length; i += 8) {
                ++totalDetections;

                //Get the id of the tag
                int id = (int) information[i];

                if(id > 22 || id < 1) {
                    break;
                }

                Rotation3d a = new Rotation3d(new Quaternion(information[i + 7], information[i + 4], information[i + 5], information[i + 6]));

                double tempX = information[i + 1];
                double tempY = information[i + 2];
                double tempZ = information[i + 3];
                Transform3d relativePose = new Transform3d(
                    new Translation3d(
                        tempX, 
                        tempY, 
                        tempZ
                    ),
                    a//CoordinateSystem.convert(a, CoordinateSystem.EDN(), CoordinateSystem.NWU())
                );
                relativePose = CoordinateSystem.convert(relativePose, CoordinateSystem.EDN(), CoordinateSystem.NWU());
                relativePose = new Transform3d(relativePose.getTranslation().rotateBy(relativePose.getRotation().unaryMinus()), relativePose.getRotation().unaryMinus());

                //Gets the camera's global pose from the apriltag's global and relative poses
                Pose3d cameraGlobalPose = Constants.apriltagPoses[id].transformBy(relativePose);//new Pose3d(new Translation3d(realX, realY, realZ), new Rotation3d(RPH[0], RPH[1], RPH[2]));

                //Gets the robot's global pose from the camera's global and relative poses
                Pose3d robotGlobalPose = cameraGlobalPose.transformBy(Constants.cameraPoses[c]);

                /*if (++print == 20) {
                    print = 0;
                    System.out.println("X: " + relativePose.getX());
                    System.out.println("Y: " + relativePose.getY());
                    System.out.println("Z: " + relativePose.getZ());
                    System.out.println("ROLL: " + relativePose.getRotation().getX());
                    System.out.println("PITCH: " + relativePose.getRotation().getY());
                    System.out.println("YAW: " + relativePose.getRotation().getZ());
                    System.out.println("APRIL X: " + Constants.apriltagPoses[id].getX());
                    System.out.println("APRIL Y: " + Constants.apriltagPoses[id].getY());
                    System.out.println("APRIL Z: " + Constants.apriltagPoses[id].getZ());
                    System.out.println("APRIL ROLL: " + Constants.apriltagPoses[id].getRotation().getX());
                    System.out.println("APRIL PITCH: " + Constants.apriltagPoses[id].getRotation().getY());
                    System.out.println("APRIL YAW: " + Constants.apriltagPoses[id].getRotation().getZ());
                    System.out.println("CAM GLOBAL X: " + cameraGlobalPose.getX());
                    System.out.println("CAM GLOBAL Y: " + cameraGlobalPose.getY());
                    System.out.println("CAM GLOBAL Z: " + cameraGlobalPose.getZ());
                    System.out.println("CAM GLOBAL ROLL: " + cameraGlobalPose.getRotation().getX());
                    System.out.println("CAM GLOBAL PITCH: " + cameraGlobalPose.getRotation().getY());
                    System.out.println("CAM GLOBAL YAW: " + cameraGlobalPose.getRotation().getZ());
                    System.out.println("ROB GLOBAL X: " + robotGlobalPose.getX());
                    System.out.println("ROB GLOBAL Y: " + robotGlobalPose.getY());
                    System.out.println("ROB GLOBAL Z: " + robotGlobalPose.getZ());
                    System.out.println("ROB GLOBAL ROLL: " + robotGlobalPose.getRotation().getX());
                    System.out.println("ROB GLOBAL PITCH: " + robotGlobalPose.getRotation().getY());
                    System.out.println("ROB GLOBAL YAW: " + robotGlobalPose.getRotation().getZ());
                    System.out.println("NETWORK TIME: " + Timer.getFPGATimestamp());
                }*/

                //If it's disabled, then we can pretty reliably trust that incoming pose estimates are correct
                //Otherwise, should be within one metre of estimate position to retain accuracy
                
                float dist = (float) Math.sqrt(relativePose.getX() * relativePose.getX() + relativePose.getY() * relativePose.getY() + relativePose.getZ() * relativePose.getZ());

                if(!DriverStation.isDisabled()) {
                    if(dist < minDistance) {
                        minDistance = dist;
                        x = (float) robotGlobalPose.getX();
                        y = (float) robotGlobalPose.getY();
                        z = (float) robotGlobalPose.getZ();
                        roll = (float) RPH[0];
                        pitch = (float) RPH[1];
                        yaw = XYH[2];
                        time = cameraApriltagEntries[c].getValue().getServerTime() / 1_000_000f + timeOffsets[c] - 0.01f;
                    } else {
                        --totalDetections;
                    }
                } else {
                    if(dist < minDistance) {
                        minDistance = dist;
                        x = (float) robotGlobalPose.getX();
                        y = (float) robotGlobalPose.getY();
                        z = (float) robotGlobalPose.getZ();
                        roll = (float) RPH[0];
                        pitch = (float) RPH[1];
                        yaw = XYH[2];
                        time = (float) Timer.getFPGATimestamp();
                    } else {
                        --totalDetections;
                    }
                }
            }
        }

        //Gets the average of all the detections
        if(totalDetections != 0) {
            x /= totalDetections;
            y /= totalDetections;
            z /= totalDetections;
            roll /= totalDetections;
            pitch /= totalDetections;
            yaw /= totalDetections;
            time /= totalDetections;
        }

        return new float[]{x, y, z, roll, pitch, yaw, time, minDistance};
    }
}

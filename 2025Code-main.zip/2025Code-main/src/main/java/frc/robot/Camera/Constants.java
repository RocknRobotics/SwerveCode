package frc.robot.Camera;

import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.math.util.Units;

public class Constants {
    
    static final float fieldX = 8.058f;
    
    //Pose3ds representing the apriltags in our coordinate system (moving right is +x, moving towards red station is +y, moving up vertically is +z)
    static final Pose3d[] apriltagPoses = new Pose3d[]{
        new Pose3d(), //Since tag 0 doesn't exist, don't fill this in with anything
        new Pose3d( //Tag ID 1
            new Translation3d(fieldX - Units.inchesToMeters(25.80f), Units.inchesToMeters(657.37d), Units.inchesToMeters(58.50f)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(126d))
        ),
        new Pose3d( //Tag ID 2
            new Translation3d(fieldX - Units.inchesToMeters(291.20f), Units.inchesToMeters(657.37d), Units.inchesToMeters(58.50f)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(234d))
        ),
        new Pose3d( //Tag ID 3
            new Translation3d(fieldX - Units.inchesToMeters(317.15d), Units.inchesToMeters(455.15d), Units.inchesToMeters(51.25d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(270f))
        ),
        new Pose3d( //Tag ID 4
            new Translation3d(fieldX - Units.inchesToMeters(241.64d), Units.inchesToMeters(365.20f), Units.inchesToMeters(73.54d)),
            new Rotation3d(Units.degreesToRadians(30f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(0f))
        ),
        new Pose3d( //Tag ID 5
            new Translation3d(fieldX - Units.inchesToMeters(75.39d), Units.inchesToMeters(365.20f), Units.inchesToMeters(73.54d)),
            new Rotation3d(Units.degreesToRadians(30f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(0f))
        ),
        new Pose3d( //Tag ID 6
            new Translation3d(fieldX - Units.inchesToMeters(130.17d), Units.inchesToMeters(530.49d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(300f))
        ),
        new Pose3d( //Tag ID 7
            new Translation3d(fieldX - Units.inchesToMeters(158.50f), Units.inchesToMeters(546.87d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(0f))
        ),
        new Pose3d( //Tag ID 8
            new Translation3d(fieldX - Units.inchesToMeters(186.83d), Units.inchesToMeters(530.49d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(60f))
        ),
        new Pose3d( //Tag ID 9
            new Translation3d(fieldX - Units.inchesToMeters(186.83d), Units.inchesToMeters(497.77d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(120f))
        ),
        new Pose3d( //Tag ID 10
            new Translation3d(fieldX - Units.inchesToMeters(158.50f), Units.inchesToMeters(481.39d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(180f))
        ),
        new Pose3d( //Tag ID 11
            new Translation3d(fieldX - Units.inchesToMeters(130.17d), Units.inchesToMeters(497.77d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(240f))
        ),
        new Pose3d( //Tag ID 12
            new Translation3d(fieldX - Units.inchesToMeters(25.80f), Units.inchesToMeters(33.51f), Units.inchesToMeters(58.50f)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(54d))
        ),
        new Pose3d( //Tag ID 13
            new Translation3d(fieldX - Units.inchesToMeters(291.20f), Units.inchesToMeters(33.51f), Units.inchesToMeters(58.50f)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(306d))
        ),
        new Pose3d( //Tag ID 14
            new Translation3d(fieldX - Units.inchesToMeters(241.64d), Units.inchesToMeters(325.68d), Units.inchesToMeters(73.54d)),
            new Rotation3d(Units.degreesToRadians(30f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(180f))
        ),
        new Pose3d( //Tag ID 15
            new Translation3d(fieldX - Units.inchesToMeters(75.39d), Units.inchesToMeters(325.68d), Units.inchesToMeters(73.54d)),
            new Rotation3d(Units.degreesToRadians(30f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(180f))
        ),
        new Pose3d( //Tag ID 16
            new Translation3d(fieldX - Units.inchesToMeters(-0.15d), Units.inchesToMeters(235.73d), Units.inchesToMeters(51.25d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(90f))
        ),
        new Pose3d( //Tag ID 17
            new Translation3d(fieldX - Units.inchesToMeters(130.17d), Units.inchesToMeters(160.39d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(240f))
        ),
        new Pose3d( //Tag ID 18
            new Translation3d(fieldX - Units.inchesToMeters(158.50f), Units.inchesToMeters(144.0f), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(180f))
        ),
        new Pose3d( //Tag ID 19
            new Translation3d(fieldX - Units.inchesToMeters(186.83d), Units.inchesToMeters(160.39d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(120f))
        ),
        new Pose3d( //Tag ID 20
            new Translation3d(fieldX - Units.inchesToMeters(186.83d), Units.inchesToMeters(193.10f), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(60f))
        ),
        new Pose3d( //Tag ID 21
            new Translation3d(fieldX - Units.inchesToMeters(158.50f), Units.inchesToMeters(209.49d), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(0f))
        ),
        new Pose3d( //Tag ID 22
            new Translation3d(fieldX - Units.inchesToMeters(130.17d), Units.inchesToMeters(193.10f), Units.inchesToMeters(12.13d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), frc.robot.Constants.PIF / 2d + Units.degreesToRadians(300f))
        )
    };

    //The poses of the cameras relative to the centre of the robot
    public static final Transform3d[] cameraPoses = new Transform3d[]{
        new Transform3d( //TR
            new Translation3d(-Units.inchesToMeters(2.75d), Units.inchesToMeters(8.5d), Units.inchesToMeters(36.75d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), Units.degreesToRadians(90f) + Math.PI)
        ),
        new Transform3d( //BR
            new Translation3d(-Units.inchesToMeters(2.75d), -Units.inchesToMeters(8.5d), Units.inchesToMeters(36.75d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), Units.degreesToRadians(270f) + Math.PI)
        ),
        new Transform3d( //BL
            new Translation3d(-Units.inchesToMeters(10.75d), -Units.inchesToMeters(7.75d), Units.inchesToMeters(7.5d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), Units.degreesToRadians(180f) + Math.PI)
        ),
        new Transform3d( //TL
            new Translation3d(Units.inchesToMeters(10.75d), Units.inchesToMeters(7.75d), Units.inchesToMeters(7.5d)),
            new Rotation3d(Units.degreesToRadians(0f), Units.degreesToRadians(0f), Units.degreesToRadians(0f) + Math.PI)
        )
    };

    static final String[] cameraNames = {"TR", "BR", "BL", "TL"};
}

package frc.robot;

import java.util.function.Function;

import com.revrobotics.spark.config.SignalsConfig;
import com.revrobotics.spark.config.SparkBaseConfig;
import com.revrobotics.spark.config.SparkFlexConfig;
import com.revrobotics.spark.config.SparkMaxConfig;
import com.revrobotics.spark.config.SparkBaseConfig.IdleMode;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.StateSpaceUtil;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.system.plant.DCMotor;
import frc.robot.MotorController.ControllerGroup;

public class Constants {
    //A DCMotor object representing a neo vortex
    public static final DCMotor neoVortexMotor = DCMotor.getNeoVortex(1);

    public static final DCMotor neoMotor = DCMotor.getNEO(1);

    //The clamp function used for all linear systems (literally just makes it so the max voltage it outputs is the battery voltage, or 12v)
    public static final Function<Matrix<N1, N1>, Matrix<N1, N1>> systemClampFunction = input -> StateSpaceUtil.desaturateInputVector(input, Math.min(12f, ControllerGroup.currentBatteryVoltage));

    //The None at the start ensures all declared but not initialised encoderType variables default to None, so the program doesn't think there's an encoder when there isn't
    public static enum encoderType {
        None,
        QuadratureEncoder,
        AnalogEncoder
    }

    //The minimum battery voltage we want the motors to cause it to drop to
    public static final float batteryMinimumVoltage = 10.5f;

    //The internal resistance of the battery. Low end estimate is 0.012 ohms, high end is 0.02 ohms, so I went in the middle with 0.016 ohms.
    public static final float batteryResistance = 0.02f;

    //The base spark flex configuration object
    public static final SparkBaseConfig baseFlexConfig = new SparkFlexConfig()
        .apply(new SignalsConfig()
            //Useful, want always enabled (shaves a few milliseconds of get() calls) and frequent updates to ensure accuracy
            .primaryEncoderPositionAlwaysOn(true)
            .primaryEncoderVelocityAlwaysOn(true)
            .primaryEncoderPositionPeriodMs(15)
            .primaryEncoderVelocityPeriodMs(15)
            .busVoltagePeriodMs(15)

            //Not necessarily important, but do still want them to update, just not as frequently
            .faultsAlwaysOn(false)
            .faultsPeriodMs(50)
            .motorTemperaturePeriodMs(50)
            .outputCurrentPeriodMs(50)
            .warningsAlwaysOn(false)
            .warningsPeriodMs(50)

            //Useless for now. Setting these to less frequent updates reduces CAN bus usage
            .absoluteEncoderPositionAlwaysOn(false)
            .absoluteEncoderVelocityAlwaysOn(false)
            .absoluteEncoderPositionPeriodMs(1000)
            .absoluteEncoderVelocityPeriodMs(1000)
            .analogPositionAlwaysOn(false)
            .analogVelocityAlwaysOn(false)
            .analogVoltageAlwaysOn(false)
            .analogPositionPeriodMs(1000)
            .analogVelocityPeriodMs(1000)
            .analogVoltagePeriodMs(1000)
            .appliedOutputPeriodMs(1000)
            .externalOrAltEncoderPositionAlwaysOn(false)
            .externalOrAltEncoderVelocityAlwaysOn(false)
            .externalOrAltEncoderPosition(1000)
            .externalOrAltEncoderVelocity(1000)
            .iAccumulationAlwaysOn(false)
            .iAccumulationPeriodMs(1000)
            .limitsPeriodMs(1000)
        )
        .disableFollowerMode()
        .disableVoltageCompensation()
        .idleMode(IdleMode.kBrake)
        .smartCurrentLimit(211, 4) //The free limit for the neo vortex is 211 amps and the stall is 3.6 amps. Since it only accepts integers, 3.6 is rounded up
        .secondaryCurrentLimit(60) //Max recommended current for 3 minutes for the SparkFlex
    ;

    public static final SparkBaseConfig baseMaxConfig = new SparkMaxConfig()
        .apply(new SignalsConfig()
            //Useful, want always enabled (shaves a few milliseconds of get() calls) and frequent updates to ensure accuracy
            .primaryEncoderPositionAlwaysOn(true)
            .primaryEncoderVelocityAlwaysOn(true)
            .primaryEncoderPositionPeriodMs(15)
            .primaryEncoderVelocityPeriodMs(15)
            .busVoltagePeriodMs(15)

            //Not necessarily important, but do still want them to update, just not as frequently
            .faultsAlwaysOn(false)
            .faultsPeriodMs(50)
            .motorTemperaturePeriodMs(50)
            .outputCurrentPeriodMs(50)
            .warningsAlwaysOn(false)
            .warningsPeriodMs(50)

            //Useless for now. Setting these to less frequent updates reduces CAN bus usage
            .absoluteEncoderPositionAlwaysOn(false)
            .absoluteEncoderVelocityAlwaysOn(false)
            .absoluteEncoderPositionPeriodMs(1000)
            .absoluteEncoderVelocityPeriodMs(1000)
            .analogPositionAlwaysOn(false)
            .analogVelocityAlwaysOn(false)
            .analogVoltageAlwaysOn(false)
            .analogPositionPeriodMs(1000)
            .analogVelocityPeriodMs(1000)
            .analogVoltagePeriodMs(1000)
            .appliedOutputPeriodMs(1000)
            .externalOrAltEncoderPositionAlwaysOn(false)
            .externalOrAltEncoderVelocityAlwaysOn(false)
            .externalOrAltEncoderPosition(1000)
            .externalOrAltEncoderVelocity(1000)
            .iAccumulationAlwaysOn(false)
            .iAccumulationPeriodMs(1000)
            .limitsPeriodMs(1000)
        )
        .disableFollowerMode()
        .disableVoltageCompensation()
        .idleMode(IdleMode.kBrake)
        .smartCurrentLimit(105, 2) //The free limit for the neo vortex is 211 amps and the stall is 3.6 amps. Since it only accepts integers, 3.6 is rounded up
        .secondaryCurrentLimit(60) //Max recommended current for 3 minutes for the SparkFlex
    ;

    public static final float PIF = (float) Math.PI;

    //TODO: Make this public and have all other Constants use these rather than have their own
    static final float fieldX = 8.058f;
    static final float fieldY = 17.548f;

    public static final int anglePrecision = 30;
    public static final int distancePrecision = 15;

    private static final int sqrtPrecision = 100;
    private static final float sqrtMax = (fieldX + 1f) * (fieldX + 1f) + (fieldY + 1f) * (fieldY + 1f);
    private static final int sqrtLookupLength = (int) Math.ceil(sqrtPrecision * sqrtMax) + 1;
    private static final float[] sqrtLookup = new float[sqrtLookupLength];

    private static final int cosPrecision = 100;
    private static final float cosMax = PIF;
    private static final int cosLookupLength = (int) Math.ceil(cosPrecision * cosMax) + 1;
    private static final float[] cosLookup = new float[cosLookupLength];

    private static final int arctanPrecision = 100;
    private static final float arctanMax = 100;
    private static final int arctanLookupLength = (int) Math.ceil(arctanPrecision * arctanMax) + 1;
    private static final float[] arctanLookup = new float[arctanLookupLength];

    public static void initSqrtLookup() {
        for(int i = 0; i < sqrtLookup.length; ++i) {
            sqrtLookup[i] = (float) Math.sqrt(((float) i) / sqrtPrecision);
        }

        Robot.totalBytes += 4f * sqrtLookupLength;
    }

    public static void initCosLookup() {
        for(int i = 0; i < cosLookup.length; ++i) {
            cosLookup[i] = (float) Math.cos(((float) i) / cosPrecision);
        }

        Robot.totalBytes += 4f * cosLookupLength;
    }

    public static void initArcTanLookup() {
        for(int i = 0; i < arctanLookup.length; ++i) {
            arctanLookup[i] = (float) Math.atan(((float) i) / arctanPrecision);
        }

        Robot.totalBytes += 4f * arctanLookupLength;
    }

    public static float sqrtLookup(float squared) {
        float squaredTimePrecision = squared * sqrtPrecision;
        int floor = (int) squaredTimePrecision;

        try {
            return sqrtLookup[floor] + (floor - squaredTimePrecision) * (sqrtLookup[floor] - sqrtLookup[++floor]);
        } catch(ArrayIndexOutOfBoundsException e) {
            //e.printStackTrace();
            return squared < 0 ? 0f : (float) Math.sqrt(squared);
        }
    }

    public static float cosLookup(float angle) {
        angle = (float) MathUtil.angleModulus(angle);
        angle = angle < 0 ? -angle : angle;

        float angleTimePrecision = angle * cosPrecision;
        int floor = (int) angleTimePrecision;
        
        return cosLookup[floor] + (floor - angleTimePrecision) * (cosLookup[floor] - cosLookup[++floor]);
    }

    public static float sinLookup(float angle) {
        return cosLookup(angle - PIF / 2f);
    }

    public static float atanLookup(float y, float x) {
        if(x == 0) {
            if(y == 0) {
                return 0;
            } else if(y < 0) {
                return -PIF / 2f;
            } else {
                return PIF / 2f;
            }
        }

        float ratioTimePrecision = Math.abs(y / x) * arctanPrecision;
        int floor = Math.min((int) ratioTimePrecision, arctanLookupLength - 1);
        int ceil = Math.min(floor + 1, arctanLookupLength - 1);

        float angle = arctanLookup[floor] + (ratioTimePrecision - floor) * (arctanLookup[ceil] - arctanLookup[floor]);

        if(y >= 0) {
            if(x > 0) {
                return angle;
            } else {
                return PIF - angle;
            }
        } else {
            if(x < 0) {
                return angle - PIF;
            } else {
                return -angle;
            }
        }
    }
}

package frc.robot.Arm;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.controller.LinearQuadraticRegulator;
import edu.wpi.first.math.estimator.KalmanFilter;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N2;
import edu.wpi.first.math.system.LinearSystem;
import edu.wpi.first.math.system.LinearSystemLoop;
import edu.wpi.first.math.system.plant.LinearSystemId;
import edu.wpi.first.math.util.Units;
import frc.robot.Robot;

public final class Constants {
    //The id of the SparkFlexes for the left coral intake wheel
    static final int controllerId = 41;

    //Whether or not to invert the left/right/top wheels
    static final boolean controllerInverted = false;

    static final LinearSystem<N2, N1, N2> armSystem = LinearSystemId.createDCMotorSystem(frc.robot.Constants.neoVortexMotor, 1.7f * Math.pow(10, -3), 1f);

    //TODO: This
    static final LinearSystemLoop<N2, N1, N2> armSystemLoop = new LinearSystemLoop<N2, N1, N2>(
        armSystem,
        new LinearQuadraticRegulator<N2, N1, N2>(armSystem.getA(), armSystem.getB(), MatBuilder.fill(Nat.N2(), Nat.N2(), 0.5f, 0f, 0f, 0.5f), MatBuilder.fill(Nat.N1(), Nat.N1(), 12d), 0.02d),
        new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), armSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3d, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02d),
        frc.robot.Constants.systemClampFunction,
        0.02d
    );

    static final int switchId = 0;

    static final float lidarHasCoralDistance = 0.05f;

    static final float wheelCircumference = (float) Units.inchesToMeters(3f) * frc.robot.Constants.PIF;

    static final float wheelChange = 3f;

    static final float coralShootTime = Robot.isSimulation() ? 0.05f : 0.1f;
}
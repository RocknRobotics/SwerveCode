package frc.robot.Arm;

import edu.wpi.first.wpilibj.AnalogInput;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;
import frc.robot.MotorController.FlexVortexController;
import frc.robot.MotorController.ControllerGroup;

public class Master {
    //Declares the left, right, and top wheel motor controller variables
    private FlexVortexController controller;

    public boolean hasCoral = true;
    public boolean fullySeated = true;

    private int intakeCounter = 0;

    private AnalogInput coralSwitch;

    public boolean scored = false;
    public boolean intaked = false;
    int print = 0;

    double t = 0;
    boolean switchState;
    int counter = 0;

    boolean shotLastLoop = false;
    boolean shotThisLoop = false;

    float initialWheelPos = 0f;

    public Master(ControllerGroup fatControllerGroup){
        //Initialises the motor controllers using the ids from the constants file
        controller = new FlexVortexController(Constants.controllerId, Constants.controllerInverted, Constants.armSystemLoop, Constants.armSystem);

        coralSwitch = new AnalogInput(Constants.switchId);
        switchState = false;

        fatControllerGroup.add(controller);
    }

    //Updates the switch state
    public void robotPeriodic(){
        controller.robotPeriodic("Arm");

        if(Robot.isReal()) {
            //System.out.println(coralSwitch.getAverageVoltage());
            switchState = coralSwitch.getAverageVoltage() > 0.25f;

            SmartDashboard.putBoolean("Switch State: ", switchState);
        }

        SmartDashboard.putBoolean("Has Coral: ", hasCoral);
        SmartDashboard.putBoolean("Fully Seated: ", fullySeated);

        shotLastLoop = shotThisLoop;
        shotThisLoop = false;
    }

    public void intake() {
        if(Robot.isReal()) {
            if(switchState) {
                hasCoral = true;
                fullySeated = true;
                intaked = true;
            }
        } else {
            if(++intakeCounter == 50) {
                intakeCounter = 0;
                hasCoral = true;
                fullySeated = true;
                intaked = true;
            }
        }

        if(!fullySeated) {
            controller.set(0.095f);
        } else {
            controller.set(-0.0275f);
        }
    }

    public void intake(float timeToSpot) {
        if(timeToSpot <= Constants.coralShootTime) {
            intake();
        } else {
            controller.set(0f);
        }
    }

    //TODO
    public void shoot() {
        shotThisLoop = true;

        if(!shotLastLoop) {
            initialWheelPos = controller.getPositionUnwrapped();
        }

        if(Robot.isReal()) {
            if((controller.getPositionUnwrapped() - initialWheelPos > Constants.wheelChange))  {
                scored = true;
                hasCoral = false;
                fullySeated = false;
                //controller.stopMotor();
            } else {
                controller.set(0.4f);
            }
        } else {
            if(++counter == 20) {
                counter = 0;
                scored = true;
                hasCoral = false;
                fullySeated = false;
                controller.stopMotor();
            } else {
                controller.set(1f);
            }   
        }
    }

    public void shoot(float timeToSpot, boolean elevatorReady, boolean anyTilt) {
        if(!fullySeated) {
            intake();
        } else if(timeToSpot <= Constants.coralShootTime && elevatorReady && !anyTilt) {
            shoot();
        }
    }

    public void slowShoot() {
        shotThisLoop = true;

        if(!shotLastLoop) {
            initialWheelPos = controller.getPositionUnwrapped();
        }

        if(Robot.isReal()) {
            if((controller.getPositionUnwrapped() - initialWheelPos > Constants.wheelChange))  {
                scored = true;
                hasCoral = false;
                fullySeated = false;
                //controller.stopMotor();
            } else {
                controller.set(0.1f);
            }
        } else {
            if(++counter == 20) {
                counter = 0;
                scored = true;
                hasCoral = false;
                fullySeated = false;
                controller.stopMotor();
            } else {
                controller.set(1f);
            }   
        }
    }

    public void slowShoot(float timeToSpot, boolean elevatorReady, boolean anyTilt) {
        if(!fullySeated) {
            intake();
        } else if(timeToSpot <= Constants.coralShootTime && elevatorReady && !anyTilt) {
            slowShoot();
        }
    }

    public void kickAlgae() {
        controller.set(1f);

        if(Timer.getFPGATimestamp() - t >= 0.2f) {
            scored = true;
        }
    }

    public void kickAlgae(float timeToSpot) {
        if(Timer.getFPGATimestamp() - t >= 0.3f) {
            t = Timer.getFPGATimestamp();
        }

        if(timeToSpot <= Constants.coralShootTime) {
            kickAlgae();
        } else {
            t = Timer.getFPGATimestamp();
        }
    }

    //TODO
    public boolean hasCoral() {
        return hasCoral;
    }

    //TODO
    public void teleopPeriodic(int armPacket){
        if(armPacket == 0) {
            intake();
        } else if(armPacket == 1) {
            shoot();
        } else if(armPacket == 2) {
            slowShoot();
        } else if(fullySeated) {
            controller.set(-0.0275f);
        } else {
            controller.set(0f);
        }
    }

    public void disabledPeriodic(){
        controller.stopMotor();
    }

    public void continuousShoot() {
        controller.set(0.5f);
    }

    public boolean getSwitchState() {
        return switchState;
    }
}
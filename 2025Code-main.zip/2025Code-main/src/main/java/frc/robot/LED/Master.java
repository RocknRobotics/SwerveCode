package frc.robot.LED;

import edu.wpi.first.wpilibj.AddressableLED;
import edu.wpi.first.wpilibj.AddressableLEDBuffer;

public class Master {
    AddressableLED led;
    AddressableLEDBuffer ledBuffer;

    public Master() {
        led = new AddressableLED(Constants.ledPort);
        ledBuffer = new AddressableLEDBuffer(Constants.ledLength);
        led.setLength(ledBuffer.getLength());

        led.setData(ledBuffer);
        led.start();
    }

    public void robotPeriodic(boolean hasCoral) {
        if(hasCoral) {
            Constants.coralPattern.applyTo(ledBuffer);
        } else {
            Constants.defaultPattern.applyTo(ledBuffer);
        }
        
        led.setData(ledBuffer);
    }
}

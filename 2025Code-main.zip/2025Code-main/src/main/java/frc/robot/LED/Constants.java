package frc.robot.LED;

import java.util.Map;

import edu.wpi.first.units.Units;
import edu.wpi.first.wpilibj.LEDPattern;
import edu.wpi.first.wpilibj.LEDPattern.GradientType;
import edu.wpi.first.wpilibj.util.Color;

public class Constants {
    static final int ledPort = 0;
    static final int ledLength = 300;

    static final float emptySpaceSize = 0.1f; //Number of LEDs to skip when using the empty pattern
    static final float actualPatternSize = 0.15f;
    static final LEDPattern emptySpacePattern =
        LEDPattern.steps(Map.of(0, Color.kWhite, actualPatternSize, Color.kBlack,
        actualPatternSize + emptySpaceSize, Color.kWhite, 2 * actualPatternSize + emptySpaceSize, Color.kBlack,
        2 * actualPatternSize + 2 * emptySpaceSize, Color.kWhite, 3 * actualPatternSize + 2 * emptySpaceSize, Color.kBlack,
        3 * actualPatternSize + 3 * emptySpaceSize, Color.kWhite, 4 * actualPatternSize + 3 * emptySpaceSize, Color.kBlack,
        4 * actualPatternSize + 4 * emptySpaceSize, Color.kWhite));
    //The empty pattern is used to create a spaces within the actual pattern

    static final LEDPattern defaultPattern = 
        LEDPattern.gradient(GradientType.kContinuous, Color.kDarkRed, Color.kYellow)
        .breathe(Units.Seconds.of(5))
        .scrollAtRelativeSpeed(Units.Percent.per(Units.Second).of(20))
        .mask(emptySpacePattern.scrollAtRelativeSpeed(Units.Percent.per(Units.Second).of(10)).reversed())
        //.atBrightness(Units.Percent.of(80))
        ;
    static final LEDPattern coralPattern = 
        LEDPattern.gradient(GradientType.kContinuous, Color.kSeaGreen, Color.kNavy)
        .breathe(Units.Seconds.of(3))
        .scrollAtRelativeSpeed(Units.Percent.per(Units.Second).of(30))
        .mask(emptySpacePattern.scrollAtRelativeSpeed(Units.Percent.per(Units.Second).of(15)).reversed())
        //.atBrightness(Units.Percent.of(80))
        .reversed();
}

// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.hal.AllianceStationID;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Joystick.Master;

/**
 * The VM is configured to automatically run this class, and to call the functions corresponding to
 * each mode, as described in the TimedRobot documentation. If you change the name of this class or
 * the package after creating this project, you must also update the build.gradle file in the
 * project.
 */


public class Robot extends TimedRobot {
  //Stores every single motor in the robot for voltage limiting calculations
  private frc.robot.MotorController.ControllerGroup fatControllerGroup;

  private frc.robot.Arm.Master armMaster;
  private frc.robot.Elevator.Master elevatorMaster;
  private frc.robot.Joystick.Master joystickMaster;
  private frc.robot.Swerve.Master swerveMaster;
  private frc.robot.Path.Master pathMaster;
  private frc.robot.Camera.Master cameraMaster;
  private NetworkTableInstance rioNetworkClient;
  private frc.robot.ObstacleParser.Master obstacleMaster;
  private frc.robot.DecisionMaker.Master decisionMaster;
  private frc.robot.AlgaePickup.Master algaeMaster;
  private frc.robot.LED.Master ledMaster;

  public static float totalBytes = 0f;

  int counter = 0;
  
  private boolean enableDecisionMaking = false;

  //2,1,pickup,1,1,pickup,1,0,pickup  
  //4,1,pickup,5,0,pickup,5,1,pickup
  //5,0,pickup,5,1,pickup

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void robotInit() {
    if(Robot.isSimulation()) {
      DriverStationSim.setFmsAttached(true);
      DriverStationSim.setDsAttached(true);
      DriverStationSim.setAllianceStationId(AllianceStationID.Blue1);
    }

    Constants.initSqrtLookup();
    Constants.initCosLookup();
    Constants.initArcTanLookup();

    //Used by Camera Master for networking with the Jetson
    rioNetworkClient = NetworkTableInstance.getDefault();
    rioNetworkClient.startClient4("rioClient");
    rioNetworkClient.setServer("10.36.92.2", NetworkTableInstance.kDefaultPort4);
    SmartDashboard.setNetworkTableInstance(rioNetworkClient);

    SmartDashboard.putString("Auto String: ", "");
    SmartDashboard.putNumber("Initial Position X: ", 4d);
    SmartDashboard.putNumber("Initial Position Y: ", 8d);

    fatControllerGroup = new frc.robot.MotorController.ControllerGroup(new frc.robot.MotorController.FlexVortexController[0]);
    
    armMaster = new frc.robot.Arm.Master(fatControllerGroup);
    elevatorMaster = new frc.robot.Elevator.Master(fatControllerGroup);
    cameraMaster = new frc.robot.Camera.Master(rioNetworkClient);
    algaeMaster = new frc.robot.AlgaePickup.Master(fatControllerGroup);
    pathMaster = new frc.robot.Path.Master();
    ledMaster = new frc.robot.LED.Master();

    if(enableDecisionMaking) {
      pathMaster.initConstantObstacles();
    }

    while(!DriverStation.getAlliance().isPresent()) {
      try {
        Thread.sleep(100);
      } catch(InterruptedException e) {
        e.printStackTrace();
      }
    }

    obstacleMaster = new frc.robot.ObstacleParser.Master(rioNetworkClient);
    swerveMaster = new frc.robot.Swerve.Master(fatControllerGroup);
    decisionMaster = null;

    if(enableDecisionMaking) {
      decisionMaster = new frc.robot.DecisionMaker.Master(swerveMaster, elevatorMaster, armMaster, obstacleMaster, pathMaster);
      decisionMaster.fillAlgaeSpots();
    }
    
    joystickMaster = new Master(swerveMaster, elevatorMaster, armMaster, algaeMaster, decisionMaster);

    System.out.println("Total MegaBytes of Lookups: " + (totalBytes / 1_000_000f));

    System.gc();
    frc.robot.DecisionMaker.Constants.algaeCostFactor = 10000f;
    frc.robot.DecisionMaker.Constants.fillAllCost = 1f;
    frc.robot.DecisionMaker.Constants.coralWorth = new float[]{3f, 4f, 6f, 7f};
  }

  //20 ms
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void robotPeriodic() {
    if(++counter == 250) {
      counter = 0;
      System.gc();
    }
    
    swerveMaster.swerveFactor = elevatorMaster.getHeightRatio();
    armMaster.robotPeriodic();
    algaeMaster.robotPeriodic();
    swerveMaster.robotPeriodic(cameraMaster.robotPeriodic(swerveMaster.getXYH(), swerveMaster.getRPH()));
    elevatorMaster.robotPeriodic();
    obstacleMaster.robotPeriodic(swerveMaster.getXYH(), swerveMaster.getPose());
    ledMaster.robotPeriodic(armMaster.hasCoral());

    if(enableDecisionMaking) {
      decisionMaster.robotPeriodic();
    }
  }

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void autonomousInit() {
    swerveMaster.reset();

    //swerveMaster.setPosition();

    decisionMaster.autonomousInit();
  }

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void autonomousPeriodic() {
    if(swerveMaster.tipping()) {
      swerveMaster.disabledPeriodic();
      elevatorMaster.goToBottom();
    } else {
      if(enableDecisionMaking) {
        decisionMaster.actOnBehaviour();
      }
    }

    fatControllerGroup.limitVoltage();
  }

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void teleopInit() {
    if(enableDecisionMaking) {
      decisionMaster.teleopInit();
    }
    
    //frc.robot.DecisionMaker.Constants.algaeCostFactor = 1f;
    frc.robot.DecisionMaker.Constants.fillAllCost = 10f;
    frc.robot.DecisionMaker.Constants.coralWorth = new float[]{2f, 3f, 4f, 5f};
  }

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void teleopPeriodic() {
    if(swerveMaster.tipping()) {
      elevatorMaster.goToBottom();
    } else {
      joystickMaster.teleopPeriodic();
    }

    fatControllerGroup.limitVoltage();
  }

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void disabledInit() {}

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void disabledPeriodic() {
    fatControllerGroup.stopMotor();
  }

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void testInit() {
    swerveMaster.reset();
  }

  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------------------------------------------------
  @Override
  public void testPeriodic() {
    //float p[] = pathMaster.calculateNextPoint(swerveMaster.getXYH(), new float[]{(float) SmartDashboard.getNumber("Target X: ", swerveMaster.getXYH()[0]), (float) SmartDashboard.getNumber("Target Y: ", swerveMaster.getXYH()[1]), (float) SmartDashboard.getNumber("Target H: ", swerveMaster.getXYH()[2])}, new ArrayList<ExtendedObstacle>());
    //swerveMaster.goTo(p[0], p[1], p[2], p[3]);

    fatControllerGroup.limitVoltage();
  }
}
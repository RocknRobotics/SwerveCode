package frc.robot.ObstacleParser;

import java.util.ArrayList;

import edu.wpi.first.math.geometry.CoordinateSystem;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Quaternion;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import frc.robot.Path.Coordinate;
import frc.robot.Path.Obstacle;

public class Master {
    private static ArrayList<ExtendedObstacle> runtimeObstacles;
    private ArrayList<ExtendedObstacle> reefObstacles;
    private Obstacle reef;
    private NetworkTableEntry[] obstaclePositions;

    public Master(NetworkTableInstance inst) {
        runtimeObstacles = new ArrayList<ExtendedObstacle>();
        reefObstacles = new ArrayList<ExtendedObstacle>();
        reef = frc.robot.Path.Constants.reefs[0];

        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            reef = frc.robot.Path.Constants.reefs[1];
        }

        obstaclePositions = new NetworkTableEntry[]{
            inst.getEntry("/Jetson/Camera/TR/Yolo"),
            inst.getEntry("/Jetson/Camera/BR/Yolo"),
            inst.getEntry("/Jetson/Camera/BL/Yolo"),
            inst.getEntry("/Jetson/Camera/TL/Yolo")
        };
    }

    //TODO
    public void robotPeriodic(float[] currentXYH, Pose3d currentPose) {
        //Updates confidence of all current obstacles, and if less than some threshold, removes them
        /*for(int i = 0; i < runtimeObstacles.size(); ++i) {
            runtimeObstacles.get(i).updatePosition();
            runtimeObstacles.get(i).updateConfidence(currentXYH);

            if(runtimeObstacles.get(i).getConfidence() < 0.1f) {
                runtimeObstacles.remove(i);
                --i;
            } else {
                runtimeObstacles.get(i).robotPeriodic();
            }
        }*/

        /*for(int i = 0; i < reefObstacles.size(); ++i) {
            reefObstacles.get(i).updatePosition();
            reefObstacles.get(i).updateConfidence(currentXYH);

            if(reefObstacles.get(i).getConfidence() < 0.1f) {
                reefObstacles.remove(i);
                --i;
            }
        }

        ArrayList<ExtendedObstacle> robotObstacles = new ArrayList<ExtendedObstacle>();
        ArrayList<ExtendedObstacle> otherObstacles = new ArrayList<ExtendedObstacle>();
        //This float array contains obstacle vertices. -1 corresponds to an algae, -2 corresponds to a cage, -3 corresponds to a coral, and -4 corresponds to a robot
        //The setup is like so:
        //a, b... -1 -> indicates an algae with vertices [(a, b)...]
        //And then after -1 it would continue c, d... -3 -> indicates a coral with vertices[(c, d), ...]
        //For robots specifically, with e,f... -4 -> indicates the partial vertices of the robot are [(e, f), ...]

        for(int c = 0; c < obstaclePositions.length; ++c) {
            double[] detectedObstacles = obstaclePositions[c].getDoubleArray(new double[]{});

            for(int i = 0; i < detectedObstacles.length; i += 8) {
                int id = (int) detectedObstacles[i];

                Transform3d tranVec = new Transform3d(
                    detectedObstacles[i + 1], 
                    detectedObstacles[i + 2], 
                    detectedObstacles[i + 3], 
                    new Rotation3d(new Quaternion(
                        detectedObstacles[i + 4], 
                        detectedObstacles[i + 5], 
                        detectedObstacles[i + 6], 
                        detectedObstacles[i + 7]
                    ))
                );

                //tranVec = new Transform3d(tranVec.getTranslation().rotateBy(tranVec.getRotation().unaryMinus()), tranVec.getRotation().unaryMinus());

                Pose3d cameraPose = currentPose.transformBy(
                    new Transform3d(
                        frc.robot.Camera.Constants.cameraPoses[c].getTranslation().rotateBy(currentPose.getRotation()),
                        frc.robot.Camera.Constants.cameraPoses[c].getRotation().rotateBy(currentPose.getRotation())
                    ));

                Pose3d[] corners = new Pose3d[Constants.objects[id].length];
                Coordinate[] cornerCoordinates = new Coordinate[corners.length];
                float zPos = 0f;

                for(int j = 0; j < corners.length; ++j) {
                    corners[j] = new Pose3d(
                        new Translation3d(
                            cameraPose.getX() - tranVec.getZ() * Math.sin(cameraPose.getZ()) - tranVec.getX() * Math.sin(cameraPose.getZ() - Math.PI / 2d),
                            cameraPose.getY() + tranVec.getZ() * Math.cos(cameraPose.getZ()) + tranVec.getX() * Math.cos(cameraPose.getZ() - Math.PI / 2d),
                            cameraPose.getZ() + tranVec.getY()),
                        new Rotation3d()
                    );
                    cornerCoordinates[j] = new Coordinate((float) corners[j].getX(), (float) corners[j].getY());
                    zPos += corners[j].getZ() / corners.length;
                }
                
                ExtendedObstacle temp = new ExtendedObstacle(cornerCoordinates, zPos);
                if(temp.obstacleCenter.getX() <= 0 || temp.obstacleCenter.getX() >= frc.robot.Path.Constants.fieldX
                || temp.obstacleCenter.getY() <= 0 || temp.obstacleCenter.getY() >= frc.robot.Path.Constants.fieldY) {
                    continue;
                }

                if(id != 3) {
                    otherObstacles.add(temp);
                } else {
                    robotObstacles.add(temp);
                }
            }
        }

        //Compares new obstacles to old obstacles in order to figure out actual new obstacles
        for(int i = 0; i < runtimeObstacles.size(); ++i) {
            for(int j = 0; j < otherObstacles.size(); ++j) {
                if(runtimeObstacles.get(i).parseObstacle(otherObstacles.get(j))) {
                    otherObstacles.get(j).updateVelocity(runtimeObstacles.get(i));
                    runtimeObstacles.set(i, otherObstacles.remove(j));
                    --j;
                }
            }
        }

        //Adds any lingering new obstacles to the runtime obstacles
        runtimeObstacles.addAll(otherObstacles);

        //TODO: Add robots correctly
        for(int i = 0; i < runtimeObstacles.size(); ++i) {
            for(int j = 0; j < robotObstacles.size(); ++j) {
                if(runtimeObstacles.get(i).parseRobot(robotObstacles.get(j))) {
                    robotObstacles.get(j).updateRobotVelocity(runtimeObstacles.get(i));
                    runtimeObstacles.set(i, robotObstacles.remove(j));
                    --j;
                }
            }
        }

        //If the obstacles cross the reef once, then they're inside the reef, so remove them
        for(int i = 0; i < runtimeObstacles.size(); ++i) {
            if(reef.isInside(runtimeObstacles.get(i).obstacleCenter)) {
                runtimeObstacles.get(i).setInReef();
                reefObstacles.add(runtimeObstacles.remove(i--));
            }
        }

        for(int i = 0; i < runtimeObstacles.size(); ++i) {
            runtimeObstacles.get(i).robotPeriodic();
        }

        for(int i = 0; i < reefObstacles.size(); ++i) {
            reefObstacles.get(i).robotPeriodic();
        }*/
    }

    public ArrayList<ExtendedObstacle> getRuntimeObstacles() {
        return runtimeObstacles;
    }

    public ArrayList<ExtendedObstacle> getReefObstacles() {
        return reefObstacles;
    }

    //Courtesy of Deepseek
    public void addReefObstacle(Coordinate xy, float z) {
        // Create a coral obstacle with a single vertex at the specified coordinate
        Coordinate[] vertices = new Coordinate[]{xy};
        ExtendedObstacle coral = new ExtendedObstacle(vertices, z);
        coral.setInReef(); // Mark as part of the reef
        reefObstacles.add(coral); // Add to reef obstacles list
    }
    
    //Courtesy of Deepseek
    public void removeReefObstacle(Coordinate xy, float z) {
        for (int i = 0; i < reefObstacles.size(); i++) {
            ExtendedObstacle obstacle = reefObstacles.get(i);
            
            // Check if the obstacle is algae and matches the position/height
            if (obstacle.isAlgae) {
                boolean positionMatches = 
                    obstacle.obstacleCenter.roughEquals(xy) &&
                    Math.abs(obstacle.zPosition - z) < 0.5f;
                
                if (positionMatches) {
                    reefObstacles.remove(i--);
                    return;
                }
            }
        }
    }

    public void addAlgae(Coordinate xy, float z) {
        Coordinate[] vertices = new Coordinate[]{xy};
        ExtendedObstacle algae = new ExtendedObstacle(vertices, z);
        algae.setInReef(); // Mark as part of the reef
        algae.setAlgae();
        reefObstacles.add(algae); // Add to reef obstacles list
    }
}

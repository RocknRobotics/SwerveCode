package frc.robot.ObstacleParser;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.wpilibj.smartdashboard.FieldObject2d;
import frc.robot.Path.Coordinate;

public class ExtendedObstacle extends frc.robot.Path.Obstacle {
    public float zPosition;
    private float[] velocity;
    public boolean inReef;
    private boolean robot;
    public boolean isAlgae;
    private float confidence; //How certain we are that the obstacle is still where it was
    private FieldObject2d glassObject;

    public ExtendedObstacle(Coordinate[] vertices, float zPosition) {
        super(vertices);
        this.zPosition = zPosition;
        velocity = new float[3];
        inReef = false;
        confidence = 1f;

        if(frc.robot.Swerve.Master.useGlass) {
            glassObject = frc.robot.Swerve.Master.field.getObject("Obstacle: " + "(" + obstacleCenter.getX() + ", " + obstacleCenter.getY() + ")");
        }
    }

    public void robotPeriodic() {
        if(frc.robot.Swerve.Master.useGlass) {
            glassObject.setPose(new Pose2d(obstacleCenter.getY(), frc.robot.Path.Constants.fieldX - obstacleCenter.getX(), new Rotation2d()));
        }
    }

    //Assumes the other obstacle already updated its position with respect to a velocity
    public void updateVelocity(ExtendedObstacle other) {
        other.obstacleCenter.add(-other.velocity[0], -other.velocity[1]);

        other.zPosition -= other.velocity[2];

        velocity[0] = this.obstacleCenter.getX() - other.obstacleCenter.getX();
        velocity[1] = this.obstacleCenter.getY() - other.obstacleCenter.getY();
        velocity[2] = this.zPosition - other.zPosition;
    }

    //TODO
    public void updateRobotVelocity(ExtendedObstacle other) {
        updateVelocity(other);
    }

    public boolean parseObstacle(ExtendedObstacle other) {
        if(isAlgae != other.isAlgae || Math.abs(this.zPosition - other.zPosition) > 0.5f) {
            return false;
        }

        return this.obstacleCenter.roughEquals(other.obstacleCenter);
    }

    //TODO
    //Different than above since robot information is sent over as incomplete vertices
    public boolean parseRobot(ExtendedObstacle robot) {
        robot.setRobot();

        if(!this.robot) {
            return false;
        } else {
            return parseObstacle(robot);
        }
    }

    public void updatePosition() {
        for(int i = 0; i < vertices.length; ++i) {
            vertices[i].add(velocity[0], velocity[1]);
        }

        zPosition += velocity[2];
        obstacleCenter.add(velocity[0], velocity[1]);
    }

    //Courtesy of Deepseek
    public void updateConfidence(float[] currentXYH) {
        try {
            Coordinate current = new Coordinate(currentXYH[0], currentXYH[1]);
            obstacleCenter.updateDistance(current);
            obstacleCenter.updateAngle(current);

            //Compute distance visibility
            float distanceVisibility;
            if(obstacleCenter.getDistance() <= Constants.VERY_CLOSE) {
                distanceVisibility = 0.2f;
            } else if(obstacleCenter.getDistance() <= Constants.OPTIMAL) {
                float t = (obstacleCenter.getDistance() - Constants.VERY_CLOSE) / (Constants.OPTIMAL - Constants.VERY_CLOSE);
                distanceVisibility = 0.2f + 0.8f * t;
            } else if(obstacleCenter.getDistance() <= Constants.FAR) {
                float t = (obstacleCenter.getDistance() - Constants.OPTIMAL) / (Constants.FAR - Constants.OPTIMAL);
                distanceVisibility = 1f - 0.8f * t;
            } else {
                distanceVisibility = 0.2f;
            }

            //Determine maximum camera score
            float maxCameraScore = 0f;

            //Front camera (0 degrees, lower)
            if(obstacleCenter.getAngle() >= frc.robot.Constants.PIF * 7f / 4f || obstacleCenter.getAngle() <= frc.robot.Constants.PIF / 4f) {
                float heightVisibility = (zPosition <= Constants.MAX_Z_LOWER) ? (1f - zPosition / Constants.MAX_Z_LOWER) : 0f;
                float cameraScore = heightVisibility * distanceVisibility;
                maxCameraScore = Math.max(maxCameraScore, cameraScore);
            }

            //Back camera (180 degrees, lower)
            if(obstacleCenter.getAngle() >= frc.robot.Constants.PIF * 3f / 4f && obstacleCenter.getAngle() <= frc.robot.Constants.PIF * 5f / 4f) {
                float heightVisibility = (zPosition <= Constants.MAX_Z_LOWER) ? (1f - zPosition / Constants.MAX_Z_LOWER) : 0f;
                float cameraScore = heightVisibility * distanceVisibility;
                maxCameraScore = Math.max(maxCameraScore, cameraScore);
            }

            //Left camera (90 degrees, higher)
            if(obstacleCenter.getAngle() >= frc.robot.Constants.PIF / 4f && obstacleCenter.getAngle() <= frc.robot.Constants.PIF * 3f / 4f) {
                float heightVisibility = Math.min(zPosition / Constants.MAX_Z_UPPER, 1f);
                float cameraScore = heightVisibility * distanceVisibility;
                maxCameraScore = Math.max(maxCameraScore, cameraScore);
            }

            //Right camera (270 degrees, higher)
            if(obstacleCenter.getAngle() >= frc.robot.Constants.PIF * 5f / 4f && obstacleCenter.getAngle() <= frc.robot.Constants.PIF * 7f / 4f) {
                float heightVisibility = Math.min(zPosition / Constants.MAX_Z_UPPER, 1f);
                float cameraScore = heightVisibility * distanceVisibility;
                maxCameraScore = Math.max(maxCameraScore, cameraScore);
            }

            //Determine reef multiplier
            float reefMultiplier = 1f;
            if(inReef) {
                if(isAlgae) {
                    reefMultiplier = Constants.ALGAE_REEF_DECAY;
                } else {
                    reefMultiplier = Constants.CORAL_REEF_DECAY;
                }
            }

            // Calculate decay factor and update confidence
            float decayRate = Constants.BASE_DECAY * maxCameraScore * reefMultiplier;
            float decayFactor = 1f - decayRate;
            confidence *= decayFactor;
            confidence = Math.max(confidence, 0f); // Ensure confidence doesn't go negative
        } catch(Exception e) {
            e.printStackTrace();
            confidence = 0f;
        }
    }

    public float getConfidence() {
        return confidence;
    }

    public void setInReef() {
        inReef = true;
    }

    public void setRobot() {
        robot = true;
    }

    public void setAlgae() {
        isAlgae = true;
    }

    public float getCost(Coordinate point) {
        obstacleCenter.updateDistance(point);

        if(obstacleCenter.getDistance() >= Constants.distanceCutoff) {
            return 0f;
        }

        float output = Constants.distanceScale / obstacleCenter.getDistance();

        return output;
    }
}

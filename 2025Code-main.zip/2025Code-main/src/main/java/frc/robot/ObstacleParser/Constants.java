package frc.robot.ObstacleParser;

import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.math.util.Units;
import frc.robot.Robot;

public class Constants {
    static final float VERY_CLOSE = 0.5f;
    static final float OPTIMAL = 2f;
    static final float FAR = 4f;
    static final float MAX_Z_LOWER = 0.5f;
    static final float MAX_Z_UPPER = 1f;
    static final float BASE_DECAY = Robot.isSimulation() ? 0f : 0.045f;
    static final float ALGAE_REEF_DECAY = 0.5f;
    static final float CORAL_REEF_DECAY = 0.1f;

    static final Translation3d objects[][] = new Translation3d[][]{
        new Translation3d[]{ //Algae
            new Translation3d(0d, 0d, -Units.inchesToMeters(16.25d / 2d)),
            new Translation3d(Units.inchesToMeters(16.25d / 2d), 0d, 0d),
            new Translation3d(0d, 0d, Units.inchesToMeters(16.25d / 2d)),
            new Translation3d(-Units.inchesToMeters(16.25d / 2d), 0d, 0d)
        },
        new Translation3d[]{ //Cage
            new Translation3d(0f, 0f, 0f)
        },
        new Translation3d[]{ //Coral
            new Translation3d(-Units.inchesToMeters(11.75d / 2d), 0d, 0d),
            new Translation3d(0d, Units.inchesToMeters(4.5d / 2d), -Units.inchesToMeters(4.5d / 2d)),
            new Translation3d(Units.inchesToMeters(11.75d / 2d), 0d, 0d),
            new Translation3d(0d, Units.inchesToMeters(4.5d / 2d), Units.inchesToMeters(4.5d / 2d))
        },
        new Translation3d[]{ //Robot
            new Translation3d(-Units.inchesToMeters(28d / 2d), 0f, 0f),
            new Translation3d(Units.inchesToMeters(28d / 2d), 0f, 0f),
            new Translation3d(Units.inchesToMeters(28d / 2d), Units.inchesToMeters(28d / 2d), 0f),
            new Translation3d(-Units.inchesToMeters(28d / 2d), Units.inchesToMeters(28d / 2d), 0f)
        }
    };

    static final float distanceCutoff = 3f;
    static final float distanceScale = 10f;
}

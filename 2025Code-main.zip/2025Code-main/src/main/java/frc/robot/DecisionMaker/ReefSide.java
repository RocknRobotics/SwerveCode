package frc.robot.DecisionMaker;

import java.util.ArrayList;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import frc.robot.Robot;
import frc.robot.ObstacleParser.ExtendedObstacle;
import frc.robot.Path.Coordinate;
import frc.robot.Path.Distance;
import frc.robot.Path.Obstacle;

public class ReefSide {
    public Branch[] branches;
    public boolean[] algae; // bottom or top algae
    public Coordinate algaeCoordinate; //where algae is
    private Coordinate algaeScoringCoordinate;
    private float[] algaeStationLength; // distance to left or right station
    private Distance[][] pathDistanceLookup;

    private boolean kickAlgae = false;
    private float[] lastCosts;

    public ReefSide(int index, Station[] stations, frc.robot.Path.Master pathMaster) {
        //Creates the left and right branch
        branches = new Branch[2];
        if(DriverStation.getAlliance().get().equals(Alliance.Blue)) {
            branches[0] = new Branch(index, Constants.leftInitialAngle, stations, pathMaster);
            branches[1] = new Branch(index, Constants.rightInitialAngle, stations, pathMaster);
        } else {
            branches[0] = new Branch(index, Constants.leftInitialAngle + frc.robot.Constants.PIF, stations, pathMaster);
            branches[1] = new Branch(index, Constants.rightInitialAngle + frc.robot.Constants.PIF, stations, pathMaster);
        }

        //Bottom spot, top spot
        algae = new boolean[2];
        
        algaeCoordinate = new Coordinate((branches[0].getCoordinate().getX() + branches[1].getCoordinate().getX()) / 2f, (branches[0].getCoordinate().getY() + branches[1].getCoordinate().getY()) / 2f);
        algaeScoringCoordinate = new Coordinate((branches[0].getScoringCoordinate().getX() + branches[1].getScoringCoordinate().getX()) / 2f, (branches[0].getScoringCoordinate().getY() + branches[1].getScoringCoordinate().getY()) / 2f);

        Coordinate complementAlgaeScoringCoordinate = algaeScoringCoordinate;
        
        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            complementAlgaeScoringCoordinate = algaeScoringCoordinate.getComplement();
        }

        algaeStationLength = new float[2];
        algaeStationLength[0] = stations[0].getMinPath(pathMaster, algaeScoringCoordinate);
        algaeStationLength[1] = stations[1].getMinPath(pathMaster, algaeScoringCoordinate);

        pathDistanceLookup = new Distance[(int) Math.ceil(frc.robot.Constants.PIF / 2f * frc.robot.Constants.anglePrecision) + 1][];

        for(int r = 0; r < pathDistanceLookup.length; ++r) {
            float closestDistance = Obstacle.OBMinDistance(r);
            pathDistanceLookup[r] = new Distance[(int) Math.ceil(frc.robot.Constants.distancePrecision * closestDistance) + 1];
            Robot.totalBytes += pathDistanceLookup[r].length;
            float xDelta = 1f / frc.robot.Constants.distancePrecision * frc.robot.Constants.cosLookup(((float) r) / frc.robot.Constants.anglePrecision);
            float yDelta = 1f / frc.robot.Constants.distancePrecision * frc.robot.Constants.sinLookup(((float) r) / frc.robot.Constants.anglePrecision);
            float[] current = new float[]{-xDelta, -yDelta, 0f};
            Coordinate currCoord = new Coordinate(-xDelta, -yDelta);

            for(int c = 0; c < pathDistanceLookup[r].length; ++c) {
                current[0] += xDelta;
                current[1] += yDelta;
                currCoord.add(xDelta, yDelta);
                currCoord.updateDistance(complementAlgaeScoringCoordinate);

                if(pathMaster.pastHalf(currCoord)) {
                    pathDistanceLookup[r][c] = new Distance(currCoord.getDistance());
                } else {
                    try {
                        float p[] = pathMaster.calculateNextPoint(current, new float[]{complementAlgaeScoringCoordinate.getX(), complementAlgaeScoringCoordinate.getY(), 0f}, Constants.emptyObstacleList);
                        pathDistanceLookup[r][c] = new Distance(p[p.length - 1]);
                    } catch(Exception e) {
                        pathDistanceLookup[r][c] = new Distance(currCoord.getDistance());
                    }
                }
            }
        }

        lastCosts = new float[algae.length];

        for(int i = 0; i < lastCosts.length; ++i) {
            lastCosts[i] = -1f;
        }
    }

    public float[][] costFunction(float[] currentXYH, int[] numPerLevel, ArrayList<ExtendedObstacle> runtimeObstacles) {
        return new float[][]{branches[0].costFunction(currentXYH, algae, numPerLevel, runtimeObstacles), branches[1].costFunction(currentXYH, algae, numPerLevel, runtimeObstacles)};
    }

    //Used specifically for algae removal
    public float[] algaeCostFunction(float[] currentXYH, int numAlgae, ArrayList<ExtendedObstacle> runtimeObstacles, int stationIndex) {
        if(!kickAlgae) {
            lastCosts = new float[]{-1f, -1f};
            return new float[]{-1f, -1f};
        }

        Coordinate current = new Coordinate(currentXYH[0], currentXYH[1]);

        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            current = current.getComplement();
        }

        current.updateDistance(frc.robot.Path.Constants.origin);
        current.updateAngle(frc.robot.Path.Constants.origin);
        int r = (int) ((current.getAngle() < 0 ? 0f : current.getAngle() > frc.robot.Constants.PIF / 2f ? frc.robot.Constants.PIF / 2f : current.getAngle()) * frc.robot.Constants.anglePrecision);
        int c = (int) (current.getDistance() * frc.robot.Constants.distancePrecision);

        float rFraction = ((current.getAngle() < 0 ? 0f : current.getAngle() > frc.robot.Constants.PIF / 2f ? frc.robot.Constants.PIF / 2f : current.getAngle()) * frc.robot.Constants.anglePrecision) - r;
        float cFraction = (current.getDistance() * frc.robot.Constants.distancePrecision) - c;

        int rNext = (r + 1) % pathDistanceLookup.length;

        float[] output = new float[2];

        for(ExtendedObstacle obstacle: runtimeObstacles) {
            if(obstacle.isInside(algaeScoringCoordinate)) {
                lastCosts = new float[]{-1f, -1f};
                return new float[]{-1f, -1f};
            }
        }

        for(int i = 0; i < 2; ++i) {
            if(algae[i]) {
                if(output[i] != -1f) {
                    output[i] = (algaeStationLength[stationIndex] + 
                        ((1 - rFraction) * (1 - cFraction) * pathDistanceLookup[r][Math.min(c, pathDistanceLookup[r].length - 1)].getFloatValue()
                        + rFraction * (1 - cFraction) * pathDistanceLookup[r][Math.min(c + 1, pathDistanceLookup[r].length - 1)].getFloatValue()
                        + (1 - rFraction) * cFraction * pathDistanceLookup[rNext][Math.min(c, pathDistanceLookup[rNext].length - 1)].getFloatValue()
                        + rFraction * cFraction * pathDistanceLookup[rNext][Math.min(c + 1, pathDistanceLookup[rNext].length - 1)].getFloatValue())) 
                        / frc.robot.Constants.sqrtLookup(frc.robot.Constants.sqrtLookup(1f + numAlgae));
                    output[i] /= frc.robot.Swerve.Constants.maxTranslationalSpeed;
                    output[i] *= Constants.algaeCostFactor;

                    for(int id = 0; id < runtimeObstacles.size(); ++id) {
                        output[i] += runtimeObstacles.get(id).getCost(algaeScoringCoordinate);
                    }

                    if(lastCosts[i] != -1f) {
                        output[i] = Math.min(output[i], lastCosts[i]);
                    }
    
                    lastCosts[i] = output[i];
                }
            } else {
                lastCosts[i] = -1f;
                output[i] = -1f;
            }
        }
        
        return output;
    }

    public Coordinate getAlgaeCoordinate() {
        return algaeCoordinate;
    }

    public Coordinate getAlgaeScoringCoordinate() {
        return algaeScoringCoordinate;
    }

    public Coordinate getBranchCoordinate(int lr) {
        return lr == 0 ? branches[0].getCoordinate() : branches[1].getCoordinate();
    }

    public Coordinate getScoringCoordinate(int lr) {
        return lr == 0 ? branches[0].getScoringCoordinate() : branches[1].getScoringCoordinate();
    }

    public Coordinate getTroughCoordinate(int lr) {
        return lr == 0 ? branches[0].troughScoringCoordinate : branches[1].troughScoringCoordinate;
    }

    public int numAlgae() {
        return (algae[0] ? 1 : 0) + (algae[1] ? 1 : 0);
    }

    public int[] numPerLevel() {
        int[] numPerLevel = new int[4];

        for(int i = 0; i < 4; ++i) {
            numPerLevel[i] += branches[0].hasCoral(i) ? 1 : 0;
            numPerLevel[i] += branches[1].hasCoral(i) ? 1 : 0;
        }

        return numPerLevel;
    }

    public void resetCosts() {
        for(int i = 0; i < lastCosts.length; ++i) {
            lastCosts[i] = -1f;
        }
    }

    public void resetBranchCosts() {
        branches[0].resetCosts();
        branches[1].resetCosts();
    }
}

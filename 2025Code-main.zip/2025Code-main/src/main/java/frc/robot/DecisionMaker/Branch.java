package frc.robot.DecisionMaker;

import java.util.ArrayList;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import frc.robot.Robot;
import frc.robot.ObstacleParser.ExtendedObstacle;
import frc.robot.Path.Coordinate;
import frc.robot.Path.Distance;
import frc.robot.Path.Obstacle;

public class Branch {
    private Coordinate branchCoordinate;
    private float stationLength;
    private Coordinate scoringCoordinate;
    public boolean[] hasCoral;
    private Distance[][] pathDistanceLookup;
    private float[] lastCosts;

    public Coordinate troughScoringCoordinate;

    public Branch(int index, float initialAngle, Station[] stations, frc.robot.Path.Master pathMaster) {
        hasCoral = new boolean[4];
        branchCoordinate = new Coordinate(Constants.reefCentreX + frc.robot.Constants.cosLookup(index * Constants.angleChange + initialAngle) * Constants.reefDistance, Constants.reefCentreY + frc.robot.Constants.sinLookup(index * Constants.angleChange + initialAngle) * Constants.reefDistance);
        Obstacle reef = frc.robot.Path.Constants.reefs[0];
        int reefIndex = index + 1;

        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            reef = frc.robot.Path.Constants.reefs[1];
        }

        scoringCoordinate = reef.updateMinDistance(branchCoordinate, reefIndex % 6, (reefIndex + 1) % 6);
        Coordinate complementScoringCoordinate = scoringCoordinate;

        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            complementScoringCoordinate = scoringCoordinate.getComplement();
        }

        //System.out.println("Index: " + index + ", " + scoringCoordinate.toString());
        
        stationLength = Math.min(stations[0].getMinPath(pathMaster, scoringCoordinate), stations[1].getMinPath(pathMaster, scoringCoordinate));

        pathDistanceLookup = new Distance[(int) Math.ceil(frc.robot.Constants.PIF / 2f * frc.robot.Constants.anglePrecision) + 1][];

        for(int r = 0; r < pathDistanceLookup.length; ++r) {
            float closestDistance = Obstacle.OBMinDistance(r);
            pathDistanceLookup[r] = new Distance[(int) Math.ceil(frc.robot.Constants.distancePrecision * closestDistance) + 1];
            Robot.totalBytes += pathDistanceLookup[r].length;
            float xDelta = 1f / frc.robot.Constants.distancePrecision * frc.robot.Constants.cosLookup(((float) r) / frc.robot.Constants.anglePrecision);
            float yDelta = 1f / frc.robot.Constants.distancePrecision * frc.robot.Constants.sinLookup(((float) r) / frc.robot.Constants.anglePrecision);
            float[] current = new float[]{-xDelta, -yDelta, 0f};
            Coordinate currCoord = new Coordinate(-xDelta, -yDelta);

            for(int c = 0; c < pathDistanceLookup[r].length; ++c) {
                current[0] += xDelta;
                current[1] += yDelta;
                currCoord.add(xDelta, yDelta);
                currCoord.updateDistance(complementScoringCoordinate);

                if(pathMaster.pastHalf(currCoord)) {
                    pathDistanceLookup[r][c] = new Distance(currCoord.getDistance());
                } else {
                    try {
                        float p[] = pathMaster.calculateNextPoint(current, new float[]{complementScoringCoordinate.getX(), complementScoringCoordinate.getY(), 0f}, Constants.emptyObstacleList);
                        pathDistanceLookup[r][c] = new Distance(p[p.length - 1]);
                    } catch(Exception e) {
                        pathDistanceLookup[r][c] = new Distance(currCoord.getDistance());
                    }
                }
            }
        }

        lastCosts = new float[4];

        for(int i = 0; i < lastCosts.length; ++i) {
            lastCosts[i] = -1f;
        }

        if(initialAngle == Constants.leftInitialAngle || initialAngle == Constants.leftInitialAngle + frc.robot.Constants.PIF) {
            reef.updateMinDistance(reef.vertices[reefIndex % 6]);
        } else {
            reef.updateMinDistance(reef.vertices[(reefIndex + 1) % 6]);
        }

        troughScoringCoordinate = reef.closestPoint;
        troughScoringCoordinate.updateAngle(reef.obstacleCenter);
        troughScoringCoordinate = new Coordinate(troughScoringCoordinate.getX() + 0.1f * frc.robot.Constants.cosLookup(troughScoringCoordinate.getAngle()), troughScoringCoordinate.getY() + 0.1f * frc.robot.Constants.sinLookup(troughScoringCoordinate.getAngle()));

        //System.out.println("Index: " + index + ", " + troughScoringCoordinate.toString());

    }

    public Coordinate getCoordinate() {
        return branchCoordinate;
    }

    public Coordinate getScoringCoordinate() {
        return scoringCoordinate;
    }

    public float[] costFunction(float[] currentXYH, boolean[] algae, int[] numPerLevel, ArrayList<ExtendedObstacle> runtimeObstacles) {
        Coordinate current = new Coordinate(currentXYH[0], currentXYH[1]);

        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            current = current.getComplement();
        }
        
        current.updateDistance(frc.robot.Path.Constants.origin);
        current.updateAngle(frc.robot.Path.Constants.origin);
        int r = (int) ((current.getAngle() < 0 ? 0f : current.getAngle() > frc.robot.Constants.PIF / 2f ? frc.robot.Constants.PIF / 2f : current.getAngle()) * frc.robot.Constants.anglePrecision);
        int c = (int) (current.getDistance() * frc.robot.Constants.distancePrecision);

        float rFraction = ((current.getAngle() < 0 ? 0f : current.getAngle() > frc.robot.Constants.PIF / 2f ? frc.robot.Constants.PIF / 2f : current.getAngle()) * frc.robot.Constants.anglePrecision) - r;
        float cFraction = (current.getDistance() * frc.robot.Constants.distancePrecision) - c;

        int rNext = (r + 1) % pathDistanceLookup.length;

        float[] output = new float[4];

        //If there's an algae touching the spot, then the spot it invalid
        if(algae[0]) {
            lastCosts[1] = -1f;
            lastCosts[2] = -1f;
            output[1] = -1f;
            output[2] = -1f;
        } else if(algae[1]) {
            lastCosts[2] = -1f;
            output[2] = -1f;
        }

        //System.out.println("Scoring Coord: " + scoringCoordinate + ", PD: " + pathDistanceLookup[r][c] + ", SL:" + stationLength);

        for(ExtendedObstacle obstacle: runtimeObstacles) {
            if(obstacle.isInside(scoringCoordinate)) {
                lastCosts = new float[]{-1f, -1f, -1f, -1f};
                return new float[]{-1f, -1f, -1f, -1f};
            }
        }

        output[3] = -1f; //Coral 3 is always invalid since it can't be reached

        for(int i = 0; i < output.length; ++i) {
            //If we already have a coral there, then it's an invalid spot
            if(hasCoral[i]) {
                lastCosts[i] = -1f;
                output[i] = -1f;
                continue;
            }

            if(output[i] != -1f) {
                //Multiply by coral worth
                output[i] = Constants.coralWorth[3] / Constants.coralWorth[i];
                //Divide by the time to get there (doesn't use path distance unless path planning can be cut down enough)
                output[i] *= 
                    (((1 - rFraction) * (1 - cFraction) * pathDistanceLookup[r][Math.min(c, pathDistanceLookup[r].length - 1)].getFloatValue()
                    + rFraction * (1 - cFraction) * pathDistanceLookup[r][Math.min(c + 1, pathDistanceLookup[r].length - 1)].getFloatValue()
                    + (1 - rFraction) * cFraction * pathDistanceLookup[rNext][Math.min(c, pathDistanceLookup[rNext].length - 1)].getFloatValue()
                    + rFraction * cFraction * pathDistanceLookup[rNext][Math.min(c + 1, pathDistanceLookup[rNext].length - 1)].getFloatValue()) 
                    + stationLength) 
                    / frc.robot.Swerve.Constants.maxTranslationalSpeed;

                //If we don't have five on that level yet, then makes it's cost less to increase likelihood of going it it
                if(numPerLevel[i] < 5) {
                    output[i] /= Constants.fillAllCost;
                }

                for(int id = 0; id < runtimeObstacles.size(); ++id) {
                    output[i] += runtimeObstacles.get(id).getCost(scoringCoordinate);
                }

                if(lastCosts[i] != -1f) {
                    output[i] = Math.min(output[i], lastCosts[i]);
                }

                lastCosts[i] = output[i];
            }
        }

        return output;
    }

    public boolean hasCoral(int i) {
        return hasCoral[i];
    }

    public void resetCosts() {
        for(int i = 0; i < lastCosts.length; ++i) {
            lastCosts[i] = -1f;
        }
    }
}

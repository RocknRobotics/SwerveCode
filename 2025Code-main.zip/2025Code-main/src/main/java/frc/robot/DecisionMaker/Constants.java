package frc.robot.DecisionMaker;

import java.util.ArrayList;

import edu.wpi.first.math.util.Units;
import frc.robot.ObstacleParser.ExtendedObstacle;
import frc.robot.Path.Coordinate;

public class Constants {
    static float leftX = 3.841f;
    static float leftY = 3.699571f;
    static float rightX = 4.170f;
    static float rightY = leftY;
    
    public static float[] coralHeights = {0.472f, 0.778096f, 1.179021f, (float) Units.inchesToMeters(72f - 7f)};
    static float[] algaeHeights = {(coralHeights[0] + coralHeights[1]) / 2f, (coralHeights[1] + (((coralHeights[0] + coralHeights[1]) / 2f) - coralHeights[0]))};

    //TODO
    //Need methods to grab teh reefx feildx and reef y and feild y
    static float reefCentreX = (frc.robot.Path.Constants.reefX[0] + (frc.robot.Path.Constants.fieldX - frc.robot.Path.Constants.reefX[0])) / 2f;
    static float reefCentreY = (frc.robot.Path.Constants.blueReefY[0] + frc.robot.Path.Constants.blueReefY[2]) / 2f;

    static final float reefDistance = frc.robot.Constants.sqrtLookup((reefCentreX - leftX) * (reefCentreX - leftX) + (reefCentreY - leftY) * (reefCentreY - leftY));

    static final float angleChange = frc.robot.Constants.PIF / 3f;

    static float leftInitialAngle = frc.robot.Constants.atanLookup(leftY - reefCentreY, leftX - reefCentreX);
    static float rightInitialAngle = frc.robot.Constants.atanLookup(rightY - reefCentreY, rightX - reefCentreX);

    public static float[] coralWorth = {3f, 4f, 6f, 7f};

    public static float fillAllCost = 1f;

    public static float algaeCostFactor = 10000f;

    //The station coordinates we can pickup from, starting from the coordinate closest to the driver station, and moving further away from it
    static final Coordinate[] leftStationCoordinates = new Coordinate[]{
        new Coordinate(1.1215f, 0.185f),
        new Coordinate(1.002f, 0.3495f),
        new Coordinate(0.8825f, 0.514f),
        new Coordinate(0.7635f, 0.678f),
        new Coordinate(0.644f, 0.843f),
        new Coordinate(0.5245f, 1.007f),
        new Coordinate(0.405f, 1.1715f),
        new Coordinate(0.2855f, 1.336f),
        new Coordinate(0.1665f, 1.5005f)
    };

    //How much to offset the robot to the "right" (aligned with the station) in order to account for the hopper offset
    static final float hopperOffset = (float) Units.inchesToMeters(2.5f);

    static enum behaviours {
        ScoreCoral0,
        ScoreCoral1,
        ScoreCoral2,
        ScoreCoral3,
        KickAlgae0,
        KickAlgae1,
        StationPickup
    };

    static final float DISTANCE_THRESHOLD = 0.25f; // meters

    static final ArrayList<ExtendedObstacle> emptyObstacleList = new ArrayList<ExtendedObstacle>();
}

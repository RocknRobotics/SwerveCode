package frc.robot.DecisionMaker;

import java.util.ArrayList;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import frc.robot.ObstacleParser.ExtendedObstacle;
import frc.robot.Path.Coordinate;

public class Reef {
    public ReefSide[] sides;
    public Station[] stations;

    public int lastR = 0;
    public int lastC = 0;
    public int lastK = 0;

    private boolean[] stationOff;

    public Reef(frc.robot.Path.Master pathMaster){
        stationOff = new boolean[]{false, false};
        stations = new Station[2];
        Thread one = new Thread(() -> {
            stations[0] = new Station(pathMaster, true);
        });
        one.start();

        stations[1] = new Station(pathMaster, false);
        
        sides = new ReefSide[6];

        try {
            one.join();
        } catch(InterruptedException e) {
            e.printStackTrace();
        }

        one = new Thread(() -> {
            for(int i = 0; i < 3; ++i) {
                sides[i] = new ReefSide(i, stations, pathMaster);
            }
        });
        one.start();

        for(int i = 3; i < sides.length; ++i) {
            sides[i] = new ReefSide(i, stations, pathMaster);
        }

        try {
            one.join();
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int numAlgae() {
        int numAlgae = 0;

        for(int i = 0; i < sides.length; ++i) {
            numAlgae += sides[i].numAlgae();
        }

        return numAlgae;
    }

    public int[] numPerLevel() {
        int[] numPerLevel = new int[4];

        for(int i = 0; i < sides.length; ++i) {
            int[] temp = sides[i].numPerLevel();

            for(int j = 0; j < 4; ++j) {
                numPerLevel[j] += temp[j]; 
            }
        }

        return numPerLevel;
    }

    public Behaviour nextBehaviour(frc.robot.Path.Master pathMaster, float[] currentXYH, ArrayList<ExtendedObstacle> runtimeObstacles, boolean hasCoral) {
        if(!hasCoral) { //Either need to get a new coral or need to remove some algae
            float[][] costs = new float[7][2];
            costs[6] = coralStationCostFunction(currentXYH, runtimeObstacles);
            int minStationIndex = costs[6][0] == -1f ? 1 : (costs[6][1] == -1f ? 0 : (costs[6][0] < costs[6][1] ? 0 : 1));

            int numAlgae = numAlgae();

            for(int i = 0; i < 6; ++i) {
                costs[i] = sides[i].algaeCostFunction(currentXYH, numAlgae, runtimeObstacles, minStationIndex);
            }

            float minCost = Float.MAX_VALUE;
            int minR = -1;
            int minC = -1;

            for(int r = 0; r < costs.length; ++r) {
                for(int c = 0; c < costs[r].length; ++c) {
                    if(costs[r][c] != -1f && costs[r][c] < minCost) {
                        minCost = costs[r][c];
                        minR = r;
                        minC = c;
                    }
                }
            }

            lastR = minR;
            lastC = minC;

            //Go to a station
            if(minR == 6) {
                return new Behaviour(stations[minC].getClosestCoordinate(), Constants.behaviours.StationPickup, DriverStation.getAlliance().get().equals(Alliance.Blue) == (minC == 0));
            } else {
                //Go kick off an algae
                return new Behaviour(sides[minR].getAlgaeCoordinate(), minC == 0 ? Constants.behaviours.KickAlgae0 : Constants.behaviours.KickAlgae1, sides[minR].getAlgaeScoringCoordinate());
            }
        } else {
            float[][][] costs = new float[6][2][4];
            int[] numPerLevel = numPerLevel();

            for(int i = 0; i < costs.length; ++i) {
                costs[i] = sides[i].costFunction(currentXYH, numPerLevel, runtimeObstacles);
            }

            float minCost = Float.MAX_VALUE;
            int minR = -1;
            int minC = -1;
            int minK = -1;

            for(int r = 0; r < costs.length; ++r) {
                for(int c = 0; c < costs[r].length; ++c) {
                    for(int k = 0; k < costs[r][c].length; ++k) {
                        if(costs[r][c][k] != -1f && costs[r][c][k] < minCost) {
                            minCost = costs[r][c][k];
                            minR = r;
                            minC = c;
                            minK = k;
                        }
                    }
                }
            }

            lastR = minR;
            lastC = minC;
            lastK = minK;

            if(minK != 0) {
                return new Behaviour(sides[minR].getBranchCoordinate(minC),
                    minK == 1 ? Constants.behaviours.ScoreCoral1 :
                    minK == 2 ? Constants.behaviours.ScoreCoral2 : Constants.behaviours.ScoreCoral3, sides[minR].getScoringCoordinate(minC)
                );
            } else {
                return new Behaviour(sides[minR].getBranchCoordinate(minC), Constants.behaviours.ScoreCoral0, sides[minR].getTroughCoordinate(minC));
            }
        }
    }

    public float[] coralStationCostFunction(float[] currentXYH, ArrayList<ExtendedObstacle> runtimeObstacles) {
        Coordinate current = new Coordinate(currentXYH[0], currentXYH[1]);
        return new float[]{stationOff[0] ? -1f : stations[0].costFunction(current, runtimeObstacles), stationOff[1] ? -1f : stations[1].costFunction(current, runtimeObstacles)};
    }

    //Courtesy of Deepseek
    public void updateReef(ArrayList<ExtendedObstacle> reefObstacles) {
        for (ReefSide side : sides) {
            // Reset algae flags for this side
            side.algae[0] = false;
            side.algae[1] = false;
            int algaeFound = 0;
    
            // Check each obstacle for algae in this side's area
            for (ExtendedObstacle obstacle : reefObstacles) {
                if (obstacle.isAlgae) {
                    obstacle.obstacleCenter.updateDistance(side.algaeCoordinate);
    
                    if (obstacle.obstacleCenter.getDistance() <= Constants.DISTANCE_THRESHOLD && algaeFound < 2) {
                        side.algae[algaeFound] = true;
                        algaeFound++;
                    }
                }
            }
    
            // Update coral status for each branch in the side
            for (Branch branch : side.branches) {
                // Reset hasCoral for the branch
                for (int i = 0; i < branch.hasCoral.length; i++) {
                    branch.hasCoral[i] = false;
                }
    
                // Check each obstacle for corals in this branch's scoring coordinate
                for (ExtendedObstacle obstacle : reefObstacles) {
                    if (!obstacle.isAlgae) {
                        obstacle.obstacleCenter.updateDistance(branch.getCoordinate());
    
                        if (obstacle.obstacleCenter.getDistance() <= Constants.DISTANCE_THRESHOLD) {
                            float z = obstacle.zPosition;
                            int closestLevel = 0;
                            float minDiff = Math.abs(z - Constants.coralHeights[0]);
                            for (int i = 1; i < Constants.coralHeights.length; i++) {
                                float diff = Math.abs(z - Constants.coralHeights[i]);
                                if (diff < minDiff) {
                                    minDiff = diff;
                                    closestLevel = i;
                                }
                            }
    
                            if (closestLevel >= 0 && closestLevel < 4) {
                                branch.hasCoral[closestLevel] = true;
                            }
                        }
                    }
                }
            }
        }
    }

    public void toggleStation(boolean left) {
        stationOff[left == true ? 0 : 1] = !stationOff[left == true ? 0 : 1];
    }

    public void resetCosts() {
        stations[0].resetCosts();
        stations[1].resetCosts();

        for(int i = 0; i < sides.length; ++i) {
            sides[i].resetCosts();
        }
    }

    public void resetBranchCosts() {
        for(int i = 0; i < sides.length; ++i) {
            sides[i].resetBranchCosts();
        }
    }
}

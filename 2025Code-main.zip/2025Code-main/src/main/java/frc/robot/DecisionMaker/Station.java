package frc.robot.DecisionMaker;

import java.util.ArrayList;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import frc.robot.Robot;
import frc.robot.ObstacleParser.ExtendedObstacle;
import frc.robot.Path.Coordinate;
import frc.robot.Path.Distance;
import frc.robot.Path.Obstacle;

public class Station {
    private Coordinate closestCoordinate;
    private Coordinate[] scoringLocations;
    private Distance[][][] pathDistanceLookup;
    private float[] lastCosts;
    public Coordinate farCoordinate;
    public Coordinate closeCoordinate;

    public Station(frc.robot.Path.Master pathMaster, boolean left) {
        scoringLocations = new Coordinate[Constants.leftStationCoordinates.length - 1];
        Coordinate[] complementScoringLocations = new Coordinate[scoringLocations.length];

        for(int i = 0; i < scoringLocations.length; ++i) {
            if(DriverStation.getAlliance().get().equals(Alliance.Blue)) {
                if(left) {
                    scoringLocations[i] = new Coordinate(frc.robot.Path.Constants.robotDiagonalHalf * frc.robot.Constants.cosLookup(frc.robot.Constants.PIF / 4f) + Constants.leftStationCoordinates[i + 1].getX() + Constants.hopperOffset * frc.robot.Constants.cosLookup(frc.robot.Constants.PIF / 4f - frc.robot.Constants.PIF / 2f), frc.robot.Path.Constants.robotDiagonalHalf * frc.robot.Constants.sinLookup(frc.robot.Constants.PIF / 4f) + Constants.leftStationCoordinates[i + 1].getY() + Constants.hopperOffset * frc.robot.Constants.sinLookup(frc.robot.Constants.PIF / 4f - frc.robot.Constants.PIF / 2f));
                    complementScoringLocations[i] = scoringLocations[i];
                } else {
                    scoringLocations[i] = new Coordinate(frc.robot.Path.Constants.robotDiagonalHalf * frc.robot.Constants.cosLookup(frc.robot.Constants.PIF * 3f / 4f) + frc.robot.Path.Constants.fieldX - Constants.leftStationCoordinates[i].getX() + Constants.hopperOffset * frc.robot.Constants.cosLookup(frc.robot.Constants.PIF * 3f / 4f - frc.robot.Constants.PIF / 2f), frc.robot.Path.Constants.robotDiagonalHalf * frc.robot.Constants.sinLookup(frc.robot.Constants.PIF * 3f / 4f) + Constants.leftStationCoordinates[i].getY() + Constants.hopperOffset * frc.robot.Constants.sinLookup(frc.robot.Constants.PIF * 3f / 4f - frc.robot.Constants.PIF / 2f));
                    complementScoringLocations[i] = scoringLocations[i];
                }
            } else {
                if(left) {
                    scoringLocations[i] = new Coordinate(frc.robot.Path.Constants.robotDiagonalHalf * frc.robot.Constants.cosLookup(frc.robot.Constants.PIF * 5f / 4f) + frc.robot.Path.Constants.fieldX - Constants.leftStationCoordinates[i + 1].getX() + Constants.hopperOffset * frc.robot.Constants.cosLookup(frc.robot.Constants.PIF * 5f / 4f - frc.robot.Constants.PIF / 2f), frc.robot.Path.Constants.robotDiagonalHalf * frc.robot.Constants.sinLookup(frc.robot.Constants.PIF * 5f / 4f) + frc.robot.Path.Constants.fieldY - Constants.leftStationCoordinates[i + 1].getY() + Constants.hopperOffset * frc.robot.Constants.sinLookup(frc.robot.Constants.PIF * 5f / 4f - frc.robot.Constants.PIF / 2f));
                    complementScoringLocations[i] = scoringLocations[i].getComplement();
                } else {
                    scoringLocations[i] = new Coordinate(frc.robot.Path.Constants.robotDiagonalHalf * frc.robot.Constants.cosLookup(frc.robot.Constants.PIF * 7f / 4f) + Constants.leftStationCoordinates[i].getX() + Constants.hopperOffset * frc.robot.Constants.cosLookup(frc.robot.Constants.PIF * 7f / 4f - frc.robot.Constants.PIF / 2f), frc.robot.Path.Constants.robotDiagonalHalf * frc.robot.Constants.sinLookup(frc.robot.Constants.PIF * 7f / 4f) + frc.robot.Path.Constants.fieldY - Constants.leftStationCoordinates[i].getY() + Constants.hopperOffset * frc.robot.Constants.sinLookup(frc.robot.Constants.PIF * 7f / 4f - frc.robot.Constants.PIF / 2f));
                    complementScoringLocations[i] = scoringLocations[i].getComplement();
                }
            }

            //System.out.println(scoringLocations[i].toString());
        }

        closeCoordinate = scoringLocations[0];
        farCoordinate = scoringLocations[scoringLocations.length - 1];

        pathDistanceLookup = new Distance[(int) Math.ceil(frc.robot.Constants.PIF / 2f * frc.robot.Constants.anglePrecision) + 1][][];

        for(int r = 0; r < pathDistanceLookup.length; ++r) {
            float closestDistance = Obstacle.OBMinDistance(r);
            pathDistanceLookup[r] = new Distance[(int) Math.ceil(frc.robot.Constants.distancePrecision * closestDistance) + 1][scoringLocations.length];
            Robot.totalBytes += pathDistanceLookup[r].length * scoringLocations.length;
            float xDelta = 1f / frc.robot.Constants.distancePrecision * frc.robot.Constants.cosLookup(((float) r) / frc.robot.Constants.anglePrecision);
            float yDelta = 1f / frc.robot.Constants.distancePrecision * frc.robot.Constants.sinLookup(((float) r) / frc.robot.Constants.anglePrecision);
            float[] current = new float[]{-xDelta, -yDelta, 0f};
            Coordinate currCoord = new Coordinate(-xDelta, -yDelta);

            for(int c = 0; c < pathDistanceLookup[r].length; ++c) {
                current[0] += xDelta;
                current[1] += yDelta;
                currCoord.add(xDelta, yDelta);
                
                for(int l = 0; l < pathDistanceLookup[r][c].length; ++l) {
                    currCoord.updateDistance(complementScoringLocations[l]);

                    if(pathMaster.pastHalf(currCoord)) {
                        pathDistanceLookup[r][c][l] = new Distance(currCoord.getDistance());
                    } else {
                        try {
                            float p[] = pathMaster.calculateNextPoint(current, new float[]{complementScoringLocations[l].getX(), complementScoringLocations[l].getY(), 0f}, Constants.emptyObstacleList);
                            pathDistanceLookup[r][c][l] = new Distance(p[p.length - 1]);
                        } catch(Exception e) {
                            pathDistanceLookup[r][c][l] = new Distance(currCoord.getDistance());
                        }
                    }
                }
            }
        }

        lastCosts = new float[scoringLocations.length];

        for(int i = 0; i < lastCosts.length; ++i) {
            lastCosts[i] = -1f;
        }
    }

    //TODO
    public float costFunction(Coordinate current, ArrayList<ExtendedObstacle> runtimeObstacles) {
        float[] costs = new float[scoringLocations.length];
        float minCost = Float.MAX_VALUE;
        int minIndex = -1;
        float[] distanceCosts = new float[costs.length];

        for(int i = 0; i < runtimeObstacles.size(); ++i) {
            for(int j = 0; j < costs.length; ++j) {
                if(costs[j] == -1f || runtimeObstacles.get(i).isInsideNoLookup(scoringLocations[j])) {
                    costs[j] = -1f;
                } else {
                    distanceCosts[j] += runtimeObstacles.get(i).getCost(scoringLocations[j]);
                }
            }
        }

        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            current = current.getComplement();
        }

        current.updateDistance(frc.robot.Path.Constants.origin);
        current.updateAngle(frc.robot.Path.Constants.origin);
        int r = (int) ((current.getAngle() < 0 ? 0f : current.getAngle() > frc.robot.Constants.PIF / 2f ? frc.robot.Constants.PIF / 2f : current.getAngle()) * frc.robot.Constants.anglePrecision);
        int c = (int) (current.getDistance() * frc.robot.Constants.distancePrecision);

        float rFraction = ((current.getAngle() < 0 ? 0f : current.getAngle() > frc.robot.Constants.PIF / 2f ? frc.robot.Constants.PIF / 2f : current.getAngle()) * frc.robot.Constants.anglePrecision) - r;
        float cFraction = (current.getDistance() * frc.robot.Constants.distancePrecision) - c;

        int rNext = (r + 1) % pathDistanceLookup.length;

        for(int i = 0; i < costs.length; ++i) {
            if(costs[i] == -1f) {
                lastCosts[i] = -1f;
                continue;
            } else {
                costs[i] = 
                    ((1 - rFraction) * (1 - cFraction) * pathDistanceLookup[r][Math.min(c, pathDistanceLookup[r].length - 1)][i].getFloatValue()
                    + rFraction * (1 - cFraction) * pathDistanceLookup[r][Math.min(c + 1, pathDistanceLookup[r].length - 1)][i].getFloatValue()
                    + (1 - rFraction) * cFraction * pathDistanceLookup[rNext][Math.min(c, pathDistanceLookup[rNext].length - 1)][i].getFloatValue()
                    + rFraction * cFraction * pathDistanceLookup[rNext][Math.min(c + 1, pathDistanceLookup[rNext].length - 1)][i].getFloatValue())
                    / frc.robot.Swerve.Constants.maxTranslationalSpeed;
                costs[i] += distanceCosts[i];

                if(lastCosts[i] != -1f) {
                    costs[i] = Math.min(costs[i], lastCosts[i]);
                }

                lastCosts[i] = costs[i];

                if(costs[i] < minCost) {
                    minCost = costs[i];
                    minIndex = i;
                }
            }
        }

        closestCoordinate = scoringLocations[minIndex];

        return minCost;
    }

    public Coordinate getClosestCoordinate() {
        return closestCoordinate;
    }

    public float getMinPath(frc.robot.Path.Master pathMaster, Coordinate start) {
        float minPath = Float.MAX_VALUE;
        float[] startArr = new float[]{start.getX(), start.getY(), 0f};
        
        for(int i = 0; i < scoringLocations.length; ++i) {
            float[] p = pathMaster.calculateNextPoint(startArr, new float[]{scoringLocations[i].getX(), scoringLocations[i].getY(), 0f}, Constants.emptyObstacleList);
            minPath = Math.min(minPath, p[p.length - 1]);
        }

        return minPath;
    }

    public void resetCosts() {
        for(int i = 0; i < lastCosts.length; ++i) {
            lastCosts[i] = -1f;
        }
    }
}

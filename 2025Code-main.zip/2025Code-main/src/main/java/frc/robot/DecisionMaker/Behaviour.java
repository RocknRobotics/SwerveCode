package frc.robot.DecisionMaker;

import frc.robot.Path.Coordinate;

public class Behaviour {
    private Coordinate targetCoordinate;
    private Coordinate drivingCoordinate;
    private Coordinate drivingCoordinate2;
    private Constants.behaviours behaviour;
    private boolean leftStation;

    public Behaviour(Coordinate targetCoordinate, Constants.behaviours behaviour, Coordinate drivingCoordinate) {
        this.targetCoordinate = targetCoordinate;
        this.behaviour = behaviour;
        this.drivingCoordinate = drivingCoordinate;
    }

    public Behaviour(Coordinate targetCoordinate, Constants.behaviours behaviour, Coordinate drivingCoordinate, Coordinate drivingCoordinate2) {
        this.targetCoordinate = targetCoordinate;
        this.behaviour = behaviour;
        this.drivingCoordinate = drivingCoordinate;
        this.drivingCoordinate2 = drivingCoordinate2;
    }

    public Behaviour(Coordinate targetCoordinate, Constants.behaviours behaviour, boolean leftStation) {
        this.targetCoordinate = targetCoordinate;
        this.behaviour = behaviour;
        this.leftStation = leftStation;
        this.drivingCoordinate = targetCoordinate;
    }

    public Coordinate getDrivingCoordinate() {
        return drivingCoordinate;
    }

    public Coordinate getDrivingCoordinate2() {
        return drivingCoordinate2;
    }

    public Coordinate getCoordinate() {
        return targetCoordinate;
    }

    public Constants.behaviours getBehaviour() {
        return behaviour;
    }

    public boolean getLeftStation() {
        return leftStation;
    }
}

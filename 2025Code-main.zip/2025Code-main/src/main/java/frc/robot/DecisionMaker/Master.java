package frc.robot.DecisionMaker;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;
import frc.robot.Path.Coordinate;

public class Master {
    private Reef reef;

    private Behaviour currentBehaviour;
    private frc.robot.Swerve.Master swerveMaster;
    private frc.robot.Elevator.Master elevatorMaster;
    private frc.robot.Arm.Master armMaster;
    private frc.robot.ObstacleParser.Master obstacleMaster;
    private frc.robot.Path.Master pathMaster;

    int score = 0;

    private String[] autoString;
    private int autoStringIndex;

    public Master(frc.robot.Swerve.Master swerveMaster, frc.robot.Elevator.Master elevatorMaster, frc.robot.Arm.Master armMaster, frc.robot.ObstacleParser.Master obstacleMaster, frc.robot.Path.Master pathMaster) {
        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            Constants.reefCentreY = frc.robot.Path.Constants.fieldY - Constants.reefCentreY;
            Constants.leftY = frc.robot.Path.Constants.fieldY - Constants.leftY;
            Constants.rightY = frc.robot.Path.Constants.fieldY - Constants.rightY;

            Constants.leftX = frc.robot.Path.Constants.fieldX - Constants.leftX;
            Constants.rightX = frc.robot.Path.Constants.fieldX - Constants.rightX;

            Constants.leftInitialAngle = frc.robot.Constants.atanLookup(Constants.reefCentreY - Constants.leftY, Constants.reefCentreX - Constants.leftX);
            Constants.rightInitialAngle = frc.robot.Constants.atanLookup(Constants.reefCentreY - Constants.rightY, Constants.reefCentreX - Constants.rightX);
        }

        this.swerveMaster = swerveMaster;
        this.elevatorMaster = elevatorMaster;
        this.armMaster = armMaster;
        this.obstacleMaster = obstacleMaster;
        this.pathMaster = pathMaster;

        reef = new Reef(pathMaster);

        currentBehaviour = new Behaviour(new Coordinate(0f, 0f), Constants.behaviours.StationPickup, true);

        autoString = new String[0];
        autoStringIndex = 0;
    }

    public void autonomousInit() {
        autoString = SmartDashboard.getString("Auto String: ", "").toLowerCase().split(",");
        SmartDashboard.putString("Auto String: ", "");

        if(autoString[0].equals("")) {
            autoString = new String[0];
        }
    }

    public void teleopInit() {
        autoString = new String[0];
    }

    public void robotPeriodic() {
        try {
            if(armMaster.scored) {
                if(!autoString[autoStringIndex].equals("auto")) {
                    ++autoStringIndex;
                    ++autoStringIndex;
                }

                reef.resetCosts();

                if(currentBehaviour.getBehaviour() == Constants.behaviours.KickAlgae0 || currentBehaviour.getBehaviour() == Constants.behaviours.KickAlgae1) {
                    reef.sides[reef.lastR].algae[reef.lastC] = false;
                    System.out.println("Kicked Algae off: " + reef.lastR + ", " + reef.lastC);
                    obstacleMaster.removeReefObstacle(reef.sides[reef.lastR].algaeCoordinate, Constants.algaeHeights[reef.lastC]);
                } else {
                    reef.sides[reef.lastR].branches[reef.lastC].hasCoral[reef.lastK] = true;
                    score += Constants.coralWorth[reef.lastK];
                    System.out.println("Score: " + score);
                    System.out.println("At: " + reef.lastR + ", " + reef.lastC + ", " + reef.lastK);
                    addCoral(reef.lastR, reef.lastC, reef.lastK);
                }
    
                armMaster.scored = false;
            } else if(armMaster.intaked) {
                if(!autoString[autoStringIndex].equals("auto")) {
                    ++autoStringIndex;
                }

                armMaster.intaked = false;
                reef.resetBranchCosts();
            }
        } catch(ArrayIndexOutOfBoundsException e) {
            //e.printStackTrace();
            armMaster.scored = false;
        }

        float t = (float) Timer.getFPGATimestamp();
        reef.updateReef(obstacleMaster.getReefObstacles());

        try {
            if(autoStringIndex >= autoString.length) {
                //currentBehaviour = reef.nextBehaviour(pathMaster, swerveMaster.getXYH(), obstacleMaster.getRuntimeObstacles(), armMaster.hasCoral());
            } else {
                if(autoString[autoStringIndex].equals("pickup") || autoString[autoStringIndex].equals("auto")) {
                    currentBehaviour = reef.nextBehaviour(pathMaster, swerveMaster.getXYH(), obstacleMaster.getRuntimeObstacles(), armMaster.hasCoral());
                } else {
                    int side = Integer.valueOf(autoString[autoStringIndex]);
                    int branch = Integer.valueOf(autoString[autoStringIndex + 1]);
                    currentBehaviour = new Behaviour(reef.sides[side].branches[branch].getCoordinate(), Constants.behaviours.ScoreCoral0, reef.sides[side].branches[branch].troughScoringCoordinate);
                }
            }
        } catch(ArrayIndexOutOfBoundsException e) { //Happens when we exhaust the reef. This prevents the robot from shutting down from the exception
            e.printStackTrace();
        }

        //System.out.println(currentBehaviour.getBehaviour().ordinal());
        //System.out.println(Timer.getFPGATimestamp() - t);
    }

    public void actOnBehaviour() {
        Coordinate driveCoordinate = currentBehaviour.getDrivingCoordinate();
        float targetHeading = frc.robot.Constants.atanLookup(currentBehaviour.getCoordinate().getY() - currentBehaviour.getDrivingCoordinate().getY(), currentBehaviour.getCoordinate().getX() - currentBehaviour.getDrivingCoordinate().getX());
        
        if(currentBehaviour.getBehaviour() == Constants.behaviours.StationPickup) {
            //Going to a station
            if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
                if(currentBehaviour.getLeftStation()) {
                    targetHeading = frc.robot.Constants.PIF * 7f / 4f;
                } else {
                    targetHeading = frc.robot.Constants.PIF * 5f / 4f;
                }
            } else {
                if(currentBehaviour.getLeftStation()) {
                    targetHeading = frc.robot.Constants.PIF / 4f;
                } else {
                    targetHeading = frc.robot.Constants.PIF * 3f / 4f;
                }
            }
        }
        
        float[] targetXYH = {driveCoordinate.getX(), driveCoordinate.getY(), targetHeading};

        //System.out.println("Drive: " + driveCoordinate.toString());
        
        float[] nextPoint = pathMaster.calculateNextPoint(swerveMaster.getXYH(), targetXYH, obstacleMaster.getRuntimeObstacles());

        swerveMaster.goTo(nextPoint[0], nextPoint[1], nextPoint[2], nextPoint[3]);

        System.out.println("Next: (" + nextPoint[0] + ", " + nextPoint[1] + ")");

        float timeToSpot = nextPoint[nextPoint.length - 1] / (frc.robot.Swerve.Constants.maxTranslationalSpeed * swerveMaster.swerveFactor);

        frc.robot.Elevator.Constants.presetIndex elevatorTarget = 
            currentBehaviour.getBehaviour() == Constants.behaviours.KickAlgae0 ? frc.robot.Elevator.Constants.presetIndex.AlgaeOffFirst :
            currentBehaviour.getBehaviour() == Constants.behaviours.KickAlgae1 ? frc.robot.Elevator.Constants.presetIndex.AlgaeOffSecond :
            currentBehaviour.getBehaviour() == Constants.behaviours.ScoreCoral0 ? frc.robot.Elevator.Constants.presetIndex.L1 :
            currentBehaviour.getBehaviour() == Constants.behaviours.ScoreCoral1 ? frc.robot.Elevator.Constants.presetIndex.L2 :
            currentBehaviour.getBehaviour() == Constants.behaviours.ScoreCoral2 ? frc.robot.Elevator.Constants.presetIndex.L3 :
            currentBehaviour.getBehaviour() == Constants.behaviours.ScoreCoral3 ? frc.robot.Elevator.Constants.presetIndex.L4 :
            frc.robot.Elevator.Constants.presetIndex.CoralIntaking;

        if(elevatorTarget == frc.robot.Elevator.Constants.presetIndex.CoralIntaking) {
            elevatorMaster.goToBottom();

            if(Robot.isReal()) {
                armMaster.intake(timeToSpot);
            }

            if(swerveMaster.atPosition(targetXYH) && elevatorMaster.atPosition(elevatorTarget)) {
                if(Robot.isSimulation()) {
                    armMaster.intake(timeToSpot);
                }

                if(armMaster.hasCoral) {
                    System.out.println("Picked up coral from station :" + reef.lastC);
                    System.out.println("Num Algae: " + reef.numAlgae());
                }
            }
        } else {
            if(currentBehaviour.getBehaviour() == Constants.behaviours.KickAlgae0 || currentBehaviour.getBehaviour() == Constants.behaviours.KickAlgae1) {
                elevatorMaster.goTo(timeToSpot, elevatorTarget, true);
                armMaster.kickAlgae(timeToSpot);
            } else {
                elevatorMaster.goTo(timeToSpot, elevatorTarget, armMaster.fullySeated);

                if(currentBehaviour.getBehaviour() == Constants.behaviours.ScoreCoral3) {
                    armMaster.slowShoot(timeToSpot, elevatorMaster.atPosition(elevatorTarget), swerveMaster.anyTilt());
                } else {
                    armMaster.shoot(timeToSpot, elevatorMaster.atPosition(elevatorTarget), swerveMaster.anyTilt());
                }
            }
        }
    }

    public void fillAlgaeSpots() {
        for(int r = 0; r < reef.sides.length; ++r) {
            reef.sides[r].algae[(r + 1) % 2] = true;
            obstacleMaster.addAlgae(reef.sides[r].algaeCoordinate, Constants.algaeHeights[(r + 1) % 2]);
        }
    }

    public void toggleStation(boolean left) {
        reef.toggleStation(left);
    }

    public void addCoral(int side, int branch, int height) {
        obstacleMaster.addReefObstacle(reef.sides[side].branches[branch].getCoordinate(), Constants.coralHeights[height]);
        System.out.println(reef.sides[side].branches[branch].getCoordinate().toString());
    }

    public float[] getBranchXYH(int side, int branch) {
        Coordinate scoreCoord = reef.sides[side].branches[branch].getScoringCoordinate();
        return new float[]{scoreCoord.getX(), scoreCoord.getY(), frc.robot.Constants.atanLookup(reef.sides[side].branches[branch].getCoordinate().getY() - reef.sides[side].branches[branch].getScoringCoordinate().getY(), reef.sides[side].branches[branch].getCoordinate().getX() - reef.sides[side].branches[branch].getScoringCoordinate().getX())};
    }

    public float[] getPathBranchGoTo(int side, int branch) {
        float[] targetXYH = getBranchXYH(side, branch);
        return pathMaster.calculateNextPoint(swerveMaster.getXYH(), targetXYH, obstacleMaster.getRuntimeObstacles());
    }
}

package frc.robot.AlgaePickup;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.controller.LinearQuadraticRegulator;
import edu.wpi.first.math.estimator.KalmanFilter;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N2;
import edu.wpi.first.math.system.LinearSystem;
import edu.wpi.first.math.system.LinearSystemLoop;
import edu.wpi.first.math.system.plant.LinearSystemId;

public class Constants {
    static final int armId = 22;
    static final int rollerId = 21;
    static final int armEncoderId = 9;

    static final float armOffset = 0f;

    static final boolean rollerInverted = false;
    static final boolean armInverted = false;
    static final boolean armEncoderInverted = false;

    static final float armConversionFactor = 1f;
    static final float armRange = 5f;

    static final LinearSystem<N2, N1, N2> rollerMotorSystem = LinearSystemId.createDCMotorSystem(
        frc.robot.Constants.neoVortexMotor, //A DCMotor object representing a neo vortex
        5.56f * Math.pow(10, -5) + 7.96 * Math.pow(10, -6), //The inertia of the motor (calculated as rotor inertia + wheel inertia)
        1f); //Gearing of the motor
    static final LinearSystemLoop<N2, N1, N2> rollerSystem = new LinearSystemLoop<N2, N1, N2>(
        rollerMotorSystem, 
        new LinearQuadraticRegulator<N2, N1, N2>(rollerMotorSystem.getA(), rollerMotorSystem.getB(), MatBuilder.fill(Nat.N2(), Nat.N2(), 0.25f, 0f, 0f, 0.25f), MatBuilder.fill(Nat.N1(), Nat.N1(), 12f), 0.02f), 
        new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), rollerMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f), 
        frc.robot.Constants.systemClampFunction, 
        0.02f);

    static final LinearSystem<N2, N1, N2> anglerMotorSystem = LinearSystemId.createDCMotorSystem(
        frc.robot.Constants.neoVortexMotor, //A DCMotor object representing a neo vortex
        5.56f * Math.pow(10, -5) + 1f, //The inertia of the motor (calculated as rotor inertia + wheel inertia)
        2f); //Gearing of the motor

    static final LinearSystemLoop<N2, N1, N2> anglerSystem = new LinearSystemLoop<N2, N1, N2>(
        rollerMotorSystem, 
        new LinearQuadraticRegulator<N2, N1, N2>(anglerMotorSystem.getA(), anglerMotorSystem.getB(), MatBuilder.fill(Nat.N2(), Nat.N2(), 10f, 0f, 0f, 0.1f), MatBuilder.fill(Nat.N1(), Nat.N1(), 12f), 0.02f), 
        new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), anglerMotorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3f, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f), 
        frc.robot.Constants.systemClampFunction, 
        0.02f);

    static final float intakePreset = 100f;//235.617172f;
    static final float holdPreset = 235.617172f - 70.761017f;
}

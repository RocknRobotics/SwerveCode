package frc.robot.AlgaePickup;

import frc.robot.MotorController.FlexVortexController;
import frc.robot.MotorController.MAXVortexController;

public class Master {
    FlexVortexController rollerController;
    MAXVortexController anglerController;

    public boolean hasAlgae;

    private boolean shotLastLoop;
    private boolean shotThisLoop;

    private float initialWheelPos;
    
    public Master(frc.robot.MotorController.ControllerGroup fatControllerGroup) {
        rollerController = new FlexVortexController(Constants.rollerId, Constants.rollerInverted, Constants.rollerSystem, Constants.rollerMotorSystem);
        anglerController = new MAXVortexController(Constants.armId, Constants.armInverted, Constants.armEncoderInverted, Constants.armOffset, Constants.armConversionFactor, Constants.armRange, Constants.anglerSystem, Constants.anglerMotorSystem, false, Constants.armEncoderId);

        hasAlgae = false;

        fatControllerGroup.add(rollerController);
        fatControllerGroup.add(anglerController);

        shotLastLoop = false;
        shotThisLoop = false;
        initialWheelPos = 0f;
    }

    public void robotPeriodic() {
        rollerController.robotPeriodic("Algae Roller");
        anglerController.robotPeriodic("Algae Angler");
    }

    public void teleopPeriodic(int angle, int roller) {
        if(roller == 0) {
            rollerController.set(0.3f);
        } else if(roller == 1) {
            rollerController.set(-0.3f);
        } else {
            rollerController.set(0f);
        }

        if(angle == 0) {
            anglerController.set(0.4f);
        } else if(angle == 1) {
            anglerController.set(-0.4f);
        } else {
            anglerController.desiredVoltageFromPositionChange(0f);
        }
    }

    public void intake() {
        anglerController.desiredVoltageFromPosition(Constants.intakePreset);
        rollerController.set(1f);
    }

    public void hold() {
        anglerController.desiredVoltageFromPosition(Constants.holdPreset);

        if(Math.abs(anglerController.getDesiredVoltage()) > 0.5f) {
            rollerController.set(1f);
        } else {
            rollerController.set(0f);
        }
    }

    public void shoot() {
        if(Math.abs(anglerController.getPositionUnwrapped() - Constants.holdPreset) < 0.1f) {
            rollerController.set(-1f);
        } else {
            anglerController.desiredVoltageFromPosition(Constants.holdPreset);
        }
    }

    public void intake(float timeToSpot) {

    }

    public void shoot(float timeToSpot) {

    }
}

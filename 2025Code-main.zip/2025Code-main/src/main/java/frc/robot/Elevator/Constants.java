package frc.robot.Elevator;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.controller.LinearQuadraticRegulator;
import edu.wpi.first.math.estimator.KalmanFilter;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N2;
import edu.wpi.first.math.system.LinearSystem;
import edu.wpi.first.math.system.LinearSystemLoop;
import edu.wpi.first.math.system.plant.DCMotor;
import edu.wpi.first.math.system.plant.LinearSystemId;
import edu.wpi.first.math.util.Units;

public final class Constants {
    //The id of the motor for the elevator
    static final int leftMotorId = 31;
    static final int rightMotorId = 32;

    //TODO
    //Whether or not the elevator motor is inverted
    static final boolean leftMotorInverted = false;
    static final boolean rightMotorInverted = false;

    //TODO
    //The minimum height of the elevator, in metres
    static final float minHeight = 0f;
    //The maximum height of the elevator, in metres
    static final float maxHeight = 0.615f;

    public static final DCMotor neoMotor = DCMotor.getNEO(2);

    //The plant for the LSL
    //States are <position, velocity>
    //Input is <voltage>
    //Output is <position, velocity>
    static final LinearSystem<N2, N1, N2> elevatorElevatorSystem = LinearSystemId.createElevatorSystem(
        neoMotor, 
        12f, 
        Units.inchesToMeters(0.75d), 
        10.71f);

    static LinearSystemLoop<N2, N1, N2> elevatorSystem = new LinearSystemLoop<N2, N1, N2>(
        elevatorElevatorSystem,
        new LinearQuadraticRegulator<N2, N1, N2>(elevatorElevatorSystem.getA(), elevatorElevatorSystem.getB(), MatBuilder.fill(Nat.N2(), Nat.N2(), 1f, 0f, 0f, 0.1f), MatBuilder.fill(Nat.N1(), Nat.N1(), 12f), 0.02f),
        new KalmanFilter<N2, N1, N2>(Nat.N2(), Nat.N2(), elevatorElevatorSystem, MatBuilder.fill(Nat.N2(), Nat.N1(), 3d, 0f), MatBuilder.fill(Nat.N2(), Nat.N1(), 0.01f, 0.01f), 0.02f),
        frc.robot.Constants.systemClampFunction,
        0.02f);

    //Lookup index for array below
    public static enum presetIndex {
        L1,
        L2,
        L3,
        L4,
        AlgaeOffFirst,
        AlgaeOffSecond,
        CoralIntaking
    }

    //Presets for the height, in metres, of the elevator in different scenarios
    static final float[] presets = {
        0.075f - 0.045f + 0.05f, //L1
        0.155f, //L2
        0.35f - 0.045f, //L3
        maxHeight, //L4
        0.144f - 0.045f, //AlgaeOffFirst
        0.38f - (0.2f - 0.144f) - 0.045f, //AlgaeOffSecond
        0f //CoralIntaking
    };

    public static final float magicJohnson = 0.222f;

    static final float maxSpeed = maxHeight / 0.4f;

    static final float ratioMin = 0.15f;
    static final float ratioHeightCutoff = 0.5f;
}

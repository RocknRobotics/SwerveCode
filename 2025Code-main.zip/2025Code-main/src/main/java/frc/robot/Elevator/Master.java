package frc.robot.Elevator;

import edu.wpi.first.math.MatBuilder;
import edu.wpi.first.math.Nat;
import edu.wpi.first.math.system.plant.DCMotor;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.simulation.ElevatorSim;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;
import frc.robot.MotorController.ControllerGroup;
import frc.robot.MotorController.ElevatorController;

public class Master {
    //The motor controller for the elevator
    ElevatorController leftController;
    ElevatorController rightController;

    //The elevator controller group
    ControllerGroup elevatorGroup;

    public static ElevatorSim elevatorSim;

    public Master(ControllerGroup fatControllerGroup) {
        leftController = new ElevatorController(Constants.leftMotorId, Constants.leftMotorInverted);
        rightController = new ElevatorController(Constants.rightMotorId, Constants.rightMotorInverted);
        leftController.setPosition(0f);
        rightController.setPosition(0f);

        elevatorGroup = new ControllerGroup(new ElevatorController[]{leftController, rightController});

        fatControllerGroup.add(new ElevatorController[]{leftController, rightController});

        if(Robot.isSimulation()) {
            elevatorSim = new ElevatorSim(Constants.elevatorElevatorSystem, DCMotor.getNEO(2), Constants.minHeight, Constants.maxHeight, true, 0f);
        }
    }

    public void robotPeriodic() {
        if(Robot.isSimulation()) {
            SmartDashboard.putNumber("Elevator Height: ", elevatorSim.getPositionMeters());
            elevatorSim.setInput(leftController.getDesiredVoltage());
            elevatorSim.update(0.02f);

            leftController.sim.setVelocity(elevatorSim.getVelocityMetersPerSecond() / ((2f * frc.robot.Constants.PIF) * Units.inchesToMeters(0.75d) / 10.71f) * 60f);
            rightController.sim.setVelocity(elevatorSim.getVelocityMetersPerSecond() / ((2f * frc.robot.Constants.PIF) * Units.inchesToMeters(0.75d) / 10.71f) * 60f);
            leftController.sim.setPosition(elevatorSim.getPositionMeters() / ((2f * frc.robot.Constants.PIF) * Units.inchesToMeters(0.75d) / 10.71f));
            rightController.sim.setPosition(elevatorSim.getPositionMeters() / ((2f * frc.robot.Constants.PIF) * Units.inchesToMeters(0.75d) / 10.71f));
        } else {
            SmartDashboard.putNumber("Elevator Height: ", (leftController.getPositionUnwrapped() + rightController.getPositionUnwrapped()) / 2f);
        }
        
        Constants.elevatorSystem.correct(MatBuilder.fill(Nat.N2(), Nat.N1(), (leftController.getPositionUnwrapped() + rightController.getPositionUnwrapped()) / 2f, (leftController.getVelocity() + rightController.getVelocity()) / 2f));
        elevatorGroup.robotPeriodic(new String[]{"Left Elevator", "Right Elevator"});
    }

    //TODO
    public void teleopPeriodic(int elevatorPacket) {
        if(elevatorPacket == -1) {
            if(Math.abs((leftController.getPositionUnwrapped() + rightController.getPositionUnwrapped()) / 2f) < 0.07d) {
                goToBottom();
            } else {
                leftController.desiredVoltageFromPositionChange(0f, rightController, Constants.elevatorSystem);
            }
        } else {
            if(elevatorPacket == Constants.presetIndex.CoralIntaking.ordinal()) {
                goToBottom();
            } else if(elevatorPacket < Constants.presetIndex.CoralIntaking.ordinal()) {
                leftController.desiredVoltageFromPosition(Constants.presets[elevatorPacket], rightController, Constants.elevatorSystem);
            } else if(elevatorPacket == 7) {
                leftController.set(0.2f);
                rightController.set(0.2f);
            } else {
                leftController.set(-0.2f);
                rightController.set(-0.2f);
            }
        }
    }

    public void goToBottom() {
        /*if(Math.abs((leftController.getPositionUnwrapped() + rightController.getPositionUnwrapped()) / 2f) < 0.07f) {
            leftController.desiredVoltageFromBottom(rightController, Constants.elevatorSystem);
        } else {
            leftController.desiredVoltageFromPosition(Constants.presets[Constants.presetIndex.CoralIntaking.ordinal()], rightController, Constants.elevatorSystem);
        }*/
        leftController.desiredVoltageFromBottom(rightController, Constants.elevatorSystem);
    }

    public void goTo(Constants.presetIndex presetIndex, boolean fullySeated) {
        if(fullySeated) {
            leftController.desiredVoltageFromPosition(Constants.presets[presetIndex.ordinal()], rightController, Constants.elevatorSystem);
        }
    }
    
    public void goTo(float timeToSpot, Constants.presetIndex presetIndex, boolean fullySeated) {
        float desiredPosition = Constants.presets[presetIndex.ordinal()];
        float timeToPosition = Math.abs(desiredPosition - (leftController.getPositionUnwrapped() + rightController.getPositionUnwrapped()) / 2f) / Constants.maxSpeed;

        if(timeToSpot <= timeToPosition || desiredPosition < (leftController.getPositionUnwrapped() + rightController.getPositionUnwrapped()) / 2f) {
            goTo(presetIndex, fullySeated);
        } else {
            teleopPeriodic(-1);
        }
    }

    //TODO
    public boolean atPosition(Constants.presetIndex presetIndex) {
        return Math.abs((leftController.getPositionUnwrapped() + rightController.getPositionUnwrapped()) / 2f - Constants.presets[presetIndex.ordinal()]) < 0.025d;
    }

    public void disabledPeriodic() {
        elevatorGroup.stopMotor();
    }

    public float getHeightRatio() {
        float pos = (leftController.getPositionUnwrapped() + rightController.getPositionUnwrapped()) / 2f;
        float temp = (pos + (1f - Constants.ratioHeightCutoff));
        temp = temp * temp * temp;
        float desmos = Math.max(Constants.ratioMin, Math.min(1f, (1f + Constants.ratioMin) - temp));

        if(DriverStation.isAutonomous()) {
            desmos *= 0.4;
        } else {
            desmos *= 1f;
        }

        return desmos;
    }
}

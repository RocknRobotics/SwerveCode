package frc.robot.Path;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.PriorityQueue;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.ObstacleParser.ExtendedObstacle;

public class Master {
    public static int printFrequency = 5;
    public static int print = printFrequency - 1;

    public Master() {
        SmartDashboard.putNumber("Target X: ", 5.5d);
        SmartDashboard.putNumber("Target Y: ", 5.5d);
        SmartDashboard.putNumber("Target H: ", 0f);
    }

    public float[] calculateNextPoint(float[] currentXYH, float[] targetXYH, ArrayList<ExtendedObstacle> runtimeObstacles) {
        //float t = Timer.getFPGATimestamp();

        //Obstacles sorted based on the minimum distance from the current point to them
        Obstacle[] sortedObstacles = new Obstacle[Constants.constantObstacles.length + runtimeObstacles.size()];
        //Used to keep track of the obstacle with the minimum distance greater than the distance to the end
        //Since it's minDist > endDist, then the obstacle cannot be hit, hence we can skip all computations involved with it
        //Technically introduces incorrect behaviour if some obstacle that is crosses causes the robot to move all the way around the end point, but no obstacle is like that this year
        int maxObstacleIndex = sortedObstacles.length;

        //Fills it with the constant obstacles
        for(int i = 0; i < Constants.constantObstacles.length; ++i) {
            sortedObstacles[i] = Constants.constantObstacles[i];
        }

        //Fills it with any runtime obstacles as well
        //Important: These runtime obstacles MUST BE STATIC. They should have zero speed. Any dynamic (moving) obstacles will be handled by the PCLRHC
        //These could be coral/algae at rest on the ground, or cages that aren't moving, or other robots if their behaviour is deduced as not moving
        for(int i = Constants.constantObstacles.length; i < sortedObstacles.length; ++i) {
            sortedObstacles[i] = runtimeObstacles.get(i - Constants.constantObstacles.length);
        }

        //Clears the queue and checked and passedObstacles
        PriorityQueue<PathPoint> queue = new PriorityQueue<PathPoint>();
        HashSet<PathPoint> checked = new HashSet<PathPoint>();
        HashSet<Obstacle> passedObstacles = new HashSet<Obstacle>();

        Coordinate startCoordinate = new Coordinate(currentXYH[0], currentXYH[1]);
        Coordinate endCoordinate = new Coordinate(targetXYH[0], targetXYH[1]);

        for(Obstacle obstacle: sortedObstacles) {
            obstacle.updateMinDistance(startCoordinate);

            if(obstacle.isInside(startCoordinate)) {
                //Check to see if noise in odometry measurement caused the robot to think it's "inside" the clearance adjusted obstacle
                obstacle.closestPoint.updateAngle(startCoordinate);
                startCoordinate = new Coordinate(obstacle.closestPoint.getX() + 0.25f * frc.robot.Constants.cosLookup(obstacle.closestPoint.getAngle()), obstacle.closestPoint.getY() + 0.25f * frc.robot.Constants.sinLookup(obstacle.closestPoint.getAngle()));
            }
        }

        if(isOB(startCoordinate) || isOB(endCoordinate)) {
            return new float[]{currentXYH[0], currentXYH[1], currentXYH[2], 0f, new Distance(Byte.MAX_VALUE).getFloatValue()};
        }
        
        //Starts off the queue with the pathPoint going from start to end
        queue.add(new PathPoint(startCoordinate, endCoordinate));

        //Look up Djisktra's algorithm for an explanation of why this is a queue
        //This is technically an A* variant, as it uses the heuristic = pathLength + airDistance, but this heuristic is admissible (guarantees the shortest path is returned)
        while(!(queue.peek().getCoordinate().equals(endCoordinate))) {
            PathPoint currentPathPoint = queue.remove();

            //If we already had this path point before, then we know that the earlier path to this point was shorter, and since we did calculations on this path point, there's no need to repeat
            if(checked.contains(currentPathPoint)) {
                continue;
            }

            if(maxObstacleIndex == 0) {
                queue.add(new PathPoint(currentPathPoint, endCoordinate, endCoordinate));
                break;
            }

            //print("Current: " + currentPathPoint.getCoordinate().getX() + ", " + currentPathPoint.getCoordinate().getY());

            checked.add(currentPathPoint);

            //Later on, if we didn't hit any obstacle, then we'll add the end point to the queue
            boolean hitObstacle = false;

            //Updates the minimum distance to each obstacle using the current path point. Everything past maxObstacleIndex is known to not be needed ever in the future
            for(int i = 0; i < maxObstacleIndex; ++i) {
                sortedObstacles[i].updateMinDistance(currentPathPoint.getCoordinate());
            }
            
            Arrays.sort(sortedObstacles, 0, maxObstacleIndex - 1);

            float distanceToEnd = frc.robot.Constants.sqrtLookup((currentPathPoint.getCoordinate().getX() - endCoordinate.getX()) * (currentPathPoint.getCoordinate().getX() - endCoordinate.getX()) + (currentPathPoint.getCoordinate().getY() - endCoordinate.getY()) * (currentPathPoint.getCoordinate().getY() - endCoordinate.getY()));

            for(int i = 0; !hitObstacle && i < maxObstacleIndex; ++i) {
                //The minimum distance to this obstacle is greater than the distance to the end, so this obstacle can't possibly be hit. Since the array is sorted, no obstacle past it needs to be checked
                if(sortedObstacles[i].getMinDistance() > distanceToEnd) {
                    maxObstacleIndex = i;
                    break;
                }

                //If we hit this obstacle before, then we can safely assume that the concave hull we constructed around it guarantees we won't hit that obstacle again (technically we could in a different instance, see Obstacle.computeConvexHull())
                else if(passedObstacles.contains(sortedObstacles[i])) {
                    continue;
                }

                else if(sortedObstacles[i].crosses(currentPathPoint.getCoordinate(), endCoordinate)) {
                    //Adds this obstacle to the passed obstacles set
                    passedObstacles.add(sortedObstacles[i]);

                    //We hit an obstacle :(
                    hitObstacle = true;

                    //Computes two possible paths around the obstacle (arbitrarily dubbed "top" and "bottom")
                    PathPoint[] pathPoints = sortedObstacles[i].computeConvexHull(currentPathPoint, endCoordinate, sortedObstacles, maxObstacleIndex);

                    //print("Convex Hull Points");
                    //print(pathPoints[0].getCoordinate().toString());
                    //print(pathPoints[1].getCoordinate().toString());

                    //Adds both paths to the queue, since technically speaking the right combination of obstacles could make the longer of these two paths eventually have a shorter path to the end
                    queue.add(pathPoints[0]);
                    queue.add(pathPoints[1]);
                }
            }

            //Since we hit no obstacles, we'll add end coordinate to the queue so the queue exits
            if(!hitObstacle) {
                queue.add(new PathPoint(currentPathPoint, endCoordinate, endCoordinate));
            }
        }

        //print("Exited");

        //Gets the path that got us to end
        PathPoint lastPathPoint = queue.remove();
        float pathDistance = lastPathPoint.getPathLength();

        //Gets the path point that is one "after" the current (start) point
        while(lastPathPoint.getPrevPoint() != null && lastPathPoint.getPrevPoint().getPrevPoint() != null) {
            lastPathPoint = lastPathPoint.getPrevPoint();
        }

        //if(++print == printFrequency) {
            //System.out.println(Timer.getFPGATimestamp() - t);
            //System.out.println(startCoordinate);
            //System.out.println("Last coordinate: " + lastPathPoint.getCoordinate().toString());
            //System.out.println();
            //print = 0;
        //}

        return new float[]{
            lastPathPoint.getCoordinate().getX(),
            lastPathPoint.getCoordinate().getY(),
            targetXYH[2],
            lastPathPoint.getCoordinate().equals(endCoordinate) ? 0f : 1f,
            pathDistance
        };
    }

    //Print utility that only prints every so many loops, to avoid clutter
    public static void print(String printStatement) {
        if(print == printFrequency) {
            System.out.println(printStatement);
        }
    }

    public static void printObstacles() {
        for(Obstacle obstacle: Constants.constantObstacles) {
            System.out.println("Obstacle");
            for(Coordinate vertex: obstacle.vertices) {
                System.out.println(vertex);
            }
        }
    }

    public void initConstantObstacles() {
        Thread one = new Thread(() -> {
            Constants.constantObstacles[0].initLookup();
            Constants.constantObstacles[2].initLookup();
            Constants.constantObstacles[7].initLookup();
        });
        one.start();
        
        Constants.constantObstacles[1].initLookup();
        Constants.constantObstacles[6].initLookup();
        Constants.constantObstacles[8].initLookup();
        Constants.constantObstacles[9].initLookup();

        try {
            one.join();
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public boolean isOB(Coordinate point) {
        return point.getX() < 0 || point.getY() < 0 || point.getX() > Constants.fieldX || point.getY() > Constants.fieldY;
    }

    public boolean pastHalf(Coordinate point) {
        point.updateAngle(Constants.fieldCentre);
        
        if(DriverStation.getAlliance().get().equals(Alliance.Red)) {
            return point.getAngle() >= frc.robot.Constants.PIF * -5f / 6f && point.getAngle() <= -frc.robot.Constants.PIF / 6f;
        } else {
            return point.getAngle() <= frc.robot.Constants.PIF * 5f / 6f && point.getAngle() >= frc.robot.Constants.PIF / 6f;
        }
    }
}

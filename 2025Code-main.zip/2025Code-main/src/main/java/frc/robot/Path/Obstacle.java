package frc.robot.Path;

import java.util.ArrayList;
import java.util.Arrays;

import edu.wpi.first.math.MathUtil;
import frc.robot.Robot;

public class Obstacle implements Comparable<Obstacle> {
    //The coordinates of the vertices for this obstacle
    //Need to be ordered such that a valid line segment exists between adjacent vertices
    public Coordinate[] vertices;
    //The min distance from some start point. Updated by updateMinDistance() method
    private float minDistance;
    //The closest point to the start point
    public Coordinate closestPoint;

    public Coordinate obstacleCenter;

    private boolean[][] insideObstacleLookup;
    private float minYLookup;
    private float maxYLookup;
    private float minXLookup;
    private float maxXLookup;

    private Distance[][] closestPointLookup;

    private static float[] OBMinDistanceLookup;

    //Takes in an array of vertices, and stores the offsets of those vertices so that the resulting polygon implicitly has clearance for the robot
    public Obstacle(Coordinate[] vertices) {
        this.vertices = new Coordinate[vertices.length];
        float x = 0;
        float y = 0;
        
        for(int i = 0; i < vertices.length; ++i) {
            Coordinate start, vertex, end;
            x += vertices[i].getX();
            y += vertices[i].getY();

            //Set start vertex
            if(i == 0) {
                start = vertices[vertices.length - 1];
            } else {
                start = vertices[i - 1];
            }

            //The vertex to offset
            vertex = vertices[i];

            //Set end vertex
            if(i == vertices.length - 1) {
                end = vertices[0];
            } else {
                end = vertices[i + 1];
            }

            //Finds the bisection angle
            float startAngle = frc.robot.Constants.atanLookup(start.getY() - vertex.getY(), start.getX() - vertex.getX());
            float endAngle = frc.robot.Constants.atanLookup(end.getY() - vertex.getY(), end.getX() - vertex.getX());
            float angleDiff = (float) MathUtil.angleModulus(endAngle - startAngle);
            
            float angleCalc = (startAngle + angleDiff / 2f);

            //Offsets the vertex by robotDiagonalHalf so that there is clearance going around the obstacle
            this.vertices[i] = new Coordinate(vertex.getX() - frc.robot.Constants.cosLookup(angleCalc) * Constants.robotDiagonalHalf, vertex.getY() - frc.robot.Constants.sinLookup(angleCalc) * Constants.robotDiagonalHalf);
        }

        obstacleCenter = new Coordinate(x / vertices.length, y / vertices.length);

        if(OBMinDistanceLookup == null) {
            OBMinDistanceLookup = new float[(int) Math.ceil(frc.robot.Constants.PIF / 2f * frc.robot.Constants.anglePrecision) + 1];
            Thread one = new Thread(() -> {
                for(int i = 0; i < OBMinDistanceLookup.length; i += 2) {
                    OBMinDistanceLookup[i] = OBMinDistanceNoLookup(((float) i) / frc.robot.Constants.anglePrecision);
                }
            });
            one.start();

            for(int i = 1; i < OBMinDistanceLookup.length; i += 2) {
                OBMinDistanceLookup[i] = OBMinDistanceNoLookup(((float) i) / frc.robot.Constants.anglePrecision);
            }

            try {
                one.join();
            } catch(InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void initLookup() {
        minYLookup = Float.MAX_VALUE;
        maxYLookup = Float.MIN_VALUE;
        minXLookup = Float.MAX_VALUE;
        maxXLookup = Float.MIN_VALUE;

        for(Coordinate vertex: vertices) {
            minYLookup = Math.min(vertex.getY(), minYLookup);
            maxYLookup = Math.max(vertex.getY(), maxYLookup);
            minXLookup = Math.min(vertex.getX(), minXLookup);
            maxXLookup = Math.max(vertex.getX(), maxXLookup);
        }

        Coordinate maxCoord = new Coordinate(maxXLookup, maxYLookup);
        Coordinate minCoord = new Coordinate(minXLookup, minYLookup);
        maxCoord.updateDistance(obstacleCenter);
        minCoord.updateDistance(obstacleCenter);

        insideObstacleLookup = new boolean[(int) Math.ceil(2f * frc.robot.Constants.PIF * frc.robot.Constants.anglePrecision) + 1][(int) Math.ceil(frc.robot.Constants.distancePrecision * Math.max(maxCoord.getDistance(), minCoord.getDistance())) + 1];
        Robot.totalBytes += insideObstacleLookup.length * insideObstacleLookup[0].length;

        for(int r = 0; r < insideObstacleLookup.length; ++r) {
            for(int c = 0; c < insideObstacleLookup[r].length; ++c) {
                Coordinate current = new Coordinate(obstacleCenter.getX() + ((float) c) / frc.robot.Constants.distancePrecision * frc.robot.Constants.cosLookup(((float) r) / frc.robot.Constants.anglePrecision), obstacleCenter.getY() + ((float) c) / frc.robot.Constants.distancePrecision * frc.robot.Constants.sinLookup(((float) r) / frc.robot.Constants.anglePrecision));
                insideObstacleLookup[r][c] = isInsideNoLookup(current);
            }
        }

        updateMinDistance(obstacleCenter);
        float distance = minDistance;

        closestPointLookup = new Distance[(int) Math.ceil(frc.robot.Constants.PIF / 2f * frc.robot.Constants.anglePrecision) + 1][];

        for(int r = 0; r < closestPointLookup.length; ++r) {
            float closestDistance = Obstacle.OBMinDistance(r);
            closestPointLookup[r] = new Distance[(int) Math.ceil(frc.robot.Constants.distancePrecision * closestDistance) + 1];
            Robot.totalBytes += closestPointLookup[r].length;
            float xDelta = 1f / frc.robot.Constants.distancePrecision * frc.robot.Constants.cosLookup(((float) r) / frc.robot.Constants.anglePrecision);
            float yDelta = 1f / frc.robot.Constants.distancePrecision * frc.robot.Constants.sinLookup(((float) r) / frc.robot.Constants.anglePrecision);
            Coordinate current = new Coordinate(-xDelta, -yDelta);

            for(int c = 0; c < closestPointLookup[r].length; ++c) {
                current.add(xDelta, yDelta);
                current.updateAngle(obstacleCenter);
                Coordinate temp = new Coordinate(obstacleCenter.getX() + distance * frc.robot.Constants.cosLookup(current.getAngle()), obstacleCenter.getY() + distance * frc.robot.Constants.sinLookup(current.getAngle()));
                float tempXDelta = frc.robot.Constants.cosLookup(current.getAngle());
                float tempYDelta = frc.robot.Constants.sinLookup(current.getAngle());

                while(isInside(temp)) {
                    temp.add(tempXDelta, tempYDelta);
                }

                tempXDelta /= -10f;
                tempYDelta /= -10f;

                while(!isInside(temp)) {
                    temp.add(tempXDelta, tempYDelta);
                }

                tempXDelta /= -10f;
                tempYDelta /= -10f;

                while(isInside(temp)) {
                    temp.add(tempXDelta, tempYDelta);
                }

                closestPointLookup[r][c] = new Distance(frc.robot.Constants.sqrtLookup((obstacleCenter.getX() - temp.getX()) * (obstacleCenter.getX() - temp.getX()) + (obstacleCenter.getY() - temp.getY()) * (obstacleCenter.getY() - temp.getY())));
            }
        }
    }

    //Returns two possible paths around this obstacle, going from parent to end
    public PathPoint[] computeConvexHull(PathPoint parent, Coordinate end, Obstacle[] sortedObstacles, int maxObstacleIndex) {
        PathPoint topPath = parent;
        PathPoint bottomPath = parent;

        //Store all points in a single array for convex hull computations
        Coordinate[] points = new Coordinate[vertices.length + 1];
        //Adds end to the points array. The goal is that both the top and bottom path will terminate once they reach the end point
        points[points.length - 1] = end;
        end.updateAngle(parent.getCoordinate());

        //All vertices (and end) have their angle calculated with respect to the start point (parent). Then, everything has it's angle difference from end's angle recorded. This effectively separates into a left and right path, split by end.
        for(int i = 0; i < vertices.length; ++i) {
            points[i] = vertices[i];
            points[i].updateAngle(parent.getCoordinate());
            points[i].setAngle((float) MathUtil.angleModulus(points[i].getAngle() - end.getAngle()));
        }

        //Need to manually set end's difference from itself as 0
        points[points.length - 1].setAngle(0f);

        //Sorts the coordinates. Technically, "left" and "right" are flipped (since negative angle differences end up at [0], [1]...), but this doesn't affect calculations)
        Arrays.sort(points, (Coordinate a, Coordinate b) -> {
            return Float.compare(a.getAngle(), b.getAngle());
        });

        int endIndex = 0;

        //Need to find the end index so we know when to stop calculating the top/bottom path
        for(int i = 0; i < points.length; ++i) {
            if(points[i] == end) {
                endIndex = i;
                break;
            }
        }

        int left = 0;
        int right = points.length - 1;
        int q = 0;
        ArrayList<Coordinate> path = new ArrayList<Coordinate>();

        //Compute the top path
        while(left != endIndex) {
            //Adds the current point
            path.add(points[left]);

            q = left + 1;

            //Finds the next point that contains all other points up to it
            for(int i = q + 1; i <= endIndex; ++i) {
                if(orientation(points[left], points[i], points[q]) == 2) {
                    q = i;
                }
            }

            left = q;
        }

        for(int i = 0; i < path.size(); ++i) {
            topPath = new PathPoint(topPath, path.get(i), end);

            //When going from parent to the first point in the hull, it's technically possible to run into some other obstacle, including previously avoided obstacles.
            //Hence, we need to see if we hit any obstacles
            if(i == 0) {
                for(int j = 0; j < maxObstacleIndex; ++j) {
                    //Can't run into yourself
                    if(sortedObstacles[j] != this && sortedObstacles[j].crosses(parent.getCoordinate(), topPath.getCoordinate())) {
                        PathPoint possiblePaths[] = sortedObstacles[j].computeConvexHull(parent, topPath.getCoordinate(), sortedObstacles, maxObstacleIndex);

                        //Technically, very technically speaking each of these path points should be stored, but for all intents and purposes that would required this recursion triggering at least twice, and that's incredibly unlikely
                        //Even then, this would probably still return the more optimal of the four possible paths
                        if(possiblePaths[0].compareTo(possiblePaths[1]) < 0) {
                            topPath = possiblePaths[0];
                        } else {
                            topPath = possiblePaths[1];
                        }
                        
                        break;
                    }
                }
            }
        }

        //Clear the path list so we can reuse it for the bottom path calculations
        path.clear();

        //Everything below is a repeat of the top, but for the bottom

        //Compute the bottom path
        while(right != endIndex) {
            path.add(points[right]);

            q = right - 1;

            for(int i = q - 1; i >= endIndex; --i) {
                if(orientation(points[right], points[i], points[q]) == 1) {
                    q = i;
                }
            }

            right = q;
        }

        for(int i = 0; i < path.size(); ++i) {
            bottomPath = new PathPoint(bottomPath, path.get(i), end);

            if(i == 0) {
                for(int j = 0; j < maxObstacleIndex; ++j) {
                    if(sortedObstacles[j] != this && sortedObstacles[j].crosses(parent.getCoordinate(), bottomPath.getCoordinate())) {
                        PathPoint possiblePaths[] = sortedObstacles[j].computeConvexHull(parent, bottomPath.getCoordinate(), sortedObstacles, maxObstacleIndex);

                        if(possiblePaths[0].compareTo(possiblePaths[1]) < 0) {
                            bottomPath = possiblePaths[0];
                        } else {
                            bottomPath = possiblePaths[1];
                        }
                        
                        break;
                    }
                }
            }
        }

        return new PathPoint[]{topPath, bottomPath};
    }

    //Checks if start crosses this osbtacle going to end
    public boolean crosses(Coordinate start, Coordinate end) {
        for(int i = 0; i < vertices.length; i++) {
            if(segmentsIntersect(start, end, vertices[i], vertices[(i + 1) % vertices.length])) {
                return true;
            }
        }

        return false;
    }

    public int numSegmentsCrossed(Coordinate start, Coordinate end) {
        int segmentsCrossed = 0;

        for(int i = 0; i < vertices.length; ++i) {
            if(segmentsIntersect(start, end, vertices[i], vertices[(i + 1) % vertices.length])) {
                ++segmentsCrossed;
            }
        }

        return segmentsCrossed;
    }

    public boolean isInside(Coordinate start) {
        Obstacle complementObstacle = this;
        
        if(this == Constants.constantObstacles[4]) {
            complementObstacle = Constants.constantObstacles[0];
        } else if(this == Constants.constantObstacles[3]) {
            complementObstacle = Constants.constantObstacles[1];
        } else if(this == Constants.constantObstacles[5]) {
            complementObstacle = Constants.constantObstacles[2];
        } else if(this == Constants.constantObstacles[10]) {
            complementObstacle = Constants.constantObstacles[7];
        } else if(this == Constants.constantObstacles[11]) {
            complementObstacle = Constants.constantObstacles[8];
        } else if(this == Constants.constantObstacles[12]) {
            complementObstacle = Constants.constantObstacles[9];
        }

        if(complementObstacle != this) {
            start.getComplement();
        }

        if(complementObstacle.insideObstacleLookup != null) {
            if(start.getX() < minXLookup || start.getX() > maxXLookup || start.getY() < minYLookup || start.getY() > maxYLookup) {
                return false;
            }

            start.updateDistance(complementObstacle.obstacleCenter);
            start.updateAngle(complementObstacle.obstacleCenter);
            int r = Math.min((int) ((start.getAngle() < 0 ? start.getAngle() + 2f * frc.robot.Constants.PIF : start.getAngle()) * frc.robot.Constants.anglePrecision), complementObstacle.insideObstacleLookup.length - 1);
            int c = Math.min((int) (start.getDistance() * frc.robot.Constants.distancePrecision), complementObstacle.insideObstacleLookup[r].length - 1);

            return complementObstacle.insideObstacleLookup[r][c];
        } else {
            return isInsideNoLookup(start);
        }
    }

    public boolean isInsideNoLookup(Coordinate start) {
        int windingNumber = 0;
        
        for(int i = 0; i < vertices.length; ++i) {
            Coordinate current = vertices[i];
            Coordinate next = vertices[(i + 1) % vertices.length];
            
            // Check if the edge crosses the horizontal line from the point.
            if(current.getY() <= start.getY()) {
                if(next.getY() > start.getY() && isLeft(current, next, start) > 0) {
                    // An upward crossing and point is left of edge
                    ++windingNumber;
                }
            } else {
                if(next.getY() <= start.getY() && isLeft(current, next, start) < 0) {
                    // A downward crossing and point is right of edge
                    --windingNumber;
                }
            }
        }

        return windingNumber != 0;
    }

    private float isLeft(Coordinate a, Coordinate b, Coordinate c) {
        return (b.getX() - a.getX()) * (c.getY() - a.getY()) -
               (c.getX() - a.getX()) * (b.getY() - a.getY());
    }

    //Courtesy of DeepSeek
    private boolean segmentsIntersect(Coordinate p1, Coordinate p2, Coordinate q1, Coordinate q2) {
        int o1 = orientation(p1, p2, q1);
        int o2 = orientation(p1, p2, q2);
        int o3 = orientation(q1, q2, p1);
        int o4 = orientation(q1, q2, p2);

        if(o1 != o2 && o3 != o4) return true;

        if(o1 == 0 && onSegment(p1, q1, p2)) return true;
        if(o2 == 0 && onSegment(p1, q2, p2)) return true;
        if(o3 == 0 && onSegment(q1, p1, q2)) return true;
        if(o4 == 0 && onSegment(q1, p2, q2)) return true;

        return false;
    }

    //Courtesy of DeepSeek
    public static int orientation(Coordinate p, Coordinate q, Coordinate r) {
        float val = (q.getY() - p.getY()) * (r.getX() - q.getX()) - (q.getX() - p.getX()) * (r.getY() - q.getY());

        if(Math.abs(val) < 1e-10) return 0; // Collinear
        
        return(val > 0) ? 1 : 2; // CW or CCW
    }

    //Courtesy of DeepSeek
    private boolean onSegment(Coordinate a, Coordinate b, Coordinate c) {
        return b.getX() <= Math.max(a.getX(), c.getX()) && b.getX() >= Math.min(a.getX(), c.getX()) &&
               b.getY() <= Math.max(a.getY(), c.getY()) && b.getY() >= Math.min(a.getY(), c.getY());
    }

    //Eventually figure out how to add some way to indicate that the obstacle is entirely "behind" the start point
    public void updateMinDistance(Coordinate start) {
        Obstacle complementObstacle = this;
        
        if(this == Constants.constantObstacles[4]) {
            complementObstacle = Constants.constantObstacles[0];
        } else if(this == Constants.constantObstacles[3]) {
            complementObstacle = Constants.constantObstacles[1];
        } else if(this == Constants.constantObstacles[5]) {
            complementObstacle = Constants.constantObstacles[2];
        } else if(this == Constants.constantObstacles[10]) {
            complementObstacle = Constants.constantObstacles[7];
        } else if(this == Constants.constantObstacles[11]) {
            complementObstacle = Constants.constantObstacles[8];
        } else if(this == Constants.constantObstacles[12]) {
            complementObstacle = Constants.constantObstacles[9];
        }

        if(complementObstacle != this) {
            start = start.getComplement();
        }

        if(complementObstacle.closestPoint != null) {
            start.updateDistance(Constants.origin);
            start.updateAngle(Constants.origin);
            int r = (int) ((start.getAngle() < 0 ? 0f : start.getAngle() > frc.robot.Constants.PIF / 2f ? frc.robot.Constants.PIF / 2f : start.getAngle()) * frc.robot.Constants.anglePrecision);
            int c = (int) (start.getDistance() * frc.robot.Constants.distancePrecision);

            float rFraction = ((start.getAngle() < 0 ? 0f : start.getAngle() > frc.robot.Constants.PIF / 2f ? frc.robot.Constants.PIF / 2f : start.getAngle()) * frc.robot.Constants.anglePrecision) - r;
            float cFraction = (start.getDistance() * frc.robot.Constants.distancePrecision) - c;

            int rNext = (r + 1) % complementObstacle.closestPointLookup.length;
            start.updateAngle(complementObstacle.obstacleCenter);

            minDistance = 
                (1 - rFraction) * (1 - cFraction) * complementObstacle.closestPointLookup[r][Math.min(c, complementObstacle.closestPointLookup[r].length - 1)].getFloatValue()
                + rFraction * (1 - cFraction) * complementObstacle.closestPointLookup[r][Math.min(c + 1, complementObstacle.closestPointLookup[r].length - 1)].getFloatValue()
                + (1 - rFraction) * cFraction * complementObstacle.closestPointLookup[rNext][Math.min(c, complementObstacle.closestPointLookup[rNext].length - 1)].getFloatValue()
                + rFraction * cFraction * complementObstacle.closestPointLookup[rNext][Math.min(c + 1, complementObstacle.closestPointLookup[rNext].length - 1)].getFloatValue();
            closestPoint = new Coordinate(complementObstacle.obstacleCenter.getX() + minDistance * frc.robot.Constants.cosLookup(start.getAngle()), complementObstacle.obstacleCenter.getY() + minDistance * frc.robot.Constants.sinLookup(start.getAngle()));

            if(complementObstacle != this) {
                closestPoint = closestPoint.getComplement();
                start = start.getComplement();
            }

            closestPoint.updateDistance(start);
            minDistance = closestPoint.getDistance();

            return;
        }

        Coordinate minVertex = vertices[0];
        Coordinate secondMinVertex = vertices[1];
        vertices[0].updateDistance(start);
        vertices[1].updateDistance(start);

        //Finds the two closest vertices to start
        for(int i = 2; i < vertices.length; ++i) {
            vertices[i].updateDistance(start);

            if(vertices[i].getDistance() < secondMinVertex.getDistance()) {
                if(vertices[i].getDistance() < minVertex.getDistance()) {
                    secondMinVertex = minVertex;
                    minVertex = vertices[i];
                } else {
                    secondMinVertex = vertices[i];
                }
            }
        }

        //Fancy math courtesy of ChatGPT
        float t = (start.getX() - minVertex.getX()) * (secondMinVertex.getX() - minVertex.getX()) + (start.getY() - minVertex.getY()) * (secondMinVertex.getY() - minVertex.getY());
        t /= (secondMinVertex.getX() - minVertex.getX()) * (secondMinVertex.getX() - minVertex.getX()) + (secondMinVertex.getY() - minVertex.getY()) * (secondMinVertex.getY() - minVertex.getY());

        //Fancy math courtesy of ChatGPT
        if(t < 0) {
            closestPoint = minVertex;
            minDistance = minVertex.getDistance();
        } else if(t > 1) {
            closestPoint = secondMinVertex;
            minDistance = secondMinVertex.getDistance();
        } else {
            float x = minVertex.getX() + t * (secondMinVertex.getX() - minVertex.getX());
            float y = minVertex.getY() + t * (secondMinVertex.getY() - minVertex.getY());

            closestPoint = new Coordinate(x, y);
            closestPoint.updateDistance(start);

            minDistance = closestPoint.getDistance();
        }
    }

    //Used for sorting the obstacles based on their minimum distance
    public int compareTo(Obstacle other) {
        return Float.compare(this.minDistance, other.minDistance);
    }

    public float getMinDistance() {
        return minDistance;
    }

    //Should not be called for on the fly minDistance measuring---this method can be very slow
    public Coordinate updateMinDistance(Coordinate start, int vertexOne, int vertexTwo) {
        Coordinate minVertex = vertices[vertexOne];
        Coordinate secondMinVertex = vertices[vertexTwo];
        vertices[vertexOne].updateDistance(start);
        vertices[vertexTwo].updateDistance(start);
        Coordinate out;

        //Fancy math courtesy of ChatGPT
        float t = (start.getX() - minVertex.getX()) * (secondMinVertex.getX() - minVertex.getX()) + (start.getY() - minVertex.getY()) * (secondMinVertex.getY() - minVertex.getY());
        t /= (secondMinVertex.getX() - minVertex.getX()) * (secondMinVertex.getX() - minVertex.getX()) + (secondMinVertex.getY() - minVertex.getY()) * (secondMinVertex.getY() - minVertex.getY());

        //Fancy math courtesy of ChatGPT
        if(t < 0) {
            out = minVertex;
        } else if(t > 1) {
            out = secondMinVertex;
        } else {
            float x = minVertex.getX() + t * (secondMinVertex.getX() - minVertex.getX());
            float y = minVertex.getY() + t * (secondMinVertex.getY() - minVertex.getY());

            out = new Coordinate(x, y);
        }

        out.updateAngle(start);
        out = new Coordinate(out.getX() + 0.1f * frc.robot.Constants.cosLookup(out.getAngle()), out.getY() + 0.1f * frc.robot.Constants.sinLookup(out.getAngle()));

        return out;
    }

    private static float OBMinDistanceNoLookup(float angle) {
        float distance = Constants.fieldX;
        float xDelta = 0.1f * frc.robot.Constants.cosLookup(angle);
        float yDelta = 0.1f * frc.robot.Constants.sinLookup(angle);
        float x = distance * frc.robot.Constants.cosLookup(angle);
        float y = distance * frc.robot.Constants.sinLookup(angle);

        while(x >= 0f && y >= 0f && x <= Constants.fieldX && y <= Constants.fieldY) {
            distance += 0.1f;
            x += xDelta;
            y += yDelta;
        }

        distance -= 0.1f;
        x -= xDelta;
        y -= yDelta;
        xDelta /= 10f;
        yDelta /= 10f;

        while(x >= 0f && y >= 0f && x <= Constants.fieldX && y <= Constants.fieldY) {
            distance += 0.01f;
            x += xDelta;
            y += yDelta;
        }

        return distance;
    }

    public static float OBMinDistance(int index) {
        return OBMinDistanceLookup[index];
    }
}
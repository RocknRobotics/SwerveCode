package frc.robot.Path;

public class PathPoint implements Comparable<PathPoint> {
    private PathPoint prevPoint;
    private Coordinate coordinate;
    private float airDistance;
    private float pathLength;
    private float heuristic;

    //Used for creating the first path point
    public PathPoint(Coordinate start, Coordinate end) {
        prevPoint = null;
        coordinate = start;
        start.updateDistance(end);
        airDistance = start.getDistance();
        pathLength = 0f;
        heuristic = airDistance;
    }

    //Creates a pathpoint with a parent
    public PathPoint(PathPoint prevPoint, Coordinate current, Coordinate end) {
        this.prevPoint = prevPoint;
        coordinate = current;
        coordinate.updateDistance(end);
        airDistance = coordinate.getDistance();
        coordinate.updateDistance(prevPoint.getCoordinate());
        pathLength = prevPoint.pathLength + coordinate.getDistance();
        heuristic = pathLength + airDistance;
    }

    public PathPoint getPrevPoint() {
        return prevPoint;
    }

    public Coordinate getCoordinate() {
        return coordinate;
    }

    public float getPathLength() {
        return pathLength;
    }

    //Used for priority queue in Master
    public int compareTo(PathPoint other) {
        return Float.compare(this.heuristic, other.heuristic);
    }

    //Necessary for HashSet in Master
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        } else if(!(other instanceof PathPoint)) {
            return false;
        } else {
            return this.coordinate.equals(((PathPoint) other).coordinate);
        }
    }

    //Calls coordinate hashing method
    public int hashCode() {
        return this.coordinate.hashCode();
    }
}

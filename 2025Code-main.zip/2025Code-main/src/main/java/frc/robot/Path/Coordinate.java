package frc.robot.Path;

public class Coordinate implements Comparable<Coordinate> {
    //Global x, y of the object
    private float x;
    private float y;

    //The magnitude and angle of the polar vector of this object. May be relative to some other origin
    private float distance;
    private float angle;

    public Coordinate(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void add(float x, float y) {
        this.x += x;
        this.y += y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getDistance() {
        return distance;
    }

    public float getAngle() {
        return angle;
    }

    public void setAngle(float angle) {
        this.angle = angle;
    }

    //Gets the distance between this coordinate and some other coordinate
    public void updateDistance(Coordinate other) {
        distance = frc.robot.Constants.sqrtLookup((this.x - other.x) * (this.x - other.x) + (this.y - other.y) * (this.y - other.y));
    }

    public void updateAngle(Coordinate other) {
        angle = frc.robot.Constants.atanLookup(this.y - other.y, this.x - other.x);
    }

    //Checks if other is within a small circle around this. Otherwise, not considered equal
    public boolean equals(Coordinate other) {
        return frc.robot.Constants.sqrtLookup((this.x - other.x) * (this.x - other.x) + (this.y - other.y) * (this.y - other.y)) < Constants.coordinateEpsilon;
    }

    public boolean roughEquals(Coordinate other) {
        return frc.robot.Constants.sqrtLookup((this.x - other.x) * (this.x - other.x) + (this.y - other.y) * (this.y - other.y)) < 0.25f;
    }

    //Used by HashSet in Master
    public int hashCode() {
        long xQuantized = Math.round(x / Constants.coordinateEpsilon);
        long yQuantized = Math.round(y / Constants.coordinateEpsilon);
        
        int hash = 17;
        hash = 31 * hash + Long.hashCode(xQuantized);
        hash = 31 * hash + Long.hashCode(yQuantized);
        
        return hash;
    }

    //Utility to print the x and y of this coordinate
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    public int compareTo(Coordinate other) {
        return Float.compare(this.distance, other.distance);
    }

    public Coordinate getComplement() {
        return new Coordinate(Constants.fieldX - x, Constants.fieldY - y);
    }
}

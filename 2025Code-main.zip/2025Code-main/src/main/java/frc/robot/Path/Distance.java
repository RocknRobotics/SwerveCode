package frc.robot.Path;

//Used for storing distance from 0 to ~20.8
//Bro really figured out how to store a decimal number in a single byte 💀
public class Distance {
    private byte value;

    public Distance(float value) {
        this.value = Distance.valueOf(value);
    }

    public Distance(byte value) {
        this.value = value;
    }

    public static byte valueOf(float value) {
        //Grabs the exponent
        int exponent = Math.max(0, Math.min(3, (int) Math.ceil(Math.log10(value) / Math.log10(2.5f))));
        //Gets the significand to multiply the exponent by
        float significand = Math.max(0f, Math.min(customPow(3), (customPow(exponent) - customPow(exponent - 1)) * value / customPow(exponent)));
        int sFloor = (int) (significand * 63d / (customPow(exponent) - customPow(exponent - 1)));
        int sCeil = sFloor == 63 ? sFloor : sFloor + 1;
        byte output = 0;

        if(sCeil / (63d / (customPow(exponent) - customPow(exponent - 1))) - significand < significand - sFloor / (63d / (customPow(exponent) - customPow(exponent - 1)))) {
            output = (byte) (64 * exponent + sCeil - 128);
        } else {
            output = (byte) (64 * exponent + sFloor - 128);
        }

        return output;
    }

    public float getFloatValue() {
        int intValue = this.value + 128;
        int exponent = intValue / 64;
        int significand = intValue % 64;

        return customPow(exponent) * significand / 63f;
    }

    private static float customPow(int exponent) {
        if(exponent < 0) {
            return 0f;
        }

        float output = 1f;

        for(int i = 0; i < exponent; ++i) {
            output *= 2.5f;
        }

        return output;
    }

    public void increment() {
        if(value != Byte.MAX_VALUE) {
            ++value;
        }
    }
}

package frc.robot.Path;

public class Constants {
    //Unless stated otherwise, everything is in metres
    public static final float fieldX = 8.058f;
    public static final float fieldY = 17.548f;

    public static final Coordinate origin = new Coordinate(0f, 0f);
    public static final Coordinate tip = new Coordinate(fieldX, fieldY);
    
    public static final float robotDiagonalHalf = frc.robot.Constants.sqrtLookup((frc.robot.Swerve.Constants.robotWidth * frc.robot.Swerve.Constants.robotWidth) + (frc.robot.Swerve.Constants.robotHeight * frc.robot.Swerve.Constants.robotHeight)) / 2f;
    
    static final float[] robotCentreAngles = frc.robot.Swerve.Constants.moduleCentreAngle;

    //The epsilon to use when checking coordinate equality, and for hashing coordinate
    static final float coordinateEpsilon = 0.001f;

    //The leftmost and second leftmost x of the reef
    public static final float[] reefX = {3.07f, 3.541f};

    //The coral station on the left side of the blue alliance, for the x coordinate that doesn't equal 0
    private static final float leftStationX = 1.270f;

    //From bottommost y to topmost y, no repeated points
    public static final float[] blueReefY = {3.658f, 4.481f, 5.321f};

    //The y coordinate that does not equal 0
    private static final float blueStationY = 1.711f;

    //The red cage's x coordinates, from left to right
    private static final float[] redCageX = {4.992f, 6.082f, 7.171f};

    private static final float cageSide = 0.186f;

    private static final float trussSide = 0.3556f;

    public static final Coordinate fieldCentre = new Coordinate(fieldX / 2f, fieldY / 2f);

    //A list of all obstacles we're guaranteed exist for a given match. So, the reefs and the coral stations
    static final Obstacle[] constantObstacles = {
        new Obstacle( //Blue side left coral station
            new Coordinate[]{
                new Coordinate(0f, 0f),
                new Coordinate(0f, blueStationY),
                new Coordinate(leftStationX, 0f)
            }
        ),
        new Obstacle( //Blue side right coral station
            new Coordinate[]{
                new Coordinate(fieldX - 0f, 0f),
                new Coordinate(fieldX - 0f, blueStationY),
                new Coordinate(fieldX - leftStationX, 0f)
            }
        ),
        new Obstacle( //Blue side reef 
            new Coordinate[]{
                new Coordinate(reefX[0], blueReefY[1]),
                new Coordinate(reefX[1], blueReefY[0]),
                new Coordinate(fieldX - reefX[1], blueReefY[0]),
                new Coordinate(fieldX - reefX[0], blueReefY[1]),
                new Coordinate(fieldX - reefX[1], blueReefY[2]),
                new Coordinate(reefX[1], blueReefY[2])
            }
        ),
        new Obstacle( //Red side right coral station
            new Coordinate[]{
                new Coordinate(fieldX - 0f, 0f).getComplement(),
                new Coordinate(fieldX - 0f, blueStationY).getComplement(),
                new Coordinate(fieldX - leftStationX, 0f).getComplement()
            }
        ),
        new Obstacle( //Red side left coral station
            new Coordinate[]{
                new Coordinate(0f, 0f).getComplement(),
                new Coordinate(0f, blueStationY).getComplement(),
                new Coordinate(leftStationX, 0f).getComplement()
            }
        ),
        new Obstacle( //Red side reef 
            new Coordinate[]{
                new Coordinate(reefX[0], blueReefY[1]).getComplement(),
                new Coordinate(reefX[1], blueReefY[0]).getComplement(),
                new Coordinate(fieldX - reefX[1], blueReefY[0]).getComplement(),
                new Coordinate(fieldX - reefX[0], blueReefY[1]).getComplement(),
                new Coordinate(fieldX - reefX[1], blueReefY[2]).getComplement(),
                new Coordinate(reefX[1], blueReefY[2]).getComplement()
            }
        ),
        new Obstacle( //Truss
            new Coordinate[]{
                new Coordinate((fieldX - trussSide) / 2f, (fieldY - trussSide) / 2f),
                new Coordinate((fieldX + trussSide) / 2f, (fieldY - trussSide) / 2f),
                new Coordinate((fieldX + trussSide) / 2f, (fieldY + trussSide) / 2f),
                new Coordinate((fieldX - trussSide) / 2f, (fieldY + trussSide) / 2f)
            }
        ),
        new Obstacle( //Innermost blue cage
            new Coordinate[]{
                new Coordinate(fieldX - redCageX[0], (fieldY - cageSide) / 2f),
                new Coordinate(fieldX - redCageX[0], (fieldY + cageSide) / 2f),
                new Coordinate(fieldX - (redCageX[0] + cageSide), (fieldY + cageSide) / 2f),
                new Coordinate(fieldX - (redCageX[0] + cageSide), (fieldY - cageSide) / 2f)
            }
        ),
        new Obstacle( //Middle blue cage
            new Coordinate[]{
                new Coordinate(fieldX - redCageX[1], (fieldY - cageSide) / 2f),
                new Coordinate(fieldX - redCageX[1], (fieldY + cageSide) / 2f),
                new Coordinate(fieldX - (redCageX[1] + cageSide), (fieldY + cageSide) / 2f),
                new Coordinate(fieldX - (redCageX[1] + cageSide), (fieldY - cageSide) / 2f)
            }
        ),
        new Obstacle( //Outermost blue cage
            new Coordinate[]{
                new Coordinate(fieldX - redCageX[2], (fieldY - cageSide) / 2f),
                new Coordinate(fieldX - redCageX[2], (fieldY + cageSide) / 2f),
                new Coordinate(fieldX - (redCageX[2] + cageSide), (fieldY + cageSide) / 2f),
                new Coordinate(fieldX - (redCageX[2] + cageSide), (fieldY - cageSide) / 2f)
            }
        ),
        new Obstacle( //Innermost red cage
            new Coordinate[]{
                new Coordinate(fieldX - redCageX[0], (fieldY - cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - redCageX[0], (fieldY + cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - (redCageX[0] + cageSide), (fieldY + cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - (redCageX[0] + cageSide), (fieldY - cageSide) / 2f).getComplement()
            }
        ),
        new Obstacle( //Middle red cage
            new Coordinate[]{
                new Coordinate(fieldX - redCageX[1], (fieldY - cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - redCageX[1], (fieldY + cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - (redCageX[1] + cageSide), (fieldY + cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - (redCageX[1] + cageSide), (fieldY - cageSide) / 2f).getComplement()
            }
        ),
        new Obstacle( //Outermost red cage
            new Coordinate[]{
                new Coordinate(fieldX - redCageX[2], (fieldY - cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - redCageX[2], (fieldY + cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - (redCageX[2] + cageSide), (fieldY + cageSide) / 2f).getComplement(),
                new Coordinate(fieldX - (redCageX[2] + cageSide), (fieldY - cageSide) / 2f).getComplement()
            }
        )
    };

    public static final Obstacle[] reefs = {constantObstacles[2], constantObstacles[5]};
}

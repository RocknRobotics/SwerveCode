package frc.robot.Joystick;

public final class Constants {
    //The port for the drive joystick
    static final int drivePort = 0;

    //The port for the arm joystick
    static final int armPort = 1;

    //The deadband to apply on the translational movement of the drive joystick
    static final float driveTranslationalDeadband = 0.15f;

    //The deadband to apply on the rotational movement of the drive joystick
    static final float driveRotationalDeadband = 0.15f;

    static final float armDeadband = 0.15f;
}

package frc.robot.Joystick;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import edu.wpi.first.wpilibj.PS4Controller;

public class Master {
    public static PS4Controller driveJoystick;
    public static PS4Controller armJoystick;

    private frc.robot.Swerve.Master swerveMaster;
    private frc.robot.Elevator.Master elevatorMaster;
    private frc.robot.Arm.Master armMaster;
    private frc.robot.AlgaePickup.Master algaeMaster;
    private frc.robot.DecisionMaker.Master decisionMaster;

    private int mode;
    //0 is full manual
    //1 if goTo assisted manual
    //2 if path planning assisted manual
    //3 is full auto

    public Master(frc.robot.Swerve.Master swerveMaster, frc.robot.Elevator.Master elevatorMaster, frc.robot.Arm.Master armMaster, frc.robot.AlgaePickup.Master algaeMaster, frc.robot.DecisionMaker.Master decisionMaster) {
        driveJoystick = new PS4Controller(Constants.drivePort);
        armJoystick = new PS4Controller(Constants.armPort);
        this.swerveMaster = swerveMaster;
        this.elevatorMaster = elevatorMaster;
        this.armMaster = armMaster;
        this.algaeMaster = algaeMaster;
        this.decisionMaster = decisionMaster;

        mode = 0;
    }

    public void teleopPeriodic() {
        if(driveJoystick.getTouchpadButtonPressed()) {
            mode = 0;
        } else if(driveJoystick.getShareButtonPressed()) {
            mode = 2;
        } else if(driveJoystick.getPSButtonPressed()) {
            mode = 3;
        }

        if(mode < 3) {
            if(mode == 0) {
                swerveMaster.teleopPeriodic(new float[]{
                    (float) MathUtil.applyDeadband(Math.sqrt(driveJoystick.getLeftX() * driveJoystick.getLeftX() + driveJoystick.getLeftY() * driveJoystick.getLeftY()), Constants.driveTranslationalDeadband),
                    2f * frc.robot.Constants.PIF - frc.robot.Constants.atanLookup((float) driveJoystick.getLeftY(), (float) driveJoystick.getLeftX()) + (DriverStation.getAlliance().get().equals(Alliance.Red) ? frc.robot.Constants.PIF : 0f),
                    (float) MathUtil.applyDeadband(-driveJoystick.getRightX(), Constants.driveRotationalDeadband),
                    (driveJoystick.getL1Button() ? 0.4f : 
                    driveJoystick.getL2Button() ? 0.1f : 0.8f),
                    driveJoystick.getOptionsButtonPressed() ? 1f : -1f,
                    (driveJoystick.getCrossButton() ? 0f :
                    driveJoystick.getCircleButton() ? 60f :
                    driveJoystick.getTriangleButton() ? 120f :
                    driveJoystick.getSquareButton() ? 180f :
                    driveJoystick.getR1Button() ? 240f :
                    driveJoystick.getR2Button() ? 300f : -1f),
                    0f
                });
            } else if(mode == 2) {
                int side = 
                    driveJoystick.getCrossButton() ? 0 :
                    driveJoystick.getCircleButton() ? 1 :
                    driveJoystick.getTriangleButton() ? 2 :
                    driveJoystick.getSquareButton() ? 3 :
                    driveJoystick.getR1Button() ? 4 :
                    driveJoystick.getR2Button() ? 5 : -1;
                int branch = 
                    driveJoystick.getL1Button() ? 0 :
                    driveJoystick.getL2Button() ? 1 : -1;

                if(side != -1 && branch != -1) {
                    float[] p = decisionMaster.getPathBranchGoTo(side, branch);
                    swerveMaster.goTo(p[0], p[1], p[2], p[3]);
                } else {
                    swerveMaster.teleopPeriodic(new float[]{
                        (float) MathUtil.applyDeadband(Math.sqrt(driveJoystick.getLeftX() * driveJoystick.getLeftX() + driveJoystick.getLeftY() * driveJoystick.getLeftY()), Constants.driveTranslationalDeadband),
                        2f * frc.robot.Constants.PIF - frc.robot.Constants.atanLookup((float) driveJoystick.getLeftY(), (float) driveJoystick.getLeftX()) + (DriverStation.getAlliance().get().equals(Alliance.Red) ? frc.robot.Constants.PIF : 0f),
                        (float) MathUtil.applyDeadband(-driveJoystick.getRightX(), Constants.driveRotationalDeadband),
                        0.35f,
                        -1f,
                        -1f,
                        0f
                    });
                }
            }

            int elevatorUpDown = 
                MathUtil.applyDeadband(armJoystick.getLeftY(), Constants.armDeadband) == 0 ? -1 : 
                armJoystick.getLeftY() < 0 ? 7 : 8;

            elevatorMaster.teleopPeriodic(
                armJoystick.getCrossButton() ? 0 :
                armJoystick.getCircleButton() ? 1 :
                armJoystick.getTriangleButton() ? 2 :
                armJoystick.getSquareButton() ? 3 :
                armJoystick.getPOV() == 0 ? 4 :
                armJoystick.getPOV() == 90 ? 5 :
                armJoystick.getPOV() == 180 ? 6 : elevatorUpDown
            );

            int algaeUpDown = 
                MathUtil.applyDeadband(armJoystick.getRightY(), Constants.armDeadband) == 0 ? -1 : 
                armJoystick.getRightY() < 0 ? 0 : 1;

            algaeMaster.teleopPeriodic(
                algaeUpDown,
                armJoystick.getR1Button() ? 0 :
                armJoystick.getL1Button() ? 1 : -1
            );

            armMaster.teleopPeriodic(
                armJoystick.getR2Button() ? 0 :
                armJoystick.getL2Button() ? 1 : 
                armJoystick.getPOV() == 270 ? 2 : -1
            );
        } else {
            if(armJoystick.getShareButtonPressed()) {
                decisionMaster.toggleStation(true);
            } else if(armJoystick.getOptionsButtonPressed()) {
                decisionMaster.toggleStation(false);
            }

            int driveSide = 
                driveJoystick.getCrossButton() ? 0 :
                driveJoystick.getCircleButton() ? 1 :
                driveJoystick.getTriangleButton() ? 2 :
                driveJoystick.getSquareButton() ? 3 :
                driveJoystick.getR1Button() ? 4 :
                driveJoystick.getR2Button() ? 5 : -1;
            int driveBranch = 
                driveJoystick.getL1Button() ? 0 :
                driveJoystick.getL2Button() ? 1 : -1;
            int driveHeight = 
                driveJoystick.getPOV() == 180 ? 0 :
                driveJoystick.getPOV() == 90 ? 1 :
                driveJoystick.getPOV() == 0 ? 2 :
                driveJoystick.getPOV() == 270 ? 3 : -1;

            int armSide = 
                armJoystick.getCrossButton() ? 0 :
                armJoystick.getCircleButton() ? 1 :
                armJoystick.getTriangleButton() ? 2 :
                armJoystick.getSquareButton() ? 3 :
                armJoystick.getR1Button() ? 4 :
                armJoystick.getR2Button() ? 5 : -1;
            int armBranch = 
                armJoystick.getL1Button() ? 0 :
                armJoystick.getL2Button() ? 1 : -1;
            int armHeight = 
                armJoystick.getPOV() == 180 ? 0 :
                armJoystick.getPOV() == 90 ? 1 :
                armJoystick.getPOV() == 0 ? 2 :
                armJoystick.getPOV() == 270 ? 3 : -1;

            if(driveSide != -1 && driveBranch != -1 && driveHeight != -1) {
                decisionMaster.addCoral(driveSide, driveBranch, driveHeight);
            }

            if(armSide != -1 && armBranch != -1 && armHeight != -1) {
                decisionMaster.addCoral(armSide, armBranch, armHeight);
            }

            decisionMaster.actOnBehaviour();
        }
    }
}
